from flask import Blueprint, request, jsonify

from database import db

from models.repair_ticket import RepairTicket
from models.repair_history import RepairHistory

from services.workflow_service import WorkflowService
from services.ticket_service import TicketService

from flask_jwt_extended import (
    jwt_required,
    get_jwt_identity,
    get_jwt
)

workflow_bp = Blueprint(
    "workflow",
    __name__,
    url_prefix="/api"
    #url_prefix="/workflow"
)


# =====================================================
# 1. 修改維修狀態
# POST /api/tickets/<ticket_id>/status
# =====================================================

@workflow_bp.route(
    "/tickets/<int:ticket_id>/status",
    methods=["POST"]
)
def change_status(ticket_id):
    print("=== workflow API ===")
    print(ticket_id)

    ticket = RepairTicket.query.get(ticket_id)

    if not ticket:
        return jsonify({
            "error": "Ticket not found"
        }), 404


    data = request.json or {}

    status = data.get("status")
    remark = data.get(
        "remark",
        ""
    )


    if not status:

        return jsonify({
            "error":"status required"
        }),400



    try:

        WorkflowService.change_status(

            ticket,

            status,

            remark=remark

        )


        db.session.commit()


        return jsonify({

            "message":
            "status updated",

            "ticket_id":
            ticket.id,

            "status":
            ticket.status

        })


    except Exception as e:

        db.session.rollback()

        return jsonify({

            "error":
            str(e)

        }),400

"""
@workflow_bp.route(
    "/tickets/<int:id>/complete",
    methods=["POST"]
)
@jwt_required()
def complete_ticket(id):

    
    ticket = RepairTicket.query.get(id)


    if not ticket:

        return jsonify({

            "error":
            "Ticket not found"

        }),404



    ticket.status = "completed"


    db.session.commit()
    


    return jsonify({

        "message":
        "案件完成"

    })
"""
@workflow_bp.route(
    "/tickets/<int:id>/complete",
    methods=["POST"]
)
@jwt_required()
def complete_ticket(id):


    current_user = get_jwt_identity()


    WorkflowService.complete_ticket(
        id,
        current_user
    )


    return jsonify({
        "message":"案件已完成"
    })


# =====================================================
# 2. 指派工程師
# POST /api/tickets/<ticket_id>/assign
# =====================================================

@workflow_bp.route(
    "/tickets/<int:ticket_id>/assign",
    methods=["POST"]
)
def assign_engineer(ticket_id):

    print("=== workflow API ===")
    print(ticket_id)

    ticket = RepairTicket.query.get(ticket_id)


    if not ticket:

        return jsonify({
            "error":
            "Ticket not found"
        }),404



    data=request.json or {}

    engineer_id=data.get(
        "engineer_id"
    )


    if not engineer_id:

        return jsonify({

            "error":
            "engineer_id required"

        }),400



    try:

        WorkflowService.assign_engineer(

            ticket,

            engineer_id

        )


        db.session.commit()


        return jsonify({

            "message":
            "engineer assigned",

            "ticket_id":
            ticket.id,

            "engineer_id":
            ticket.engineer_id

        })


    except Exception as e:

        db.session.rollback()

        return jsonify({

            "error":
            str(e)

        }),400

@workflow_bp.route(
    "/tickets/<int:id>/start",
    methods=["POST"]
)
@jwt_required()
def start_ticket(id):


    ticket = TicketService.get(id)


    if not ticket:

        return jsonify({
            "error":
            "Ticket not found"
        }),404



    ticket.status="repairing"


    db.session.commit()



    return jsonify({

        "message":
        "開始維修成功"

    })




# =====================================================
# 3. 查詢 Repair History
# GET /api/tickets/<ticket_id>/history
# =====================================================

@workflow_bp.route(
    "/tickets/<int:ticket_id>/history",
    methods=["GET"]
)
def history(ticket_id):

    print("=== workflow API ===")
    print(ticket_id)

    ticket = RepairTicket.query.get(ticket_id)


    if not ticket:

        return jsonify({

            "error":
            "Ticket not found"

        }),404



    histories = RepairHistory.query.filter_by(

        ticket_id=ticket_id

    ).order_by(

        RepairHistory.created_at.asc()

    ).all()



    result=[]


    for h in histories:


        result.append({

            "id":
            h.id,

            "old_status":
            h.old_status,

            "new_status":
            h.new_status,

            "remark":
            h.remark,

            "created_at":
            h.created_at.isoformat()

        })



    return jsonify({

        "ticket_id":
        ticket_id,

        "count":
        len(result),

        "history":
        result

    })





# =====================================================
# 4. 查詢 Workflow 狀態
# GET /api/tickets/<ticket_id>/workflow
# =====================================================

@workflow_bp.route(
    "/tickets/<int:ticket_id>/workflow",
    methods=["GET"]
)
def workflow(ticket_id):

    print("=== workflow API ===")
    print(ticket_id)

    ticket = RepairTicket.query.get(ticket_id)


    if not ticket:

        return jsonify({

            "error":
            "Ticket not found"

        }),404



    next_status = (
        WorkflowService.STATUS_FLOW
        .get(
            ticket.status,
            []
        )
    )


    return jsonify({

        "ticket_id":
        ticket.id,

        "ticket_no":
        ticket.ticket_no,

        "current_status":
        ticket.status,

        "next_status":
        next_status

    })