from app import create_app

from database.base import db

from models.repair_ticket import RepairTicket



app=create_app()


with app.app_context():


    ticket = (
        RepairTicket.query
        .first()
    )


    print(
        "Ticket:",
        ticket.ticket_no
    )


    print(
        "Customer:",
        ticket.customer.name
        if ticket.customer
        else None
    )


    print(
        "Device:",
        ticket.device.brand
        if ticket.device
        else None
    )


    print(
        "History Count:",
        len(ticket.histories)
    )