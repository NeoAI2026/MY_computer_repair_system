from datetime import datetime

from database.base import db



class Device(db.Model):

    __tablename__ = "devices"


    id = db.Column(
        db.Integer,
        primary_key=True
    )


    customer_id = db.Column(
        db.Integer,
        db.ForeignKey(
            "customers.id"
        ),
        nullable=False
    )


    device_type = db.Column(
        db.String(100),
        nullable=False
    )


    brand = db.Column(
        db.String(100)
    )


    model = db.Column(
        db.String(100)
    )


    serial_number = db.Column(
        db.String(200)
    )


    note = db.Column(
        db.Text
    )


    created_at = db.Column(
        db.DateTime,
        default=datetime.utcnow
    )


    updated_at = db.Column(
        db.DateTime,
        default=datetime.utcnow,
        onupdate=datetime.utcnow
    )


    # ==========================
    # Customer Relation
    # ==========================

    customer = db.relationship(
        "Customer",
        back_populates="devices"
    )


    # ==========================
    # Ticket Relation
    # ==========================

    tickets = db.relationship(
        "RepairTicket",
        back_populates="device",
        cascade="all, delete",
        lazy=True
    )


"""
from datetime import datetime

from database.base import db


class Device(db.Model):

    __tablename__ = "devices"


    id = db.Column(
        db.Integer,
        primary_key=True
    )


    # 客戶關聯
    customer_id = db.Column(
        db.Integer,
        db.ForeignKey(
            "customers.id"
        ),
        nullable=False
    )


    device_type = db.Column(
        db.String(50),
        nullable=False
    )


    brand = db.Column(
        db.String(100)
    )


    model = db.Column(
        db.String(100)
    )


    serial_number = db.Column(
        db.String(100),
        unique=True
    )


    purchase_date = db.Column(
        db.Date
    )


    note = db.Column(
        db.Text
    )


    created_at = db.Column(
        db.DateTime,
        default=datetime.utcnow
    )


    updated_at = db.Column(
        db.DateTime,
        default=datetime.utcnow,
        onupdate=datetime.utcnow
    )


    # Customer relationship

    customer = db.relationship(
        "Customer",
        back_populates="devices"
    )


    # Ticket relationship

    tickets = db.relationship(
        "RepairTicket",
        back_populates="device"
    )
"""


"""
from database.base import db
from datetime import datetime

class Device(db.Model):

    __tablename__="devices"


    id=db.Column(
        db.Integer,
        primary_key=True
    )


    customer_id=db.Column(
        db.Integer,
        db.ForeignKey("customers.id")
    )


    device_type=db.Column(
        db.String(50)
    )


    brand=db.Column(
        db.String(100)
    )


    model=db.Column(
        db.String(100)
    )


    serial_number=db.Column(
        db.String(100)
    )

    description = db.Column(
            db.Text
        )


    created_at = db.Column(
        db.DateTime,
        default=datetime.utcnow
    )

    customer=db.relationship(
        "Customer",
        back_populates="devices"
    )

    tickets = db.relationship(
        "RepairTicket",
        back_populates="device"
    )
"""