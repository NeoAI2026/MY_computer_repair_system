from database.base import db
from datetime import datetime


class Quotation(db.Model):

    __tablename__ = "quotations"


    id = db.Column(
        db.Integer,
        primary_key=True
    )


    quotation_no = db.Column(
        db.String(50),
        unique=True,
        nullable=False
    )


    ticket_id = db.Column(
        db.Integer,
        db.ForeignKey(
            "repair_tickets.id"
        ),
        nullable=False
    )


    engineer_id = db.Column(
        db.Integer,
        db.ForeignKey(
            "users.id"
        )
    )


    status = db.Column(
        db.String(30),
        default="draft"
    )


    # draft
    # sent
    # confirmed
    # rejected


    subtotal = db.Column(
        db.Float,
        default=0
    )


    tax = db.Column(
        db.Float,
        default=0
    )


    total_amount = db.Column(
        db.Float,
        default=0
    )


    customer_note = db.Column(
        db.Text
    )


    created_at = db.Column(
        db.DateTime,
        default=datetime.utcnow
    )

    # ★ 重要
    repair_ticket = db.relationship(
        "RepairTicket",
        back_populates="quotations"
    )

    updated_at = db.Column(
        db.DateTime,
        default=datetime.utcnow,
        onupdate=datetime.utcnow
    )


    ticket = db.relationship(
        "RepairTicket",
        backref="quotation"
    )


    engineer = db.relationship(
        "User"
    )


    items = db.relationship(
        "QuotationItem",
        back_populates="quotation",
        cascade="all, delete-orphan"
    )


    def calculate_total(self):

        self.subtotal = sum(
            item.amount
            for item in self.items
        )


        self.tax = self.subtotal * 0.05


        self.total_amount = (
            self.subtotal +
            self.tax
        )
