from database.base import db
from datetime import datetime


class RepairHistory(db.Model):

    __tablename__="repair_histories"


    id=db.Column(
        db.Integer,
        primary_key=True
    )


    ticket_id=db.Column(
        db.Integer,
        db.ForeignKey(
            "repair_tickets.id"
        ),
        nullable=False
    )


    user_id=db.Column(
        db.Integer,
        db.ForeignKey(
            "users.id"
        )
    )


    old_status=db.Column(
        db.String(30)
    )


    new_status=db.Column(
        db.String(30)
    )


    note=db.Column(
        db.Text
    )


    created_at=db.Column(
        db.DateTime,
        default=datetime.utcnow
    )


    ticket=db.relationship(
        "RepairTicket",
        back_populates="histories"
    )


    user=db.relationship(
        "User"
    )