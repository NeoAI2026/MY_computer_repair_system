from database.base import db
from datetime import datetime

class Device(db.Model):

    __tablename__="devices"


    id=db.Column(
        db.Integer,
        primary_key=True
    )


    customer_id=db.Column(
        db.Integer,
        db.ForeignKey("customers.id")
    )


    device_type=db.Column(
        db.String(50)
    )


    brand=db.Column(
        db.String(100)
    )


    model=db.Column(
        db.String(100)
    )


    serial_number=db.Column(
        db.String(100)
    )

    description = db.Column(
            db.Text
        )


    created_at = db.Column(
        db.DateTime,
        default=datetime.utcnow
    )

    customer=db.relationship(
        "Customer",
        back_populates="devices"
    )

    tickets = db.relationship(
        "RepairTicket",
        back_populates="device"
    )