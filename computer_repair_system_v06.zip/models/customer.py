from database.base import db
from datetime import datetime


class Customer(db.Model):

    __tablename__="customers"


    id=db.Column(
        db.Integer,
        primary_key=True
    )


    name=db.Column(
        db.String(100),
        nullable=False
    )


    phone=db.Column(
        db.String(50)
    )


    email=db.Column(
        db.String(100)
    )


    address=db.Column(
        db.String(200)
    )


    created_at=db.Column(
        db.DateTime,
        default=datetime.utcnow
    )


    devices=db.relationship(
        "Device",
        back_populates="customer"
    )