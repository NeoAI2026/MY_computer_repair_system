from database.base import db
from datetime import datetime


class RepairTicket(db.Model):

    __tablename__ = "repair_tickets"


    id = db.Column(
        db.Integer,
        primary_key=True
    )


    ticket_no = db.Column(
        db.String(50),
        unique=True,
        nullable=False
    )


    customer_id = db.Column(
        db.Integer,
        db.ForeignKey("customers.id"),
        nullable=False
    )


    device_id = db.Column(
        db.Integer,
        db.ForeignKey("devices.id")
    )


    engineer_id = db.Column(
        db.Integer,
        db.ForeignKey("users.id")
    )


    title = db.Column(
        db.String(200),
        nullable=False
    )


    description = db.Column(
        db.Text
    )


    status = db.Column(
        db.String(50),
        default="new"
    )    

    priority = db.Column(
        db.String(20),
        default="normal"
    )


    created_at = db.Column(
        db.DateTime,
        default=datetime.utcnow
    )


    updated_at = db.Column(
        db.DateTime,
        default=datetime.utcnow,
        onupdate=datetime.utcnow
    )


    customer = db.relationship(
        "Customer"
    )


    device = db.relationship(
        "Device"
    )


    engineer = db.relationship(
        "User"
    )


    histories = db.relationship(
        "RepairHistory",
        back_populates="ticket",
        cascade="all, delete-orphan"
    )


    attachments = db.relationship(
        "Attachment",
        back_populates="ticket",
        cascade="all, delete-orphan"
    )

    """
    quotation = db.relationship(
        "Quotation",
        uselist=False,
        back_populates="ticket"
    )
    """
    quotations=db.relationship(
            "Quotation",
            back_populates="repair_ticket",
            cascade="all, delete-orphan"
        )
    
    quotations = db.relationship(
        "Quotation",
        back_populates="repair_ticket",
        cascade="all, delete-orphan"
    )

    def status_text(self):

        mapping = {

            "pending":"待派工",

            "assigned":"已派工程師",

            "checking":"檢測中",

            "quotation":"報價確認",

            "repairing":"維修中",

            "testing":"測試中",

            "completed":"完工",

            "accepted":"客戶驗收",

            "closed":"結案"

        }


        return mapping.get(
            self.status,
            self.status
        )