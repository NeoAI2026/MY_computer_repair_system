from database.base import db
from datetime import datetime


class User(db.Model):

    __tablename__ = "users"


    id = db.Column(
        db.Integer,
        primary_key=True
    )


    username = db.Column(
        db.String(50),
        unique=True,
        nullable=False
    )


    password_hash = db.Column(
        db.String(255),
        nullable=False
    )


    email = db.Column(
        db.String(120)
    )


    role_id = db.Column(
        db.Integer,
        db.ForeignKey("roles.id")
    )


    active = db.Column(
        db.Boolean,
        default=True
    )


    created_at = db.Column(
        db.DateTime,
        default=datetime.utcnow
    )


    role = db.relationship(
        "Role",
        back_populates="users"
    )