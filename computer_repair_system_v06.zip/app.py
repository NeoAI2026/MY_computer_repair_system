from flask import Flask

from config import Config

from database.base import db



def create_app():

    app=Flask(__name__)


    app.config.from_object(
        Config
    )


    db.init_app(app)


    return app



app=create_app()



@app.route("/")
def index():

    return "CRMS System Running"



if __name__=="__main__":

    app.run(
        debug=True
    )