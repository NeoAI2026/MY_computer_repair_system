from datetime import date

from models.repair_ticket import RepairTicket
from models.user import User


class DashboardService:

    @staticmethod
    def admin_dashboard():

        tickets = (
            RepairTicket.query
            .order_by(RepairTicket.id.desc())
            .limit(10)
            .all()
        )

        all_tickets = RepairTicket.query.all()

        return {

            "tickets": tickets,
            
            "total_tickets":
                len(all_tickets),

            "today_count":
                RepairTicket.query.filter(
                    RepairTicket.created_at >= date.today()
                ).count(),            

            "pending_count":
                RepairTicket.query.filter_by(
                    status="pending"
                ).count(),

            "repairing_count":
                RepairTicket.query.filter_by(
                    status="repairing"
                ).count(),

            "closed_count":
                RepairTicket.query.filter_by(
                    status="closed"
                ).count(),

            "new_count":
                RepairTicket.query.filter_by(
                    status="new"
                ).count(),
            
            "engineer_count":
                User.query.count()
        }
    
    @staticmethod
    def engineer_dashboard(user_id):

        tickets = RepairTicket.query.filter_by(
            engineer_id=user_id
        ).all()

        return {

            "tickets": tickets,

            "total": len(tickets),

            "repairing":
                RepairTicket.query.filter_by(
                    engineer_id=user_id,
                    status="repairing"
                ).count(),

            "completed":
                RepairTicket.query.filter_by(
                    engineer_id=user_id,
                    status="closed"
                ).count()

        }
    
    @staticmethod
    def get_engineer_dashboard(user_id):


        tickets = RepairTicket.query.filter_by(
            engineer_id=user_id
        ).all()


        return {


            "tickets": tickets,


            "total": len(tickets),


            "checking":
            RepairTicket.query.filter_by(
                engineer_id=user_id,
                status="checking"
            ).count(),



            "repairing":
            RepairTicket.query.filter_by(
                engineer_id=user_id,
                status="repairing"
            ).count(),



            "completed":
            RepairTicket.query.filter(
                RepairTicket.engineer_id==user_id,
                RepairTicket.status.in_(
                    [
                        "completed",
                        "closed"
                    ]
                )
            ).count()

        }


"""
from datetime import datetime, timedelta
from datetime import date

from database.base import db

from models.repair_ticket import RepairTicket
from models.repair_history import RepairHistory



class DashboardService:

    @staticmethod
    def get_admin_dashboard():

        tickets = RepairTicket.query.order_by(
            RepairTicket.id.desc()
        ).limit(10).all()

        all_tickets = RepairTicket.query.all()

        return {

            "tickets": tickets,

            "total_tickets": len(all_tickets),

            "today_count":
                RepairTicket.query.filter(
                    RepairTicket.created_at >= date.today()
                ).count(),

            "pending_count":
                RepairTicket.query.filter_by(
                    status="pending"
                ).count(),

            "repairing_count":
                RepairTicket.query.filter_by(
                    status="repairing"
                ).count(),

            "closed_count":
                RepairTicket.query.filter_by(
                    status="closed"
                ).count(),

            "new_count":
                RepairTicket.query.filter_by(
                    status="new"
                ).count(),


        }

    # =========================
    # 今日新增案件
    # =========================

    @staticmethod
    def today_ticket_count():


        today = datetime.utcnow().date()


        return RepairTicket.query.filter(

            db.func.date(
                RepairTicket.created_at
            ) == today

        ).count()



    # =========================
    # 待處理案件
    # =========================

    @staticmethod
    def pending_count():


        return RepairTicket.query.filter(

            RepairTicket.status.in_(

                [
                    "new",
                    "processing"
                ]

            )

        ).count()



    # =========================
    # 狀態統計
    # =========================

    @staticmethod
    def status_summary():


        result = {}


        rows = db.session.query(

            RepairTicket.status,

            db.func.count(
                RepairTicket.id
            )

        ).group_by(

            RepairTicket.status

        ).all()



        for status,count in rows:

            result[status] = count



        return result




    # =========================
    # 最近維修紀錄
    # =========================

    @staticmethod
    def recent_history(limit=10):


        histories = RepairHistory.query.order_by(

            RepairHistory.created_at.desc()

        ).limit(limit).all()



        return histories




    # =========================
    # 工程師案件
    # =========================

    @staticmethod
    def engineer_ticket_count(
        engineer_id
    ):


        return RepairTicket.query.filter(

            RepairTicket.engineer_id ==
            engineer_id

        ).count()




    # =========================
    # Dashboard Payload
    # =========================

    @staticmethod
    def get_dashboard_data(
        role,
        user_id=None
    ):


        data = {


            "today":

                DashboardService.today_ticket_count(),


            "pending":

                DashboardService.pending_count(),


            "status":

                DashboardService.status_summary(),


            "history":

                DashboardService.recent_history()

        }



        if role=="engineer":


            data["my_tickets"] = (

                DashboardService
                .engineer_ticket_count(
                    user_id
                )

            )


        else:


            data["my_tickets"]=0



        return data

"""