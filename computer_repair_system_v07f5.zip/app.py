from flask import Flask
from flask_jwt_extended import get_jwt

from config import Config

from database.base import db

from routes.workflow_routes import workflow_bp
from routes.ticket_routes import ticket_bp
from routes.web_ticket_routes import web_ticket_bp
from routes.history_routes import history_bp
from flask_jwt_extended import JWTManager
from routes.auth_routes import auth_bp
from routes.dashboard_routes import dashboard_bp
from routes.web_routes import web_bp


#from routes.test_permission_routes import test_permission_bp
from routes.test_permission_routes import (
    test_permission_bp
)

jwt = JWTManager()

def create_app():

    app=Flask(__name__)
   

    # =====================================
    # JWT Cookie 設定
    # =====================================

    app.config["JWT_TOKEN_LOCATION"] = [
        "cookies"
    ]


    app.config["JWT_COOKIE_SECURE"] = False


    app.config["JWT_COOKIE_CSRF_PROTECT"] = False


    app.config["JWT_ACCESS_COOKIE_PATH"] = "/"


    app.config["JWT_COOKIE_SAMESITE"] = "Lax"

    app.secret_key = "crms-secret-key"

    app.config["JWT_SECRET_KEY"] = (
        "crms-secret-key-change-later"
    )
    
    app.config.from_object(
        Config
    )
    
    app.register_blueprint(
        auth_bp
    )

    app.register_blueprint(
        test_permission_bp
    )

    app.register_blueprint(dashboard_bp)

    app.register_blueprint(
        workflow_bp
    )

    app.register_blueprint(
        ticket_bp
    )
    
    app.register_blueprint(
        history_bp
    )

    app.register_blueprint(web_bp)

    

    db.init_app(app)

    jwt.init_app(app)

    return app



app=create_app()

from flask_jwt_extended import get_jwt


@app.context_processor
def inject_user():

    try:

        claims=get_jwt()

        return {

            "jwt_user":
                claims.get("username"),

            "jwt_role":
                claims.get("role")

        }


    except:

        return {

            "jwt_user":None,

            "jwt_role":None

        }


@app.route("/")
def index():

    return "CRMS System Running"



if __name__=="__main__":
    """
    #print(app.url_map)
    for rule in app.url_map.iter_rules():
        print(rule.endpoint, rule.rule)
    """
    app.run(
        debug=True
    )