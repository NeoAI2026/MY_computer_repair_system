import os
from flask import Flask, jsonify

from config import Config
from database.base import db
from flask_jwt_extended import JWTManager

from routes.repair_ticket_routes import repair_ticket_bp
from routes.attachment_routes import attachment_bp
from routes.dashboard_routes import dashboard_bp
from routes.repair_history_routes import history_bp
from routes.vendor_routes import vendor_bp
from routes.user_admin_routes import user_admin_bp

from flask import render_template
from flask import redirect, request


app = Flask(
    __name__,
    template_folder="templates",
    static_folder="static"
)

app.config.from_object(Config)

db.init_app(app)

app.config["JWT_SECRET_KEY"] = "computer_repair_jwt_secret"
jwt = JWTManager(app)

# =========================
# 🔥 Import Models（一定要）
# =========================
import models

# =========================
# 🔥 Register Routes
# =========================
from routes.user_routes import user_bp

app.register_blueprint(user_bp, url_prefix="/api/users")

app.register_blueprint(repair_ticket_bp, url_prefix="/api/tickets")

app.register_blueprint(
    attachment_bp,
    url_prefix="/api/attachments"
)

app.register_blueprint(dashboard_bp, url_prefix="/api/dashboard")

app.register_blueprint(history_bp, url_prefix="/api/history")

app.register_blueprint(vendor_bp, url_prefix="/api/vendors")

app.register_blueprint(
    user_admin_bp,
    url_prefix="/api/users"
)


@app.errorhandler(Exception)
def handle_error(e):

    return jsonify({
        "error": str(e)
    }), 500


@jwt.unauthorized_loader
def missing_token(callback):
    return {"error": "Missing token"}, 401

@app.route("/unauthorized")
def unauthorized():
    return render_template("unauthorized.html")


@jwt.invalid_token_loader
def invalid_token(callback):
    return {"error": "Invalid token"}, 401


@jwt.expired_token_loader
def expired_token(jwt_header, jwt_payload):
    return {"error": "Token expired"}, 401



@app.route("/")
def home():
    return {
        "system": "Computer Repair System",
        "version": "DEV-02",
        "status": "API Running"
    }

@app.route("/login")
def login_page():
    return render_template("login.html")

@app.route("/dashboard")
def dashboard_page():
    return render_template("dashboard.html")

@app.route("/tickets")
def tickets_page():
    return render_template("tickets.html")

@app.route("/ticket-create")
def ticket_create_page():
    return render_template("ticket_create.html")

@app.route("/base")
def base_page():
    return render_template("base.html")


if __name__ == "__main__":
    with app.app_context():
        db.create_all()

    app.run(debug=True, host="0.0.0.0", port=5000)