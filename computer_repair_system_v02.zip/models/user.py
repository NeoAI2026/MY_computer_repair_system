from werkzeug.security import generate_password_hash, check_password_hash

from database.base import db
from models.base_model import BaseModel

class User(BaseModel):
    """
    系統使用者
    """

    __tablename__ = "users"

    username = db.Column(
        db.String(50),
        unique=True,
        nullable=False,
        index=True
    )

    password_hash = db.Column(
        db.String(255),
        nullable=False
    )

    name = db.Column(
        db.String(100),
        nullable=False
    )

    email = db.Column(
        db.String(120),
        unique=True,
        nullable=False
    )

    phone = db.Column(
        db.String(30)
    )

    role = db.Column(
        db.String(20),
        default="USER"
    )
    
    def set_role(self, role):
        self.role = role.upper().strip()

    # ADMIN
    # ENGINEER
    # USER

    status = db.Column(
        db.Boolean,
        default=True
    )

    # 建立的工單
    repair_tickets = db.relationship(
        "RepairTicket",
        foreign_keys="RepairTicket.creator_id",
        back_populates="creator",
        lazy=True
    )

    # 維修紀錄
    repair_histories = db.relationship(
        "RepairHistory",
        foreign_keys="RepairHistory.created_by",
        back_populates="user",
        lazy=True
    )

    # 系統Log
    logs = db.relationship(
        "SystemLog",
        back_populates="user",
        lazy=True
    )

    def set_password(self, password):

        self.password_hash = generate_password_hash(password)

    def check_password(self, password):

        return check_password_hash(
            self.password_hash,
            password
        )

    def set_role(self, role):
        self.role = role.upper().strip()

    def __repr__(self):

        return f"<User {self.username}>"

    def to_dict(self):

        return {
            "id": self.id,
            "username": self.username,
            "name": self.name,
            "email": self.email,
            "phone": self.phone,
            "role": self.role,
            "status": self.status,
            "created_at": self.created_at,
            "updated_at": self.updated_at
        }