from datetime import datetime

from database.base import db
from models.repair_history import RepairHistory

class HistoryService:


    @staticmethod
    def add(
        ticket_id,
        user_id=None,
        action=None,
        description=None,
        old_status=None,
        new_status=None,
        note=None
    ):


        history = RepairHistory(

            ticket_id=ticket_id,

            user_id=user_id,

            action=action,

            description=description,

            old_status=old_status,

            new_status=new_status,

            note=note,

            created_at=datetime.utcnow()

        )


        db.session.add(history)

        db.session.commit()


        return history

    @staticmethod
    def get_ticket_history(ticket_id):

        return (
            RepairHistory.query
            .filter_by(
                ticket_id=ticket_id
            )
            .order_by(
                RepairHistory.created_at.desc()
            )
            .all()
        )