from datetime import datetime

from database.base import db

from models.quotation import Quotation
from models.ticket_part import TicketPart
from models.part import Part


class QuotationService:

    @staticmethod
    def get_all():

        return (
            Quotation.query
            .order_by(
                Quotation.created_at.desc()
            )
            .all()
        )

    @staticmethod
    def get_detail(id):

        quotation = Quotation.query.get(id)

        ticket_parts = (
            TicketPart.query
            .filter_by(ticket_id=quotation.ticket_id)
            .all()
        )

        return quotation, ticket_parts

    @staticmethod
    def generate_number():

        today = datetime.now().strftime("%Y%m%d")

        count = Quotation.query.count() + 1

        return f"QT{today}{count:04d}"

    @staticmethod
    def create(ticket_id, user_id):

        quotation = Quotation(

            quotation_no=QuotationService.generate_number(),

            ticket_id=ticket_id,

            created_by=user_id

        )

        db.session.add(quotation)

        db.session.commit()

        QuotationService.calculate(quotation.id)

        return quotation

    @staticmethod
    def get(id):

        return Quotation.query.get(id)

    @staticmethod
    def get_by_ticket(ticket_id):

        return Quotation.query.filter_by(

            ticket_id=ticket_id

        ).first()

    @staticmethod
    def calculate(id):

        quotation = Quotation.query.get(id)

        if quotation is None:
            return

        ticket_parts = TicketPart.query.filter_by(

            ticket_id=quotation.ticket_id

        ).all()

        parts_total = 0

        for item in ticket_parts:

            part = Part.query.get(item.part_id)

            if part:

                parts_total += part.price * item.quantity

        quotation.parts_total = parts_total

        quotation.total_price = (

            quotation.parts_total +

            quotation.labor_fee +

            quotation.other_fee

        )

        db.session.commit()

        @staticmethod
        def update(id, form):

            quotation = Quotation.query.get(id)

            quotation.labor_fee = float(

                form.get(

                    "labor_fee",

                    0

                )

            )

            quotation.other_fee = float(

                form.get(

                    "other_fee",

                    0

                )

            )

            db.session.commit()

            QuotationService.calculate(id)

    @staticmethod
    def approve(id):

        quotation = Quotation.query.get(id)

        quotation.status = "Approved"

        quotation.approved_at = datetime.now()

        db.session.commit()

    @staticmethod
    def reject(id):

        quotation = Quotation.query.get(id)

        quotation.status = "Rejected"

        db.session.commit()