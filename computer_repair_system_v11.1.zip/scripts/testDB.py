from app import create_app
from database.base import db


app=create_app()


with app.app_context():

    db.session.execute(
        db.text(
            """
            ALTER TABLE quotations
            ADD COLUMN customer_id INTEGER
            """
        )
    )


    db.session.commit()


print(
    "quotation customer_id added"
)