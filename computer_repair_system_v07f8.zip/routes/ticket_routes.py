from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required

from services.ticket_service import TicketService
from middleware.permission import permission_required

from datetime import datetime

from database.base import db

from models.repair_ticket import RepairTicket
from models.repair_history import RepairHistory

ticket_bp = Blueprint(
    "ticket",
    __name__,
    url_prefix="/api"
)

# ==========================
# Create Ticket
# ==========================
@ticket_bp.route("/tickets/create", methods=["POST"])
@jwt_required()
@permission_required("ticket:create")
def create_ticket():

    ticket = TicketService.create_ticket(request.json)

    return jsonify({
        "message": "ticket created",
        "ticket_id": ticket.id,
        "ticket_no": ticket.ticket_no
    }), 201


# ==========================
# List Tickets
# ==========================
@ticket_bp.route("/tickets", methods=["GET"])
@jwt_required()
@permission_required("ticket:list")
def list_tickets():


    keyword = request.args.get(
        "keyword"
    )


    status = request.args.get(
        "status"
    )


    tickets = TicketService.search(
        keyword,
        status
    )


    return jsonify([

        {

            "id": t.id,

            "ticket_no":
                t.ticket_no,


            "customer_name":
                t.customer_name,


            "device_type":
                t.device_type,


            "status":
                t.status,


            "priority":
                t.priority,


            # ⭐新增工程師名稱
            "engineer":
                t.engineer.username
                if t.engineer
                else None,


            # 保留ID方便後續修改
            "engineer_id":
                t.engineer_id

        }

        for t in tickets

    ])

# ==========================
# Ticket Detail
# ==========================
@ticket_bp.route("/<int:ticket_id>", methods=["GET"])
@jwt_required()
@permission_required("ticket:list")
def get_ticket(ticket_id):

    ticket = TicketService.get_ticket(ticket_id)

    if ticket is None:
        return jsonify({
            "error": "ticket not found"
        }), 404

    return jsonify({
        "id": ticket.id,
        "ticket_no": ticket.ticket_no,
        "title": ticket.title,
        "description": ticket.description,
        "status": ticket.status,
        "priority": ticket.priority,
        "category": ticket.category
    })


# ==========================
# Update Ticket
# ==========================
"""
@ticket_bp.route("/<int:ticket_id>", methods=["PUT"])
@jwt_required()
@permission_required("ticket:update")
def update_ticket(ticket_id):

    ticket = TicketService.update_ticket(
        ticket_id,
        request.json
    )

    if ticket is None:
        return jsonify({
            "error": "ticket not found"
        }), 404

    return jsonify({
        "message": "ticket updated"
    })
"""
# =========================
# Update Ticket
# =========================

@ticket_bp.route(
    "/<int:ticket_id>",
    methods=["PUT"]
)
@jwt_required()
@permission_required(
    "ticket:update"
)
def update_ticket(ticket_id):


    ticket = TicketService.get_ticket(
        ticket_id
    )


    if ticket is None:

        return jsonify({

            "error":
            "ticket not found"

        }),404



    TicketService.update_ticket(

        ticket,

        request.json

    )


    return jsonify({

        "message":
        "ticket updated",

        "ticket_id":
        ticket.id,

        "status":
        ticket.status

    }),200


# ==========================
# Assign Engineer
# ==========================
@ticket_bp.route("/<int:ticket_id>/assign", methods=["PUT"])
@jwt_required()
@permission_required("ticket:assign")
def assign_ticket(ticket_id):

    engineer_id = request.json.get("engineer_id")

    ticket = TicketService.assign_engineer(
        ticket_id,
        engineer_id
    )

    if ticket is None:
        return jsonify({
            "error": "ticket not found"
        }), 404

    return jsonify({
        "message": "engineer assigned"
    })


# ==========================
# Close Ticket
# ==========================
"""
@ticket_bp.route("/<int:ticket_id>/close", methods=["POST"])
@jwt_required()
@permission_required("ticket:close")
def close_ticket(ticket_id):

    ticket = TicketService.close_ticket(ticket_id)

    if ticket is None:
        return jsonify({
            "error": "ticket not found"
        }), 404

    return jsonify({
        "message": "ticket closed"
    })
"""
# =========================
# Close Ticket
# =========================

@ticket_bp.route(
    "/tickets/<int:ticket_id>/close",
    methods=["POST"]
)
@jwt_required()
@permission_required(
    "ticket:close"
)
def close_ticket(ticket_id):


    ticket = TicketService.get_ticket(
        ticket_id
    )


    if ticket is None:

        return jsonify({

            "error":
            "ticket not found"

        }),404



    TicketService.close_ticket(
        ticket
    )


    return jsonify({

        "message":
        "ticket closed",

        "ticket_id":
        ticket.id,

        "status":
        ticket.status

    }),200

    