from flask import (
    Blueprint,
    render_template,
    request,
    redirect,
    url_for,
    flash
)


from flask_jwt_extended import (
    create_access_token,
    set_access_cookies,
    unset_jwt_cookies,
    jwt_required,
    get_jwt,
    get_jwt_identity
)


from services.auth_service import AuthService
from services.ticket_service import TicketService
from services.user_service import UserService


from models.repair_ticket import RepairTicket
from models.repair_history import RepairHistory
from services.dashboard_service import DashboardService
from models.user import User

from flask import g

web_bp = Blueprint(
    "web",
    __name__
)

@web_bp.app_context_processor
def inject_user():

    try:

        claims = get_jwt()

        return {

            "username":
                claims.get("username"),

            "role":
                claims.get("role")

        }

    except:

        return {

            "username":None,

            "role":None

        }

# =================================
# Home
# =================================

@web_bp.route("/")
def home():

    return redirect(
        url_for(
            "web.login"
        )
    )



# =================================
# Login
# =================================

@web_bp.route(
    "/login",
    methods=[
        "GET",
        "POST"
    ]
)
def login():


    if request.method == "POST":


        username = request.form.get(
            "username"
        )


        password = request.form.get(
            "password"
        )


        user = AuthService.login(
            username,
            password
        )


        if user is None:


            flash(
                "帳號或密碼錯誤",
                "danger"
            )


            return redirect(
                url_for(
                    "web.login"
                )
            )


        # JWT identity 必須 string

        access_token = create_access_token(

            identity=str(user.id),

            additional_claims={

                "username":
                    user.username,

                "role":
                    user.role.name

            }

        )


        response = redirect(

            url_for(
                "web.dashboard"
            )

        )


        set_access_cookies(

            response,

            access_token

        )


        return response



    return render_template(
        "login.html"
    )



# =================================
# Dashboard Router
# =================================

@web_bp.route("/dashboard")
@jwt_required()
def dashboard():

    claims = get_jwt()

    role = claims.get("role")


    if role == "admin":

        data = DashboardService.get_admin_dashboard()

        return render_template(
            "dashboard/admin.html",
            **data
        )


    elif role == "engineer":

        return redirect(
            url_for(
                "web.dashboard_engineer"
            )
        )


    elif role == "manager":

        return redirect(
            url_for(
                "web.dashboard_manager"
            )
        )


    elif role == "vendor":

        return redirect(
            url_for(
                "web.dashboard_vendor"
            )
        )


    return redirect(
        url_for("web.login")
    )


# =================================
# Engineer Dashboard
# =================================

@web_bp.route("/dashboard/engineer")
@jwt_required()
def dashboard_engineer():

    user_id=int(
        get_jwt_identity()
    )


    data = DashboardService.get_engineer_dashboard(
        user_id
    )


    return render_template(
        "dashboard/engineer.html",
        **data
    )




# =================================
# Manager Dashboard
# =================================


@web_bp.route(
    "/dashboard/manager"
)
@jwt_required()
def dashboard_manager():


    data = DashboardService.get_manager_dashboard()


    return render_template(

        "dashboard/manager.html",

        **data

    )


# =================================
# Vendor Dashboard
# =================================

@web_bp.route(
    "/dashboard/vendor"
)
@jwt_required()
def dashboard_vendor():


    data = DashboardService.get_vendor_dashboard()


    return render_template(

        "dashboard/vendor.html",

        **data

    )


# =================================
# Ticket List
# =================================


@web_bp.route(
    "/tickets"
)
@jwt_required()
def ticket_list():


    claims=get_jwt()

    role=claims.get("role")

    user_id=int(
        get_jwt_identity()
    )


    if role=="admin":

        tickets=TicketService.get_all()


    elif role=="manager":

        tickets=TicketService.get_all()


    elif role=="engineer":

        tickets=(
            RepairTicket.query
            .filter_by(
                engineer_id=user_id
            )
            .all()
        )


    elif role=="vendor":

        tickets=TicketService.get_waiting_parts()


    else:

        tickets=[]



    return render_template(

        "tickets/list.html",

        tickets=tickets

    )



# =================================
# Create Ticket
# =================================


@web_bp.route(
    "/tickets/create",
    methods=[
        "GET",
        "POST"
    ]
)
@jwt_required()
def create_ticket_page():


    if request.method == "POST":


        creator_id = int(
            get_jwt_identity()
        )


        data = (
            request.form
            .to_dict()
        )


        TicketService.create_ticket(

            data,

            creator_id

        )


        flash(
            "案件建立成功",
            "success"
        )


        return redirect(
            url_for(
                "web.ticket_list"
            )
        )



    return render_template(
        "tickets/create.html"
    )



# =================================
# Ticket Detail
# =================================


@web_bp.route(
    "/tickets/<int:ticket_id>"
)
@jwt_required()
def ticket_detail(ticket_id):


    ticket = TicketService.get_ticket(ticket_id)


    if ticket is None:

        flash(
            "案件不存在",
            "danger"
        )

        return redirect(
            url_for("web.ticket_list")
        )


    user_id = int(
        get_jwt_identity()
    )


    user = User.query.get(
        user_id
    )


    return render_template(

        "tickets/detail.html",

        user=user,

        ticket=ticket

    )



# =================================
# Ticket Edit
# =================================


@web_bp.route(
    "/tickets/<int:ticket_id>/edit",
    methods=[
        "GET",
        "POST"
    ]
)
@jwt_required()
def edit_ticket(ticket_id):


    ticket = (
        TicketService
        .get_ticket(
            ticket_id
        )
    )


    if request.method == "POST":


        data = (
            request.form
            .to_dict()
        )


        TicketService.update_ticket(

            ticket,

            data

        )


        if data.get(
            "engineer_id"
        ):


            TicketService.assign_engineer(

                ticket_id,

                data["engineer_id"]

            )


        return redirect(

            url_for(

                "web.ticket_detail",

                ticket_id=ticket_id

            )

        )



    engineers = (
        UserService
        .get_engineers()
    )


    return render_template(

        "tickets/edit.html",

        ticket=ticket,

        engineers=engineers

    )



# =================================
# History
# =================================


@web_bp.route(
    "/tickets/<int:ticket_id>/history"
)
@jwt_required()
def ticket_history(ticket_id):


    ticket = (
        RepairTicket
        .query
        .get_or_404(
            ticket_id
        )
    )


    histories = (
        RepairHistory
        .query
        .filter_by(
            ticket_id=ticket_id
        )
        .order_by(
            RepairHistory.created_at.asc()
        )
        .all()
    )


    return render_template(

        "tickets/history.html",

        ticket=ticket,

        histories=histories

    )



# =================================
# Logout
# =================================


@web_bp.route(
    "/logout"
)
def logout():


    response = redirect(

        url_for(
            "web.login"
        )

    )


    unset_jwt_cookies(
        response
    )


    flash(
        "已登出",
        "success"
    )


    return response

@web_bp.route("/customers")
@jwt_required()
def customer_list():

    customers = CustomerService.get_all()

    return render_template(
        "customers/list.html",
        customers=customers
    )

@web_bp.route("/devices")
@jwt_required()
def device_list():

    devices = DeviceService.get_all()

    return render_template(
        "devices/list.html",
        devices=devices
    )

@web_bp.route("/engineers")
@jwt_required()
def engineer_list():

    engineers = UserService.get_engineers()

    return render_template(
        "engineers/list.html",
        engineers=engineers
    )


@web_bp.route("/vendors")
@jwt_required()
def vendor_list():

    vendors = VendorService.get_all()

    return render_template(
        "vendors/list.html",
        vendors=vendors
    )



@web_bp.route("/quotations")
@jwt_required()
def quotation_list():

    quotations = QuotationService.get_all()

    return render_template(
        "quotations/list.html",
        quotations=quotations
    )

@web_bp.route("/reports")
@jwt_required()
def report_dashboard():

    data = ReportService.dashboard()

    return render_template(
        "reports/dashboard.html",
        **data
    )

@web_bp.route("/settings")
@jwt_required()
def system_setting():

    return render_template(
        "settings/index.html"
    )

