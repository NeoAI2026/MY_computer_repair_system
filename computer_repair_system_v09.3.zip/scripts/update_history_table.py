import sqlite3


conn = sqlite3.connect(
    "database/db.sqlite3"
)

cursor = conn.cursor()


try:

    cursor.execute(
        """
        ALTER TABLE repair_histories
        ADD COLUMN action VARCHAR(100)
        """
    )

    print("action 新增成功")


except Exception as e:

    print(e)



try:

    cursor.execute(
        """
        ALTER TABLE repair_histories
        ADD COLUMN description TEXT
        """
    )

    print("description 新增成功")


except Exception as e:

    print(e)



conn.commit()

conn.close()