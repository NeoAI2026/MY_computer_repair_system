from app import app
from database.base import db

with app.app_context():
    db.create_all()