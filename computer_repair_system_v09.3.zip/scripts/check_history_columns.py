import sqlite3


conn = sqlite3.connect(
    "instance/crms.db"
)


cursor = conn.cursor()


cursor.execute(
    """
    PRAGMA table_info(repair_histories)
    """
)


columns = cursor.fetchall()


for col in columns:
    print(col)


conn.close()