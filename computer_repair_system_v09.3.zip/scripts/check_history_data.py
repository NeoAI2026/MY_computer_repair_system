import sqlite3


conn = sqlite3.connect(
    "instance/crms.db"
)


cursor = conn.cursor()


cursor.execute(
    """
    SELECT 
        id,
        ticket_id,
        user_id,
        action,
        description,
        created_at
    FROM repair_histories
    ORDER BY id DESC
    LIMIT 10
    """
)


for row in cursor.fetchall():
    print(row)


conn.close()