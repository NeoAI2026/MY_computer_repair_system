from app import app
from database.base import db
from models.part import Part


with app.app_context():

    Part.__table__.create(
        db.engine
    )

    print("parts table created")