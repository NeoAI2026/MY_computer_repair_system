import sqlite3


conn = sqlite3.connect(
    "database/db.sqlite3"
)


cursor = conn.cursor()


cursor.execute(
    "PRAGMA table_info(repair_histories)"
)


for row in cursor.fetchall():

    print(row)


conn.close()