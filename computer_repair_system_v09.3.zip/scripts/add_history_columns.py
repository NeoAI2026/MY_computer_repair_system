import sqlite3


conn = sqlite3.connect(
    "instance/crms.db"
)

cursor = conn.cursor()


try:

    cursor.execute(
        """
        ALTER TABLE repair_histories
        ADD COLUMN action VARCHAR(100)
        """
    )

    print("action OK")

except Exception as e:

    print(e)



try:

    cursor.execute(
        """
        ALTER TABLE repair_histories
        ADD COLUMN description TEXT
        """
    )

    print("description OK")

except Exception as e:

    print(e)



conn.commit()

conn.close()