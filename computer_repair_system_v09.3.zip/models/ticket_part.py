from database.base import db
from datetime import datetime


class TicketPart(db.Model):

    __tablename__ = "ticket_parts"


    id = db.Column(
        db.Integer,
        primary_key=True
    )


    ticket_id = db.Column(
        db.Integer,
        db.ForeignKey(
            "repair_tickets.id"
        ),
        nullable=False
    )


    part_id = db.Column(
        db.Integer,
        db.ForeignKey(
            "parts.id"
        ),
        nullable=False
    )


    quantity = db.Column(
        db.Integer,
        default=1
    )


    created_at = db.Column(
        db.DateTime,
        default=datetime.utcnow
    )

    # TicketPart -> RepairTicket
    ticket = db.relationship(
        "RepairTicket",
        back_populates="parts"
    )

    # TicketPart -> Part
    part = db.relationship(
        "Part",
        back_populates="ticket_parts"
    )