from datetime import datetime
from database.base import db


class Part(db.Model):

    __tablename__ = "parts"


    id = db.Column(
        db.Integer,
        primary_key=True
    )


    part_no = db.Column(
        db.String(50),
        unique=True,
        nullable=False
    )


    part_name = db.Column(
        db.String(100),
        nullable=False
    )


    brand = db.Column(
        db.String(100)
    )


    model = db.Column(
        db.String(100)
    )


    supplier = db.Column(
        db.String(100)
    )


    price = db.Column(
        db.Float,
        default=0
    )


    stock = db.Column(
        db.Integer,
        default=0
    )


    min_stock = db.Column(
        db.Integer,
        default=0
    )


    status = db.Column(
        db.String(20),
        default="ACTIVE"
    )


    created_at = db.Column(
        db.DateTime,
        default=datetime.utcnow
    )


    updated_at = db.Column(
        db.DateTime,
        default=datetime.utcnow,
        onupdate=datetime.utcnow
    )


    ticket_parts = db.relationship(
        "TicketPart",
        back_populates="part",
        cascade="all, delete-orphan"
    )