from datetime import datetime

from database.base import db



class RepairHistory(db.Model):

    __tablename__ = "repair_histories"



    id = db.Column(

        db.Integer,

        primary_key=True

    )



    # =========================
    # 所屬案件
    # =========================

    ticket_id = db.Column(

        db.Integer,

        db.ForeignKey(
            "repair_tickets.id"
        ),

        nullable=False,

        index=True

    )



    # =========================
    # 狀態變更
    # =========================


    old_status = db.Column(

        db.String(50)

    )



    new_status = db.Column(

        db.String(50)

    )



    # =========================
    # 操作內容
    # =========================


    note = db.Column(

        db.Text

    )



    # =========================
    # 操作者
    # =========================


    user_id = db.Column(

        db.Integer,

        db.ForeignKey(
            "users.id"
        ),

        nullable=True

    )

    action = db.Column(
        db.String(100)
    )


    description = db.Column(
        db.Text
    )


    # =========================
    # 時間
    # =========================


    created_at = db.Column(

        db.DateTime,

        default=datetime.utcnow

    )



    # =================================================
    # Relationship
    # =================================================



    # History -> Ticket

    ticket = db.relationship(

        "RepairTicket",

        back_populates="histories"

    )



    # History -> User

    user = db.relationship(

        "User",

        back_populates="repair_histories"

    )



    def __repr__(self):

        return (

            f"<RepairHistory {self.ticket_id}>"

        )