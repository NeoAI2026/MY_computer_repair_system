from database.base import db

from models.ticket_part import TicketPart
from models.part import Part



class TicketPartService:


    @staticmethod
    def get_by_ticket(ticket_id):

        return (
            TicketPart.query
            .filter_by(
                ticket_id=ticket_id
            )
            .all()
        )


    @staticmethod
    def add(ticket_id, part_id, qty):

        item = TicketPart(

            ticket_id=ticket_id,

            part_id=part_id,

            quantity=qty

        )


        db.session.add(item)


        # 扣庫存

        part = Part.query.get(part_id)

        if part:

            part.stock -= qty


        db.session.commit()


        return item



    @staticmethod
    def delete(id):

        item = TicketPart.query.get(id)

        if item:

            part = Part.query.get(
                item.part_id
            )

            if part:
                part.stock += item.quantity


            db.session.delete(item)

            db.session.commit()


        return True