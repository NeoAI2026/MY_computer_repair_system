from database.base import db
from models.repair_history import RepairHistory


class HistoryService:


    @staticmethod
    def add(
        ticket_id,
        user_id,
        action,
        description
    ):


        history = RepairHistory(

            ticket_id=ticket_id,

            user_id=user_id,

            action=action,

            description=description

        )


        db.session.add(history)

        db.session.commit()


        return history