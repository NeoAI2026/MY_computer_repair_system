from database.base import db
from models.part import Part


class PartService:

    @staticmethod
    def get_all():
        return Part.query.order_by(
            Part.part_name
        ).all()

    @staticmethod
    def get(id):
        return Part.query.get(id)

    @staticmethod
    def create(data):

        part = Part(
            part_no=data["part_no"],
            part_name=data["part_name"],
            brand=data.get("brand"),
            model=data.get("model"),
            supplier=data.get("supplier"),
            price=float(data.get("price") or 0),
            stock=int(data.get("stock") or 0),
            min_stock=int(data.get("min_stock") or 0)
        )

        db.session.add(part)
        db.session.commit()

        return part

    @staticmethod
    def update(id, data):

        part = Part.query.get(id)

        if not part:
            return None

        part.part_no = data["part_no"]
        part.part_name = data["part_name"]
        part.brand = data.get("brand")
        part.model = data.get("model")
        part.supplier = data.get("supplier")
        part.price = float(data.get("price") or 0)
        part.stock = int(data.get("stock") or 0)
        part.min_stock = int(data.get("min_stock") or 0)

        db.session.commit()

        return part

    @staticmethod
    def delete(id):

        part = Part.query.get(id)

        if part:
            db.session.delete(part)
            db.session.commit()