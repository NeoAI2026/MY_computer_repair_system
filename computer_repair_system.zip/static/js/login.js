if (data.role === "ADMIN") {
    window.location.href = "/dashboard";
}

if (data.role === "ENGINEER") {
    window.location.href = "/engineer";
}

if (data.role === "USER") {
    window.location.href = "/my-tickets";
}