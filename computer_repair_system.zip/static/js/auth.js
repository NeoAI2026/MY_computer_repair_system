function getToken() {
    return localStorage.getItem("token");
}

function getRole() {
    return localStorage.getItem("role");
}

function requireLogin() {
    if (!getToken()) {
        window.location.href = "/login";
    }
}

function requireRole(roles) {

    const role = getRole();

    if (!roles.includes(role)) {
        window.location.href = "/unauthorized";
    }
}