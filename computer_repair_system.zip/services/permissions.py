from functools import wraps
from flask_jwt_extended import get_jwt_identity
from flask import jsonify

from models.user import User

def get_current_user():

    user_id = get_jwt_identity()
    return User.query.get(user_id)

def admin_required(fn):

    @wraps(fn)
    def wrapper(*args, **kwargs):

        user = get_current_user()

        if not user:
            return jsonify({"error": "Unauthorized"}), 401

        if user.role != "ADMIN":
            return jsonify({"error": "Admin only"}), 403

        return fn(*args, **kwargs)

    return wrapper

def engineer_required(fn):

    @wraps(fn)
    def wrapper(*args, **kwargs):

        user = get_current_user()

        if not user:
            return jsonify({"error": "Unauthorized"}), 401

        if user.role not in ["ENGINEER", "ADMIN"]:
            return jsonify({"error": "Engineer only"}), 403

        return fn(*args, **kwargs)

    return wrapper

def login_required(fn):

    @wraps(fn)
    def wrapper(*args, **kwargs):

        user = get_current_user()

        if not user:
            return jsonify({"error": "Unauthorized"}), 401

        return fn(*args, **kwargs)

    return wrapper