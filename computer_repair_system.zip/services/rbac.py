from functools import wraps
from flask import jsonify
from flask_jwt_extended import get_jwt_identity

from models.user import User

def get_current_user():
    user_id = get_jwt_identity()

    if not user_id:
        return None

    return User.query.get(int(user_id))

def normalize_role(role):
    if not role:
        return "USER"
    return role.upper()

ROLE_PERMISSIONS = {
    "ADMIN": {
        "user:manage",
        "ticket:create",
        "ticket:assign",
        "ticket:view",
        "ticket:update",
        "dashboard:view"
    },

    "ENGINEER": {
        "ticket:view",
        "ticket:accept",
        "ticket:update",
        "ticket:list",
        "dashboard:view"
    },

    "USER": {
        "ticket:create",
        "ticket:view_own",
        "dashboard:view"
    }
}

def has_permission(user, permission):

    if not user:
        return False

    role = normalize_role(user.role)

    permissions = ROLE_PERMISSIONS.get(role, set())

    return permission in permissions

def permission_required(permission):

    def decorator(fn):

        @wraps(fn)
        def wrapper(*args, **kwargs):

            user = get_current_user()

            if not user:
                return jsonify({"error": "Unauthorized"}), 401

            # 🔥 DEBUG（開發期必備）
            print("RBAC DEBUG:")
            print("User:", user.username)
            print("Role:", user.role)
            print("Required:", permission)

            if not has_permission(user, permission):
                return jsonify({
                    "error": "Forbidden",
                    "role": user.role,
                    "required": permission
                }), 403

            return fn(*args, **kwargs)

        return wrapper

    return decorator