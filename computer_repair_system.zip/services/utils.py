import uuid
from datetime import datetime


def generate_ticket_no():
    """
    產生唯一工單編號
    格式：T20260627-8F3A2B
    """

    date_part = datetime.now().strftime("%Y%m%d")

    uuid_part = str(uuid.uuid4()).split("-")[0].upper()

    return f"T{date_part}-{uuid_part}"