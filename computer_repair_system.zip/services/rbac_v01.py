from functools import wraps
from flask import jsonify
from flask_jwt_extended import get_jwt_identity

from models.user import User


def get_current_user():
    user_id = get_jwt_identity()
    return User.query.get(user_id)


ROLE_PERMISSIONS = {
    "ADMIN": ["user:manage", "ticket:assign", "ticket:create"],
    "ENGINEER": ["ticket:accept", "ticket:update"],
    "USER": ["ticket:create"]
}


def has_permission(user, permission):
    if not user:
        return False
    return permission in ROLE_PERMISSIONS.get(user.role, [])


def permission_required(permission):

    def decorator(fn):

        @wraps(fn)
        def wrapper(*args, **kwargs):

            user = get_current_user()

            if not user:
                return jsonify({"error": "Unauthorized"}), 401

            if not has_permission(user, permission):
                return jsonify({
                    "error": "Forbidden",
                    "permission": permission
                }), 403

            return fn(*args, **kwargs)

        return wrapper

    return decorator