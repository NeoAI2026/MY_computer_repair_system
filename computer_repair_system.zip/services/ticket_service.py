from models.repair_ticket import RepairTicket
from database.base import db


def create_ticket(data, user_id):

    ticket = RepairTicket(
        ticket_no=data.get("ticket_no"),
        title=data.get("title"),
        description=data.get("description"),
        status="OPEN",
        creator_id=user_id
    )

    db.session.add(ticket)
    db.session.commit()

    return ticket