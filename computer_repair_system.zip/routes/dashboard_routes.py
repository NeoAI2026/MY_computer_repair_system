from flask import Blueprint, jsonify
from flask_jwt_extended import jwt_required
from models.repair_ticket import RepairTicket
from models.user import User

from services.rbac import permission_required

dashboard_bp = Blueprint("dashboard_bp", __name__)

@dashboard_bp.route("/", methods=["GET"])
@jwt_required()
def dashboard():

    total_users = User.query.count()
    total_tickets = RepairTicket.query.count()

    open_tickets = RepairTicket.query.filter_by(status="OPEN").count()
    processing_tickets = RepairTicket.query.filter_by(status="PROCESSING").count()
    closed_tickets = RepairTicket.query.filter_by(status="CLOSED").count()

    return jsonify({
        "users": total_users,
        "tickets": total_tickets,
        "open": open_tickets,
        "processing": processing_tickets,
        "closed": closed_tickets
    })