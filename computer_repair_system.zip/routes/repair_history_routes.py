from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity

from database.base import db
from models.repair_history import RepairHistory

history_bp = Blueprint("history_bp", __name__)

@history_bp.route("/", methods=["POST"])
@jwt_required()
def add_history():

    data = request.get_json()
    user_id = get_jwt_identity()

    history = RepairHistory(
        ticket_id=data.get("ticket_id"),
        status=data.get("status"),
        content=data.get("content"),
        repair_result=data.get("repair_result"),
        created_by=user_id
    )

    db.session.add(history)
    db.session.commit()

    return jsonify(history.to_dict())

@history_bp.route("/ticket/<int:ticket_id>", methods=["GET"])
@jwt_required()
def get_history(ticket_id):

    histories = RepairHistory.query.filter_by(
        ticket_id=ticket_id
    ).all()

    return jsonify([h.to_dict() for h in histories])