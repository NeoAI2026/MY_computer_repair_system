from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity

from database.base import db
from models.repair_ticket import RepairTicket
from models.system_log import SystemLog

from services.utils import generate_ticket_no

from services.rbac import permission_required 

repair_ticket_bp = Blueprint("repair_ticket_bp", __name__)

@repair_ticket_bp.route("/", methods=["POST"])
@jwt_required()
@permission_required("ticket:create")
def create_ticket():

    data = request.get_json()
    user_id = get_jwt_identity()

    ticket = RepairTicket(
    ticket_no=generate_ticket_no(),
    title=data.get("title"),
    description=data.get("description"),
    device_type=data.get("device_type"),
    device_brand=data.get("device_brand"),
    device_model=data.get("device_model"),
    serial_number=data.get("serial_number"),
    priority=data.get("priority", "NORMAL"),
    status="OPEN",
    creator_id=user_id
)

    db.session.add(ticket)

    # 🔥 系統日誌
    log = SystemLog(
        user_id=user_id,
        action="CREATE_TICKET",
        detail=f"Ticket {ticket.ticket_no} created"
    )

    db.session.add(log)
    db.session.commit()

    return jsonify({
        "message": "Ticket created",
        "ticket": ticket.to_dict()
    })

@repair_ticket_bp.route("/", methods=["GET"])
@jwt_required()
@permission_required("ticket:list")
def get_tickets():

    tickets = RepairTicket.query.all()

    return jsonify([
        t.to_dict()
        for t in tickets
    ])

@repair_ticket_bp.route("/<int:ticket_id>", methods=["GET"])
@jwt_required()
@permission_required("ticket:accept")
def get_ticket(ticket_id):

    ticket = RepairTicket.query.get(ticket_id)

    if not ticket:
        return jsonify({"error": "Ticket not found"}), 404

    return jsonify(ticket.to_dict())

@repair_ticket_bp.route("/<int:ticket_id>/status", methods=["PUT"])
@jwt_required()
@permission_required("ticket:update")
def update_status(ticket_id):

    data = request.get_json()
    user_id = get_jwt_identity()

    ticket = RepairTicket.query.get(ticket_id)

    if not ticket:
        return jsonify({"error": "Ticket not found"}), 404

    ticket.status = data.get("status", ticket.status)

    # 🔥 log
    log = SystemLog(
        user_id=user_id,
        action="UPDATE_TICKET_STATUS",
        detail=f"Ticket {ticket_id} -> {ticket.status}"
    )

    db.session.add(log)
    db.session.commit()

    return jsonify({
        "message": "Status updated",
        "ticket": ticket.to_dict()
    })

