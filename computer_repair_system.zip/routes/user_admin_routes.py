from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required

from models.user import User
from database.base import db
from services.rbac_v01 import permission_required

user_admin_bp = Blueprint("user_admin_bp", __name__)

@user_admin_bp.route("/", methods=["GET"])
@jwt_required()
@permission_required("user:manage")
def get_users():

    users = User.query.all()

    return jsonify([u.to_dict() for u in users])

@user_admin_bp.route("/", methods=["POST"])
@jwt_required()
@permission_required("user:manage")
def create_user():

    data = request.get_json()

    user = User(
        username=data["username"],
        name=data["name"],
        email=data["email"],
        role=data.get("role", "USER")
    )
    user.set_role(data.get("role", "USER"))

    user.set_password(data["password"])

    db.session.add(user)
    db.session.commit()

    return user.to_dict()