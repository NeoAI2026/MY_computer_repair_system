from flask import Blueprint, request, jsonify

from database.base import db
from models.user import User

from flask_jwt_extended import create_access_token
from werkzeug.security import check_password_hash

from flask_jwt_extended import jwt_required

from services.rbac import permission_required

user_bp = Blueprint("user_bp", __name__)


# =========================
# ✔ 建立使用者（Register）
# =========================
@user_bp.route("/register", methods=["POST"])
@user_bp.route("/register", methods=["POST"])
def register_user():

    data = request.get_json()

    # ✅ 必填欄位檢查
    required_fields = ["username", "password", "name"]

    for field in required_fields:
        if not data.get(field):
            return jsonify({
                "error": f"Missing required field: {field}"
            }), 400

    if User.query.filter_by(username=data["username"]).first():
        return jsonify({"error": "Username already exists"}), 400

    user = User(
        username=data["username"],
        name=data.get("name"),
        email=data.get("email"),
        phone=data.get("phone"),
        role=data.get("role", "USER").upper().strip()
    )

    user.set_password(data["password"])

    db.session.add(user)
    db.session.commit()

    return jsonify({
        "message": "User created successfully",
        "user": user.to_dict()
    })

# =========================
# ✔ LOGIN（放這裡👇）
# =========================
@user_bp.route("/login", methods=["POST"])
def login():

    data = request.get_json()

    if not data:
        return jsonify({"error": "No input data"}), 400

    user = User.query.filter_by(username=data.get("username")).first()

    if not user:
        return jsonify({"error": "User not found"}), 404

    if not user.check_password(data.get("password")):
        return jsonify({"error": "Invalid password"}), 401

    # 🔥 產生 JWT Token
    #token = create_access_token(identity=user.id)
    token = create_access_token(identity=str(user.id))

    """
    return jsonify({
        "message": "Login successful",
        "token": token,
        "user": user.to_dict()
    })
    """
    
    return jsonify({
    "access_token": token,
    "role": user.role.upper().strip(),
    "user_id": user.id,
    "username": user.username
    })


# =========================
# ✔ 取得所有使用者（測試DB）
# =========================
@user_bp.route("/", methods=["GET"])
def get_users():

    users = User.query.all()

    return jsonify([
        user.to_dict()
        for user in users
    ])
