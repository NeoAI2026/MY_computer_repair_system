from flask import Blueprint, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity

from models.repair_ticket import RepairTicket
from database.base import db
from services.permissions import engineer_required

engineer_bp = Blueprint("engineer_bp", __name__)

@engineer_bp.route("/accept/<int:ticket_id>", methods=["POST"])
@jwt_required()
@engineer_required
def accept_ticket(ticket_id):

    user_id = get_jwt_identity()

    ticket = RepairTicket.query.get(ticket_id)

    if not ticket:
        return {"error": "Ticket not found"}, 404

    if ticket.engineer_id != user_id:
        return {"error": "Not assigned to you"}, 403

    ticket.status = "PROCESSING"

    db.session.commit()

    return {
        "message": "Ticket accepted"
    }