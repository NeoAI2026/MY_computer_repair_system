from flask_jwt_extended import jwt_required
from flask import Blueprint, request, jsonify
from models.repair_ticket import RepairTicket

@jwt_required()
def update_status(ticket_id):

    data = request.get_json()

    ticket = RepairTicket.query.get(ticket_id)

    ticket.status = data.get("status")

    db.session.commit()

    return {"message": "status updated"}