from flask_jwt_extended import jwt_required
from flask import Blueprint, request, jsonify
from models.repair_ticket import RepairTicket

from database.base import db

@jwt_required()
def update_status(ticket_id):

    data = request.get_json()

    ticket = RepairTicket.query.get(ticket_id)

    if not ticket:
        return {"error": "Ticket not found"}, 404

    old_status = ticket.status
    new_status = data.get("status")

    ticket.status = new_status

    db.session.commit()

    return {
        "message": "status updated",
        "from": old_status,
        "to": new_status
    }