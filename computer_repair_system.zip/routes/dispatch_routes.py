from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required

from models.repair_ticket import RepairTicket
from models.user import User
from database.base import db

from services.permissions import admin_required

dispatch_bp = Blueprint("dispatch_bp", __name__)

@dispatch_bp.route("/assign/<int:ticket_id>", methods=["POST"])
@jwt_required()
@admin_required
def assign_engineer(ticket_id):

    data = request.get_json()

    engineer_id = data.get("engineer_id")

    ticket = RepairTicket.query.get(ticket_id)

    if not ticket:
        return {"error": "Ticket not found"}, 404

    ticket.engineer_id = engineer_id
    ticket.status = "ASSIGNED"

    db.session.commit()

    return {
        "message": "Engineer assigned",
        "ticket_id": ticket.id,
        "engineer_id": engineer_id
    }