from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required

from database.base import db
from models.vendor import Vendor

vendor_bp = Blueprint("vendor_bp", __name__)

@vendor_bp.route("/", methods=["POST"])
@jwt_required()
def create_vendor():

    data = request.get_json()

    vendor = Vendor(
        company_name=data.get("company_name"),
        contact_name=data.get("contact_name"),
        phone=data.get("phone"),
        email=data.get("email"),
        address=data.get("address")
    )

    db.session.add(vendor)
    db.session.commit()

    return jsonify(vendor.to_dict())

@vendor_bp.route("/", methods=["GET"])
@jwt_required()
def get_vendors():

    vendors = Vendor.query.all()
    return jsonify([v.to_dict() for v in vendors])