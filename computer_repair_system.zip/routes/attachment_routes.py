import os
import uuid

from flask import Blueprint, request, jsonify, current_app
from flask_jwt_extended import jwt_required, get_jwt_identity
from werkzeug.utils import secure_filename

from database.base import db
from models.attachment import Attachment
from models.repair_ticket import RepairTicket

attachment_bp = Blueprint(
    "attachment_bp",
    __name__
)

ALLOWED_EXTENSIONS = {
    "png",
    "jpg",
    "jpeg",
    "gif",
    "pdf"
}


def allowed_file(filename):

    return (
        "." in filename and
        filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS
    )


@attachment_bp.route(
    "/<int:ticket_id>",
    methods=["POST"]
)
@jwt_required()
def upload_attachment(ticket_id):

    print("=" * 50)
    print("request.files =", request.files)
    print("request.form =", request.form)

    if "file" not in request.files:
        print("沒有 file")
        return jsonify({"error": "No file"}), 400

    file = request.files["file"]

    print("filename =", file.filename)
    print("content_type =", file.content_type)
    print("=" * 50)

    ticket = RepairTicket.query.get(ticket_id)

    if ticket is None:
        return jsonify({
            "error": "Ticket not found"
        }), 404

    if "file" not in request.files:
        return jsonify({
            "error": "No file"
        }), 400

    file = request.files["file"]

    if file.filename == "":
        return jsonify({
            "error": "Empty filename"
        }), 400

    if not allowed_file(file.filename):
        return jsonify({
            "error": "Unsupported file type"
        }), 400

    user_id = int(get_jwt_identity())

    ext = file.filename.rsplit(".", 1)[1].lower()

    new_filename = (
        str(uuid.uuid4()) +
        "." +
        ext
    )

    folder = os.path.join(
        current_app.config["UPLOAD_FOLDER"],
        "tickets",
        str(ticket_id)
    )

    os.makedirs(folder, exist_ok=True)

    filepath = os.path.join(
        folder,
        secure_filename(new_filename)
    )

    file.save(filepath)

    attachment = Attachment(
        ticket_id=ticket_id,
        file_name=file.filename,
        file_path=filepath,
        file_type=ext,
        mime_type=file.content_type,
        file_size=os.path.getsize(filepath),
        uploaded_by=user_id
    )

    db.session.add(attachment)
    db.session.commit()

    return jsonify({
        "message": "Upload success",
        "attachment": attachment.to_dict()
    })

@attachment_bp.route(
    "/ticket/<int:ticket_id>",
    methods=["GET"]
)
@jwt_required()
def list_attachment(ticket_id):

    files = Attachment.query.filter_by(
        ticket_id=ticket_id
    ).all()

    return jsonify([
        f.to_dict()
        for f in files
    ])