from database.base import db
from models.base_model import BaseModel


class RepairHistory(BaseModel):
    """
    工單生命週期紀錄（Workflow / Audit Trail）
    每一次狀態變更或維修動作都會記錄在這裡
    """

    __tablename__ = "repair_histories"

    # 所屬工單
    ticket_id = db.Column(
        db.Integer,
        db.ForeignKey("repair_tickets.id"),
        nullable=False,
        index=True
    )

    # 狀態變更
    status = db.Column(
        db.String(30),
        nullable=False
        # OPEN / PROCESSING / WAITING / DONE / CLOSED
    )

    # 操作內容（文字紀錄）
    content = db.Column(
        db.Text,
        nullable=True
    )

    # 維修結果（可選）
    repair_result = db.Column(
        db.Text,
        nullable=True
    )

    # 操作者（User）
    created_by = db.Column(
        db.Integer,
        db.ForeignKey("users.id"),
        nullable=False
    )

    # ========== relationships ==========

    # 對應工單
    ticket = db.relationship(
        "RepairTicket",
        backref="histories"
    )

    # 操作者（User）
    user = db.relationship(
        "User",
        back_populates="repair_histories",
        foreign_keys=[created_by]
    )

    def __repr__(self):
        return f"<RepairHistory ticket_id={self.ticket_id} status={self.status}>"

    def to_dict(self):
        return {
            "id": self.id,
            "ticket_id": self.ticket_id,
            "status": self.status,
            "content": self.content,
            "repair_result": self.repair_result,
            "created_by": self.created_by,
            "created_at": self.created_at
        }