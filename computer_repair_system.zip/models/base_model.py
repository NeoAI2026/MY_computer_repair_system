from database.base import db
from sqlalchemy.sql import func

class BaseModel(db.Model):

    __abstract__ = True

    id = db.Column(db.Integer, primary_key=True)

    created_at = db.Column(
        db.DateTime,
        server_default=func.now()
    )

    updated_at = db.Column(
        db.DateTime,
        server_default=func.now(),
        onupdate=func.now()
    )

    def to_dict(self):

        return {
            column.name: getattr(self, column.name)
            for column in self.__table__.columns
        }