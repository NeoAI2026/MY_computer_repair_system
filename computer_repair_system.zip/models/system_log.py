from database.base import db
from models.base_model import BaseModel


class SystemLog(BaseModel):
    """
    系統操作日誌（Audit / Security Log）
    記錄所有重要操作：登入、修改、刪除、建立工單等
    """

    __tablename__ = "system_logs"

    # 操作使用者
    user_id = db.Column(
        db.Integer,
        db.ForeignKey("users.id"),
        nullable=True,
        index=True
    )

    # 操作類型
    action = db.Column(
        db.String(100),
        nullable=False,
        index=True
        # LOGIN / CREATE / UPDATE / DELETE / UPLOAD / ASSIGN ...
    )

    # 詳細內容（JSON 或文字）
    detail = db.Column(
        db.Text,
        nullable=True
    )

    # IP 位址（未來 API / Web 追蹤用）
    ip_address = db.Column(
        db.String(50),
        nullable=True
    )

    # User Agent（瀏覽器 / API client）
    user_agent = db.Column(
        db.String(255),
        nullable=True
    )

    # ========= relationships =========

    user = db.relationship(
        "User",
        back_populates="logs"
    )

    def __repr__(self):
        return f"<SystemLog user_id={self.user_id} action={self.action}>"

    def to_dict(self):
        return {
            "id": self.id,
            "user_id": self.user_id,
            "action": self.action,
            "detail": self.detail,
            "ip_address": self.ip_address,
            "user_agent": self.user_agent,
            "created_at": self.created_at
        }