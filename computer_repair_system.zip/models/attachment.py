from datetime import datetime

from database.base import db
from models.base_model import BaseModel


class Attachment(BaseModel):
    """
    工單附件（圖片 / PDF / 文件）
    """

    __tablename__ = "attachments"

    # 所屬工單
    ticket_id = db.Column(
        db.Integer,
        db.ForeignKey("repair_tickets.id"),
        nullable=False,
        index=True
    )

    # 原始檔案名稱
    file_name = db.Column(
        db.String(255),
        nullable=False
    )

    # 儲存路徑
    file_path = db.Column(
        db.String(500),
        nullable=False
    )

    # 檔案類型（image/pdf/other）
    file_type = db.Column(
        db.String(50),
        nullable=True
    )

    # MIME type
    mime_type = db.Column(
        db.String(100),
        nullable=True
    )

    # 檔案大小（bytes）
    file_size = db.Column(
        db.Integer,
        nullable=True
    )

    # 上傳者（User）
    uploaded_by = db.Column(
        db.Integer,
        db.ForeignKey("users.id"),
        nullable=False
    )

    uploaded_at = db.Column(
        db.DateTime,
        default=datetime.utcnow
    )

    # ========= relationships =========

    # 對應工單
    ticket = db.relationship(
        "RepairTicket",
        backref="attachments"
    )

    # 上傳者
    user = db.relationship(
        "User",
        backref="uploaded_files"
    )

    def __repr__(self):
        return f"<Attachment {self.file_name}>"

    def to_dict(self):
        return {
            "id": self.id,
            "ticket_id": self.ticket_id,
            "file_name": self.file_name,
            "file_path": self.file_path,
            "file_type": self.file_type,
            "mime_type": self.mime_type,
            "file_size": self.file_size,
            "uploaded_by": self.uploaded_by,
            "uploaded_at": self.uploaded_at
        }