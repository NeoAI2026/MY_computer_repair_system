from datetime import datetime

from database.base import db
from models.base_model import BaseModel


class RepairTicket(BaseModel):
    """
    維修工單（核心表）
    """

    __tablename__ = "repair_tickets"

    ticket_no = db.Column(
        db.String(50),
        unique=True,
        nullable=False,
        index=True
    )

    title = db.Column(
        db.String(200),
        nullable=False
    )

    description = db.Column(
        db.Text,
        nullable=True
    )

    device_type = db.Column(
        db.String(50),
        nullable=True
    )

    device_brand = db.Column(
        db.String(50),
        nullable=True
    )

    device_model = db.Column(
        db.String(50),
        nullable=True
    )

    serial_number = db.Column(
        db.String(100),
        nullable=True
    )

    priority = db.Column(
        db.String(20),
        default="NORMAL"
        # LOW / NORMAL / HIGH / URGENT
    )

    status = db.Column(
        db.String(20),
        default="OPEN"
        # OPEN / PROCESSING / WAITING / DONE / CLOSED
    )

    # 外鍵：建立者（User）
    creator_id = db.Column(
        db.Integer,
        db.ForeignKey("users.id"),
        nullable=False
    )

    # 外鍵：指派工程師（先保留，未來可擴充 ENGINEER ROLE）
    engineer_id = db.Column(
        db.Integer,
        db.ForeignKey("users.id"),
        nullable=True
    )

    # 外鍵：廠商
    vendor_id = db.Column(
        db.Integer,
        db.ForeignKey("vendors.id"),
        nullable=True
    )

    # 關聯：建立者
    creator = db.relationship(
        "User",
        foreign_keys=[creator_id],
        back_populates="repair_tickets"
    )

    # 關聯：工程師（同 User 表）
    engineer = db.relationship(
        "User",
        foreign_keys=[engineer_id],
        backref="assigned_tickets"
    )

    # 關聯：廠商
    vendor = db.relationship(
        "Vendor",
        back_populates="repair_tickets"
    )

    def __repr__(self):
        return f"<RepairTicket {self.ticket_no}>"

    def to_dict(self):
        return {
            "id": self.id,
            "ticket_no": self.ticket_no,
            "title": self.title,
            "description": self.description,
            "device_type": self.device_type,
            "device_brand": self.device_brand,
            "device_model": self.device_model,
            "serial_number": self.serial_number,
            "priority": self.priority,
            "status": self.status,
            "creator_id": self.creator_id,
            "engineer_id": self.engineer_id,
            "vendor_id": self.vendor_id,
            "created_at": self.created_at,
            "updated_at": self.updated_at
        }