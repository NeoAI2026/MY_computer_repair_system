from database.base import db
from models.base_model import BaseModel


class Vendor(BaseModel):
    """
    廠商資料
    """

    __tablename__ = "vendors"

    company_name = db.Column(
        db.String(120),
        nullable=False,
        index=True
    )

    contact_name = db.Column(
        db.String(100),
        nullable=False
    )

    phone = db.Column(
        db.String(30),
        nullable=False
    )

    email = db.Column(
        db.String(120),
        nullable=True
    )

    address = db.Column(
        db.String(255),
        nullable=True
    )

    note = db.Column(
        db.Text,
        nullable=True
    )

    status = db.Column(
        db.Boolean,
        default=True
    )

    # 一個廠商可以對應多張維修單
    repair_tickets = db.relationship(
        "RepairTicket",
        back_populates="vendor",
        lazy=True
    )

    def __repr__(self):
        return f"<Vendor {self.company_name}>"

    def to_dict(self):
        return {
            "id": self.id,
            "company_name": self.company_name,
            "contact_name": self.contact_name,
            "phone": self.phone,
            "email": self.email,
            "address": self.address,
            "note": self.note,
            "status": self.status,
            "created_at": self.created_at,
            "updated_at": self.updated_at
        }