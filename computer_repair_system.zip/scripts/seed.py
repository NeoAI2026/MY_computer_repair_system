import sys
import os

# 👉 讓 scripts 可以 import app
sys.path.append(os.path.dirname(os.path.dirname(__file__)))

from app import app
from database.base import db
from models.user import User


def create_user(username, name, email, password, role):

    existing = User.query.filter_by(username=username).first()

    if existing:
        print(f"[SKIP] {username} already exists")
        return existing

    user = User(
        username=username,
        name=name,
        email=email,
        role=role.upper().strip()
    )

    user.set_password(password)

    db.session.add(user)
    db.session.commit()

    print(f"[OK] Created user: {username}")
    return user


def seed_data():

    print("🚀 Starting DEV-08 Seed System...")

    # =========================
    # 1️⃣ ADMIN
    # =========================
    admin = create_user(
        username="admin",
        name="System Admin",
        email="admin@system.com",
        password="admin123",
        role="ADMIN"
    )

    # =========================
    # 2️⃣ ENGINEER
    # =========================
    engineer = create_user(
        username="engineer1",
        name="Tech Engineer",
        email="eng1@system.com",
        password="eng123",
        role="ENGINEER"
    )

    # =========================
    # 3️⃣ USER
    # =========================
    user = create_user(
        username="user1",
        name="Normal User",
        email="user1@system.com",
        password="user123",
        role="USER"
    )

    print("\n✅ Seed completed successfully!")
    print("Login accounts:")
    print("ADMIN: admin / admin123")
    print("ENGINEER: engineer1 / eng123")
    print("USER: user1 / user123")


if __name__ == "__main__":

    with app.app_context():

        db.create_all()  # 保險：確保 table 存在

        seed_data()