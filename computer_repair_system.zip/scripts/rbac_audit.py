import os
import re
import sys

sys.path.append(os.path.dirname(os.path.dirname(__file__)))

from services.rbac import ROLE_PERMISSIONS


ROUTES_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "routes")


# 解析 permission_required("xxx")
pattern = re.compile(r'permission_required\(["\'](.*?)["\']\)')


def scan_files():

    results = []

    for root, _, files in os.walk(ROUTES_DIR):

        for file in files:

            if not file.endswith(".py"):
                continue

            path = os.path.join(root, file)

            with open(path, "r", encoding="utf-8") as f:
                content = f.read()

            matches = pattern.findall(content)

            for m in matches:
                results.append((path, m))

    return results


def audit():

    print("\n🚀 RBAC AUDIT START\n")

    used_permissions = scan_files()

    defined_permissions = set()

    for role, perms in ROLE_PERMISSIONS.items():
        defined_permissions.update(perms)

    undefined = []

    for file, perm in used_permissions:

        if perm not in defined_permissions:
            undefined.append((file, perm))

    print("===================================")
    print("📌 USED PERMISSIONS IN ROUTES:")
    print("===================================")

    for file, perm in used_permissions:
        print(f"{perm}  ->  {file}")

    print("\n===================================")
    print("❌ UNDEFINED PERMISSIONS:")
    print("===================================")

    if not undefined:
        print("✅ No issues found")
    else:
        for file, perm in undefined:
            print(f"❌ {perm}  ->  {file}")

    print("\n===================================")
    print("📊 SUMMARY")
    print("===================================")
    print(f"Total used permissions: {len(used_permissions)}")
    print(f"Undefined permissions: {len(undefined)}")


if __name__ == "__main__":
    audit()