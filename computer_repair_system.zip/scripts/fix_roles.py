import sys
import os

sys.path.append(os.path.dirname(os.path.dirname(__file__)))

from app import app
from database.base import db
from models.user import User

with app.app_context():

    users = User.query.all()

    for u in users:
        if u.role:
            u.role = u.role.upper().strip()
        else:
            u.role = "USER"

    db.session.commit()

    print("✅ Role normalization completed")