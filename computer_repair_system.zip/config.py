import os

BASE_DIR = os.path.abspath(os.path.dirname(__file__))

class Config:

    SECRET_KEY = "computer_repair_secret_key"
    JWT_SECRET_KEY = (
    "ComputerRepairSystemJWTSecretKey2026!@#$"
    )

    SQLALCHEMY_DATABASE_URI = \
        "sqlite:///" + os.path.join(
            BASE_DIR,
            "database",
            "db.sqlite3"
        )

    SQLALCHEMY_TRACK_MODIFICATIONS = False

    UPLOAD_FOLDER = os.path.join(
        BASE_DIR,
        "uploads"
    )

    REPORT_FOLDER = os.path.join(
        BASE_DIR,
        "reports"
    )

    MAX_CONTENT_LENGTH = 50 * 1024 * 1024
