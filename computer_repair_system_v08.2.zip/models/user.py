from datetime import datetime

from database.base import db


class User(db.Model):

    __tablename__ = "users"


    id = db.Column(
        db.Integer,
        primary_key=True
    )


    username = db.Column(
        db.String(50),
        unique=True,
        nullable=False,
        index=True
    )


    email = db.Column(
        db.String(120),
        unique=True
    )


    password_hash = db.Column(
        db.String(255),
        nullable=False
    )


    real_name = db.Column(
        db.String(50)
    )


    phone = db.Column(
        db.String(30)
    )


    role_id = db.Column(
        db.Integer,
        db.ForeignKey(
            "roles.id"
        ),
        nullable=False
    )


    is_active = db.Column(
        db.Boolean,
        default=True
    )


    created_at = db.Column(
        db.DateTime,
        default=datetime.utcnow
    )


    updated_at = db.Column(
        db.DateTime,
        default=datetime.utcnow,
        onupdate=datetime.utcnow
    )



    # ==================================================
    # Relationship
    # ==================================================


    # User -> Role

    role = db.relationship(

        "Role",

        back_populates="users"

    )



    # User -> Assigned Repair Tickets

    assigned_tickets = db.relationship(

        "RepairTicket",

        foreign_keys="RepairTicket.engineer_id",

        back_populates="engineer"

    )



    # User -> Repair History

    repair_histories = db.relationship(

        "RepairHistory",

        back_populates="user"

    )


    # =========================
    # 建立案件者
    # =========================

    created_tickets = db.relationship(

        "RepairTicket",

        foreign_keys="RepairTicket.creator_id",

        back_populates="creator"

    )



    # =========================
    # 負責工程師
    # =========================

    assigned_tickets = db.relationship(

        "RepairTicket",

        foreign_keys="RepairTicket.engineer_id",

        back_populates="engineer"

    )



    def __repr__(self):

        return f"<User {self.username}>"



    # 密碼設定

    def set_password(self, password):

        from werkzeug.security import generate_password_hash

        self.password_hash = generate_password_hash(
            password
        )



    # 密碼驗證

    def check_password(self, password):

        from werkzeug.security import check_password_hash

        return check_password_hash(

            self.password_hash,

            password

        )
