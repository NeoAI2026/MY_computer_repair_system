from datetime import datetime

from database.base import db

from models.repair_ticket import RepairTicket
from models.repair_history import RepairHistory
#from models.repair_status import RepairStatus



class WorkflowService:
    """
    CRMS 維修流程服務
    """


    # -----------------------------
    # 狀態流程規則
    # -----------------------------

    STATUS_FLOW = {


        "new": [

            "wait_assign"

        ],


        "wait_assign": [

            "assigned"

        ],


        "assigned": [

            "checking"

        ],


        "checking": [

            "quotation",

            "repairing"

        ],


        "quotation": [

            "repairing"

        ],


        "repairing": [

            "testing"

        ],


        "testing": [

            "completed"

        ],


        "completed": [

            "customer_check"

        ],


        "customer_check": [

            "closed"

        ],


        "closed": []

    }



    # -----------------------------
    # 驗證狀態轉換
    # -----------------------------

    @staticmethod
    def validate_transition(
        old_status,
        new_status
    ):


        allowed = WorkflowService.STATUS_FLOW.get(
            old_status,
            []
        )


        return new_status in allowed



    # -----------------------------
    # 建立維修歷程
    # -----------------------------

    @staticmethod
    def create_history(
        ticket,
        old_status,
        new_status,
        operator_id=None,
        remark=None
    ):


        history = RepairHistory(

            ticket_id=ticket.id,

            old_status=old_status,

            new_status=new_status,

            operator_id=operator_id,

            remark=remark

        )


        db.session.add(history)


        return history



    # -----------------------------
    # 修改維修狀態
    # -----------------------------

    @staticmethod
    def change_status(
        ticket,
        new_status,
        operator_id=None,
        remark=None
    ):


        old_status = ticket.status


        if not WorkflowService.validate_transition(
            old_status,
            new_status
        ):

            raise Exception(
                f"Invalid workflow: {old_status} -> {new_status}"
            )



        ticket.status = new_status



        WorkflowService.create_history(

            ticket,

            old_status,

            new_status,

            operator_id,

            remark

        )


        db.session.commit()


        return ticket



    # -----------------------------
    # 指派工程師
    # -----------------------------

    @staticmethod
    def assign_engineer(
        ticket,
        engineer_id,
        operator_id=None
    ):


        ticket.engineer_id = engineer_id



        old_status = ticket.status



        if old_status == "NEW":

            ticket.status = "WAIT_ASSIGN"


        db.session.commit()


        return ticket