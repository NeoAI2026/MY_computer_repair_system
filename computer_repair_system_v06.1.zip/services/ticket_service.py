from datetime import datetime

from database.base import db

from models.customer import Customer
from models.device import Device
from models.repair_ticket import RepairTicket
from models.repair_history import RepairHistory


class TicketService:


    @staticmethod
    def create_ticket(

        customer_name,

        customer_phone,

        customer_email,


        device_type,

        brand,

        model,

        serial_number,


        title,

        description,


        priority="normal",

        category="other"

    ):


        # =====================
        # 1. Customer
        # =====================

        customer = Customer(

            name=customer_name,

            phone=customer_phone,

            email=customer_email

        )


        db.session.add(customer)

        db.session.flush()



        # =====================
        # 2. Device
        # =====================

        device = Device(

            customer_id=customer.id,

            device_type=device_type,

            brand=brand,

            model=model,

            serial_number=serial_number

        )


        db.session.add(device)

        db.session.flush()



        # =====================
        # 3. Repair Ticket
        # =====================

        ticket = RepairTicket(

            ticket_no=TicketService.generate_ticket_no(),


            customer_id=customer.id,

            device_id=device.id,


            title=title,

            description=description,


            status="new",


            priority=priority,

            category=category,


            workflow_started_at=datetime.utcnow()

        )


        db.session.add(ticket)

        db.session.flush()



        # =====================
        # 4. Initial History
        # =====================

        history = RepairHistory(

            ticket_id=ticket.id,


            old_status=None,

            new_status="new",


            remark="建立維修案件",


            created_at=datetime.utcnow()

        )


        db.session.add(history)



        db.session.commit()



        return ticket



    @staticmethod
    def generate_ticket_no():

        import uuid

        return "TK-" + uuid.uuid4().hex[:8].upper()


"""
from datetime import datetime
from database import db

from models.repair_ticket import RepairTicket
from models.customer import Customer
from models.device import Device



class TicketService:


    @staticmethod
    def create_ticket(data):

        ticket = RepairTicket(

            ticket_no=TicketService.generate_ticket_no(),

            customer_id=data.get(
                "customer_id"
            ),

            device_id=data.get(
                "device_id"
            ),

            title=data.get(
                "title"
            ),

            description=data.get(
                "description"
            ),

            status="new",

            priority=data.get(
                "priority",
                "normal"
            )

        )


        db.session.add(ticket)

        db.session.commit()


        return ticket



    @staticmethod
    def get_ticket(ticket_id):

        return RepairTicket.query.get(
            ticket_id
        )



    @staticmethod
    def get_all():

        return RepairTicket.query.order_by(
            RepairTicket.id.desc()
        ).all()



    @staticmethod
    def update_ticket(ticket, data):


        if "title" in data:

            ticket.title = data["title"]


        if "description" in data:

            ticket.description = data["description"]


        if "priority" in data:

            ticket.priority = data["priority"]


        ticket.updated_at = datetime.utcnow()


        db.session.commit()


        return ticket



    @staticmethod
    def close_ticket(ticket):

        ticket.status = "closed"

        ticket.updated_at = datetime.utcnow()


        db.session.commit()


        return ticket



    @staticmethod
    def generate_ticket_no():

        import uuid

        return (
            "TK-"
            +
            uuid.uuid4()
            .hex[:8]
            .upper()
        )
"""