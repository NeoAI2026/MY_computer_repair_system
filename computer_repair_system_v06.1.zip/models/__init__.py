from models.user import User
from models.role import Role
from models.permission import Permission

from models.customer import Customer
from models.device import Device

from models.repair_ticket import RepairTicket
from models.repair_history import RepairHistory
from models.attachment import Attachment
from models.repair_status import RepairStatus

from models.quotation import Quotation
from models.quotation_item import QuotationItem


#from models.part import Part
#from models.inventory import Inventory

#from models.system_log import SystemLog

