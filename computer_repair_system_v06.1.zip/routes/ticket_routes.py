from flask import Blueprint, request, jsonify

from services.ticket_service import TicketService


ticket_bp = Blueprint(
    "ticket",
    __name__,
    url_prefix="/api/tickets"
)



# =========================
# Create Ticket
# =========================

@ticket_bp.route(
    "",
    methods=["POST"]
)
def create_ticket():


    data = request.json


    ticket = TicketService.create_ticket(
        data
    )


    return jsonify({

        "message":
            "ticket created",

        "ticket_id":
            ticket.id,

        "ticket_no":
            ticket.ticket_no

    }),201




# =========================
# List Tickets
# =========================

@ticket_bp.route(
    "",
    methods=["GET"]
)
def list_ticket():


    tickets = TicketService.get_all()


    return jsonify([

        {

        "id":t.id,

        "ticket_no":
            t.ticket_no,

        "status":
            t.status,

        "title":
            t.title

        }

        for t in tickets

    ])





# =========================
# Ticket Detail
# =========================

@ticket_bp.route(
    "/<int:ticket_id>",
    methods=["GET"]
)
def get_ticket(ticket_id):


    ticket = TicketService.get_ticket(
        ticket_id
    )


    if not ticket:

        return jsonify({

            "error":
            "ticket not found"

        }),404



    return jsonify({

        "id":
            ticket.id,

        "ticket_no":
            ticket.ticket_no,

        "status":
            ticket.status,

        "title":
            ticket.title,

        "description":
            ticket.description

    })





# =========================
# Update Ticket
# =========================

@ticket_bp.route(
    "/<int:ticket_id>",
    methods=["PUT"]
)
def update_ticket(ticket_id):


    ticket = TicketService.get_ticket(
        ticket_id
    )


    if not ticket:

        return jsonify({
            "error":
            "ticket not found"
        }),404



    ticket = TicketService.update_ticket(

        ticket,

        request.json

    )


    return jsonify({

        "message":
        "ticket updated"

    })





# =========================
# Close Ticket
# =========================

@ticket_bp.route(
    "/<int:ticket_id>/close",
    methods=["POST"]
)
def close_ticket(ticket_id):


    ticket = TicketService.get_ticket(
        ticket_id
    )


    if not ticket:

        return jsonify({

            "error":
            "ticket not found"

        }),404



    TicketService.close_ticket(
        ticket
    )


    return jsonify({

        "message":
        "ticket closed"

    })