from flask import Flask

from config import Config

from database.base import db

from routes.workflow_routes import workflow_bp
from routes.ticket_routes import ticket_bp
from routes.history_routes import history_bp

def create_app():

    app=Flask(__name__)


    app.config.from_object(
        Config
    )

    app.register_blueprint(
        workflow_bp
    )

    app.register_blueprint(
        ticket_bp
    )

    app.register_blueprint(
        history_bp
    )

    db.init_app(app)


    return app



app=create_app()



@app.route("/")
def index():

    return "CRMS System Running"



if __name__=="__main__":
    
    app.run(
        debug=True
    )