from database.base import db

class User(db.Model):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)

    username = db.Column(db.String(80), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)

    role = db.Column(db.String(20), default="user")

    # 使用者建立的維修單
    repair_tickets = db.relationship(
        "RepairTicket",
        foreign_keys="RepairTicket.user_id",
        backref="customer",
        lazy=True
    )

    # 工程師負責的維修單
    assigned_tickets = db.relationship(
        "RepairTicket",
        foreign_keys="RepairTicket.engineer_id",
        backref="engineer",
        lazy=True
    )