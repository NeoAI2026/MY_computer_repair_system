from flask import Flask, redirect
from config import Config
from database.base import db

from routes.auth_routes import auth_bp
from routes.dashboard_routes import dashboard_bp
from routes.ticket_routes import ticket_bp

app = Flask(__name__)
app.config.from_object(Config)

db.init_app(app)

# Blueprint 註冊
app.register_blueprint(auth_bp, url_prefix="/auth")
app.register_blueprint(dashboard_bp, url_prefix="/dashboard")
app.register_blueprint(ticket_bp, url_prefix="/ticket")


# 🔥 入口直接導向登入
@app.route("/")
def index():
    return redirect("/auth/login")


if __name__ == "__main__":
    with app.app_context():
        db.create_all()

    app.run(debug=True)