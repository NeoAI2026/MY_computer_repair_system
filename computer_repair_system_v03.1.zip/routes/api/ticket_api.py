from flask import Blueprint, request, jsonify
from models.repair_ticket import RepairTicket
from database.base import db
from sockets.socket_events import emit_ticket_update

ticket_api = Blueprint("ticket_api", __name__)


@ticket_api.route("/update", methods=["POST"])
def update_ticket():
    data = request.json

    ticket = RepairTicket.query.get(data["ticket_id"])
    ticket.status = data["status"]

    db.session.commit()

    # 🔥 即時通知
    emit_ticket_update({
        "ticket_id": ticket.id,
        "status": ticket.status
    })

    return jsonify({"message": "updated"})