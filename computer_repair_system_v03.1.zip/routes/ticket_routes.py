from flask import Blueprint, request, session, redirect, render_template
from models.repair_ticket import RepairTicket
from database.base import db

ticket_bp = Blueprint("ticket", __name__)

# =========================
# CREATE（你已經有）
# =========================
@ticket_bp.route("/create", methods=["POST"])
def create():

    if "user_id" not in session:
        return redirect("/auth/login")

    title = request.form["title"]
    desc = request.form["description"]

    ticket = RepairTicket(
        title=title,
        description=desc,
        user_id=session["user_id"]
    )

    db.session.add(ticket)
    db.session.commit()

    return redirect("/dashboard/user")


# =========================
# DETAIL（查看）
# =========================
@ticket_bp.route("/<int:ticket_id>")
def view(ticket_id):

    if "user_id" not in session:
        return redirect("/auth/login")

    ticket = RepairTicket.query.get_or_404(ticket_id)

    # 權限：user只能看自己的
    if session["role"] == "user":
        if ticket.user_id != session["user_id"]:
            return "403 Forbidden", 403

    return render_template("ticket_detail.html", ticket=ticket)


# =========================
# EDIT（編輯頁）
# =========================
@ticket_bp.route("/edit/<int:ticket_id>", methods=["GET", "POST"])
def edit(ticket_id):

    if "user_id" not in session:
        return redirect("/auth/login")

    ticket = RepairTicket.query.get_or_404(ticket_id)

    # 權限
    if session["role"] == "user":
        if ticket.user_id != session["user_id"]:
            return "403 Forbidden", 403

    # GET → 顯示編輯頁
    if request.method == "GET":
        return render_template("ticket_edit.html", ticket=ticket)

    # POST → 更新資料
    ticket.title = request.form["title"]
    ticket.description = request.form["description"]

    # admin / engineer 可以改狀態
    if session["role"] in ["admin", "engineer"]:
        ticket.status = request.form.get("status", ticket.status)

    db.session.commit()

    return redirect(f"/ticket/{ticket.id}")


# =========================
# DELETE（刪除）
# =========================
@ticket_bp.route("/delete/<int:ticket_id>")
def delete(ticket_id):

    if "user_id" not in session:
        return redirect("/auth/login")

    ticket = RepairTicket.query.get_or_404(ticket_id)

    # 權限
    if session["role"] == "user":
        if ticket.user_id != session["user_id"]:
            return "403 Forbidden", 403

    db.session.delete(ticket)
    db.session.commit()

    return redirect("/dashboard/user")

from models.user import User

@ticket_bp.route("/assign/<int:ticket_id>", methods=["GET", "POST"])
def assign(ticket_id):

    if "user_id" not in session:
        return redirect("/auth/login")

    if session["role"] != "admin":
        return "403 Forbidden", 403

    ticket = RepairTicket.query.get_or_404(ticket_id)
    engineers = User.query.filter_by(role="engineer").all()

    if request.method == "GET":
        return render_template(
            "ticket_assign.html",
            ticket=ticket,
            engineers=engineers
        )

    ticket.engineer_id = request.form["engineer_id"]
    ticket.status = "assigned"

    db.session.commit()

    return redirect("/dashboard/admin")

@ticket_bp.route("/accept/<int:ticket_id>")
def accept(ticket_id):

    if "user_id" not in session:
        return redirect("/auth/login")

    if session["role"] != "engineer":
        return "403 Forbidden", 403

    ticket = RepairTicket.query.get_or_404(ticket_id)

    if ticket.engineer_id != session["user_id"]:
        return "不是指派給你的任務", 403

    ticket.status = "processing"

    db.session.commit()

    return redirect("/dashboard/engineer")

@ticket_bp.route("/done/<int:ticket_id>")
def done(ticket_id):

    if session.get("role") != "engineer":
        return "403 Forbidden", 403

    ticket = RepairTicket.query.get_or_404(ticket_id)

    if ticket.engineer_id != session.get("user_id"):
        return "不是你的案件", 403

    ticket.status = "done"
    db.session.commit()

    return redirect("/dashboard/engineer")

# 👇 放在 create / assign / done 這些 function「下面」

@ticket_bp.route("/verify/<int:ticket_id>")
def verify(ticket_id):

    if session.get("role") != "admin":
        return "403 Forbidden", 403

    ticket = RepairTicket.query.get_or_404(ticket_id)

    if ticket.status != "done":
        return "還沒完工不能驗收", 400

    ticket.status = "verified"
    db.session.commit()

    return redirect("/dashboard/admin")


@ticket_bp.route("/close/<int:ticket_id>")
def close(ticket_id):

    if session.get("role") != "admin":
        return "403 Forbidden", 403

    ticket = RepairTicket.query.get_or_404(ticket_id)

    if ticket.status != "verified":
        return "尚未驗收", 400

    ticket.status = "closed"
    db.session.commit()

    return redirect("/dashboard/admin")