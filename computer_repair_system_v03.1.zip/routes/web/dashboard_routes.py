from flask import Blueprint, render_template, session, redirect
from models.repair_ticket import RepairTicket



dashboard_bp = Blueprint("dashboard", __name__)  # 🔥 一定要在最外層

@dashboard_bp.route("/admin")
def admin_dashboard():

    if "user_id" not in session:
        return redirect("/auth/login")

    if session["role"] != "admin":
        return "403 Forbidden", 403

    return render_template("admin_dashboard.html")

from flask import render_template, session, redirect
from models.repair_ticket import RepairTicket

@dashboard_bp.route("/engineer")
def engineer_dashboard():

    if "user_id" not in session:
        return redirect("/auth/login")

    tickets = RepairTicket.query.filter_by(
        engineer_id=session["user_id"]
    ).all()

    return render_template(
        "dashboard_engineer.html",
        tickets=tickets
    )

@dashboard_bp.route("/user")
def user_dashboard():

    if "user_id" not in session:
        return redirect("/auth/login")

    tickets = RepairTicket.query.filter_by(
        user_id=session["user_id"]
    ).order_by(
        RepairTicket.id.desc()
    ).all()

    return render_template(
        "dashboard_user.html",
        tickets=tickets
    )