from flask import Blueprint, render_template, session, redirect
from models.repair_ticket import RepairTicket
dashboard_bp = Blueprint("dashboard", __name__)

# 🔧 Engineer
@dashboard_bp.route("/engineer")
def engineer():

    if "user_id" not in session:
        return redirect("/auth/login")

    tickets = RepairTicket.query.filter_by(engineer_id=session["user_id"]).all()
    return render_template("dashboard_engineer.html", tickets=tickets)