from flask import Blueprint, render_template, session, redirect
from models.repair_ticket import RepairTicket

dashboard_bp = Blueprint("dashboard", __name__)


# 🔐 Admin
@dashboard_bp.route("/admin")
def admin():

    if "user_id" not in session:
        return redirect("/auth/login")

    if session["role"] != "admin":
        return "403 Forbidden", 403

    tickets = RepairTicket.query.all()
    return render_template("dashboard_admin.html", tickets=tickets)


# 🔧 Engineer
@dashboard_bp.route("/engineer")
def engineer():

    if "user_id" not in session:
        return redirect("/auth/login")

    tickets = RepairTicket.query.filter_by(engineer_id=session["user_id"]).all()
    return render_template("dashboard_engineer.html", tickets=tickets)


# 👤 User
@dashboard_bp.route("/user")
def user():

    if "user_id" not in session:
        return redirect("/auth/login")

    tickets = RepairTicket.query.filter_by(user_id=session["user_id"]).all()
    return render_template("dashboard_user.html", tickets=tickets)