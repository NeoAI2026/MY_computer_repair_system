from app import app
from database.base import db
from models.user import User

with app.app_context():
    db.create_all()

    # 如果資料庫沒有使用者，就建立測試帳號
    if User.query.count() == 0:

        admin = User(username="admin", password="1234", role="admin")
        engineer = User(username="eng", password="1234", role="engineer")
        user = User(username="user", password="1234", role="user")

        db.session.add(admin)
        db.session.add(engineer)
        db.session.add(user)

        db.session.commit()

    print("✅ 初始化完成")