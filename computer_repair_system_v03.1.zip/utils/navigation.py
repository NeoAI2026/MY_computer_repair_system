def get_dashboard_url(role):
    if role == "admin":
        return "/dashboard/admin"
    elif role == "engineer":
        return "/dashboard/engineer"
    else:
        return "/dashboard/user"