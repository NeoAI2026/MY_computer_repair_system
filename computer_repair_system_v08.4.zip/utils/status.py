STATUS_MAP = {

    "new":"新案件",

    "wait_assign":"等待派工",

    "assigned":"已派工",

    "checking":"檢測中",

    "quotation":"報價中",

    "repairing":"維修中",

    "testing":"測試中",

    "completed":"完成",

    "closed":"結案"

}


def status_text(status):

    return STATUS_MAP.get(
        status,
        status
    )