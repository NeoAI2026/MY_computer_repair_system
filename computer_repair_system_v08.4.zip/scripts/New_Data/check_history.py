from app import create_app

from models.repair_history import RepairHistory


app = create_app()


with app.app_context():

    histories = RepairHistory.query.all()


    print("================")
    print("REPAIR HISTORY")
    print("================")


    for h in histories:

        print(
            "ID:",
            h.id,
            "Ticket:",
            h.ticket_id,
            "OLD:",
            h.old_status,
            "NEW:",
            h.new_status,
            "USER:",
            h.user_id
        )