from app import create_app

from models.repair_ticket import RepairTicket
from services.workflow_service import WorkflowService


app = create_app()


with app.app_context():

    ticket = RepairTicket.query.first()


    print("================")
    print("BEFORE")
    print(ticket.id)
    print(ticket.status)
    print(ticket.assigned_engineer_id)


    WorkflowService.assign_engineer(
        ticket,
        engineer_id=2,
        operator_id=1
    )


    print("================")
    print("AFTER")
    print(ticket.status)
    print(ticket.assigned_engineer_id)