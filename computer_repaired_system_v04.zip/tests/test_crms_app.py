import pytest

from app import app as flask_app
from database.base import db
from database.init_db import init_default_users
from models.repair_ticket import RepairTicket
from models.user import User


@pytest.fixture
def client():
    flask_app.config.update(TESTING=True, SQLALCHEMY_DATABASE_URI="sqlite:///:memory:")
    with flask_app.app_context():
        db.drop_all()
        db.create_all()
        yield flask_app.test_client()
        db.session.remove()
        db.drop_all()


def test_init_default_users_creates_three_accounts(client):
    with flask_app.app_context():
        init_default_users(flask_app)
        users = User.query.order_by(User.username).all()

    usernames = [user.username for user in users]
    assert usernames == ["admin", "eng", "user"]
    assert {user.username: user.password for user in users} == {
        "admin": "1234",
        "eng": "1234",
        "user": "1234",
    }


def test_user_dashboard_renders_create_ticket_form(client):
    with flask_app.app_context():
        init_default_users(flask_app)

    response = client.post(
        "/auth/login",
        data={"username": "user", "password": "1234"},
        follow_redirects=True,
    )

    assert response.status_code == 200
    html = response.get_data(as_text=True)
    assert "建立報修單" in html
    assert 'name="title"' in html
    assert 'name="description"' in html


def test_admin_dashboard_renders_assignment_controls(client):
    with flask_app.app_context():
        init_default_users(flask_app)
        db.session.add(
            RepairTicket(
                title="測試報修",
                description="測試描述",
                user_id=User.query.filter_by(username="user").first().id,
            )
        )
        db.session.commit()

    response = client.post(
        "/auth/login",
        data={"username": "admin", "password": "1234"},
        follow_redirects=True,
    )

    assert response.status_code == 200
    html = response.get_data(as_text=True)
    assert "派工" in html
    assert "測試報修" in html


def test_admin_can_assign_ticket_to_engineer(client):
    with flask_app.app_context():
        init_default_users(flask_app)
        engineer = User.query.filter_by(username="eng").first()
        user = User.query.filter_by(username="user").first()
        ticket = RepairTicket(title="派工測試", description="描述", user_id=user.id)
        db.session.add(ticket)
        db.session.commit()

    response = client.post(
        "/auth/login",
        data={"username": "admin", "password": "1234"},
        follow_redirects=True,
    )
    assert response.status_code == 200

    with flask_app.app_context():
        ticket_id = RepairTicket.query.filter_by(title="派工測試").first().id
        engineer_id = User.query.filter_by(username="eng").first().id

    response = client.post(
        "/ticket/assign",
        data={"ticket_id": ticket_id, "engineer_id": engineer_id},
        follow_redirects=True,
    )

    assert response.status_code == 200
    with flask_app.app_context():
        updated_ticket = RepairTicket.query.get(ticket_id)
        assert updated_ticket.engineer_id == engineer_id
        assert updated_ticket.status == "processing"


def test_engineer_can_update_ticket_status(client):
    with flask_app.app_context():
        init_default_users(flask_app)
        user = User.query.filter_by(username="user").first()
        engineer = User.query.filter_by(username="eng").first()
        ticket = RepairTicket(
            title="維修中案件",
            description="描述",
            user_id=user.id,
            engineer_id=engineer.id,
            status="processing",
        )
        db.session.add(ticket)
        db.session.commit()
        ticket_id = ticket.id

    response = client.post(
        "/auth/login",
        data={"username": "eng", "password": "1234"},
        follow_redirects=True,
    )
    assert response.status_code == 200

    response = client.post(
        "/api/ticket/update",
        json={"ticket_id": ticket_id, "status": "done"},
        follow_redirects=True,
    )

    assert response.status_code == 200
    with flask_app.app_context():
        updated_ticket = RepairTicket.query.get(ticket_id)
        assert updated_ticket.status == "done"


def test_engineer_dashboard_api_returns_assigned_tickets(client):
    with flask_app.app_context():
        init_default_users(flask_app)
        user = User.query.filter_by(username="user").first()
        engineer = User.query.filter_by(username="eng").first()
        ticket = RepairTicket(
            title="新派工案件",
            description="等待工程師處理",
            user_id=user.id,
            engineer_id=engineer.id,
            status="processing",
        )
        db.session.add(ticket)
        db.session.commit()

    client.post(
        "/auth/login",
        data={"username": "eng", "password": "1234"},
        follow_redirects=True,
    )

    response = client.get("/api/ticket/engineer")
    assert response.status_code == 200
    payload = response.get_json()
    assert payload[0]["title"] == "新派工案件"
    assert payload[0]["status"] == "processing"
