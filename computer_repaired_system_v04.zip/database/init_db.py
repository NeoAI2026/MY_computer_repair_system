from database.base import db
from models.user import User


def init_default_users(app):
    with app.app_context():
        db.create_all()

        default_users = [
            {"username": "admin", "password": "1234", "role": "admin"},
            {"username": "eng", "password": "1234", "role": "engineer"},
            {"username": "user", "password": "1234", "role": "user"},
        ]

        created_any = False
        for user_data in default_users:
            user = User.query.filter_by(username=user_data["username"]).first()
            if user is None:
                db.session.add(User(**user_data))
                created_any = True
            else:
                if user.password != user_data["password"] or user.role != user_data["role"]:
                    user.password = user_data["password"]
                    user.role = user_data["role"]

        if created_any or any(
            User.query.filter_by(username=user_data["username"]).first() is None for user_data in default_users
        ):
            db.session.commit()

        existing_usernames = [u.username for u in User.query.filter(User.username.in_([u["username"] for u in default_users])).all()]
        print(f"✅ 預設帳號已就緒: {', '.join(existing_usernames)}")


if __name__ == "__main__":
    from app import app

    init_default_users(app)