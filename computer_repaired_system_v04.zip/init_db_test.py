from app import app
from database.init_db import init_default_users

init_default_users(app)
print("✅ 初始化完成")