from flask import Blueprint, render_template, session
from models.repair_ticket import RepairTicket
from flask import Blueprint, render_template, session, redirect

dashboard_bp = Blueprint("dashboard", __name__)  # 🔥 一定要在最外層

@dashboard_bp.route("/admin")
def admin_dashboard():

    if "user_id" not in session:
        return redirect("/auth/login")

    if session["role"] != "admin":
        return "403 Forbidden", 403

    return render_template("admin_dashboard.html")

@dashboard_bp.route("/engineer")
def engineer_dashboard():
    return "engineer"

@dashboard_bp.route("/user")
def user_dashboard():
    return "user"