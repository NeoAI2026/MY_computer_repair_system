from flask import Blueprint, request, session, redirect, url_for
from models.repair_ticket import RepairTicket
from models.user import User
from database.base import db

ticket_bp = Blueprint("ticket", __name__)


# 建立維修單
@ticket_bp.route("/create", methods=["POST"])
def create():

    if "user_id" not in session:
        return redirect("/auth/login")

    title = request.form["title"]
    desc = request.form["description"]

    ticket = RepairTicket(
        title=title,
        description=desc,
        user_id=session["user_id"]
    )

    db.session.add(ticket)
    db.session.commit()

    return redirect("/dashboard/user")


# 派工給工程師
@ticket_bp.route("/assign", methods=["POST"])
def assign_ticket():
    if "user_id" not in session:
        return redirect("/auth/login")

    if session.get("role") != "admin":
        return "403 Forbidden", 403

    ticket_id = request.form.get("ticket_id")
    engineer_id = request.form.get("engineer_id")

    if not ticket_id or not engineer_id:
        return redirect("/dashboard/admin")

    ticket = RepairTicket.query.get(ticket_id)
    engineer = User.query.get(engineer_id)

    if not ticket or not engineer or engineer.role != "engineer":
        return redirect("/dashboard/admin")

    ticket.engineer_id = engineer.id
    ticket.status = "processing"
    db.session.commit()

    return redirect("/dashboard/admin")