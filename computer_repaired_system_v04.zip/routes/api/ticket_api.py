from flask import Blueprint, request, jsonify, session
from models.repair_ticket import RepairTicket
from database.base import db
from sockets.socket_events import emit_ticket_update

ticket_api = Blueprint("ticket_api", __name__)


@ticket_api.route("/engineer", methods=["GET"])
def get_engineer_tickets():
    if "user_id" not in session:
        return jsonify({"error": "not login"}), 401

    if session.get("role") != "engineer":
        return jsonify({"error": "forbidden"}), 403

    tickets = RepairTicket.query.filter_by(engineer_id=session.get("user_id")).all()
    payload = [
        {
            "id": ticket.id,
            "title": ticket.title,
            "description": ticket.description,
            "status": ticket.status,
            "user_id": ticket.user_id,
        }
        for ticket in tickets
    ]
    return jsonify(payload)


@ticket_api.route("/update", methods=["POST"])
def update_ticket():
    if "user_id" not in session:
        return jsonify({"error": "not login"}), 401

    if session.get("role") not in {"engineer", "admin"}:
        return jsonify({"error": "forbidden"}), 403

    data = request.json or {}
    ticket_id = data.get("ticket_id")
    new_status = data.get("status")

    if not ticket_id or not new_status:
        return jsonify({"error": "missing data"}), 400

    ticket = RepairTicket.query.get(ticket_id)
    if not ticket:
        return jsonify({"error": "ticket not found"}), 404

    if session.get("role") == "engineer" and ticket.engineer_id != session.get("user_id"):
        return jsonify({"error": "forbidden"}), 403

    ticket.status = new_status
    db.session.commit()

    emit_ticket_update({
        "ticket_id": ticket.id,
        "status": ticket.status,
    })

    return jsonify({"message": "updated"})