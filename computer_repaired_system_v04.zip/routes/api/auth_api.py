from flask import Blueprint, request, jsonify
from models.user import User
from utils.jwt_handler import generate_token

auth_api = Blueprint("auth_api", __name__)

@auth_api.route("/login", methods=["POST"])
def login():
    data = request.json

    user = User.query.filter_by(username=data["username"]).first()

    if not user or user.password != data["password"]:
        return jsonify({"error": "login failed"}), 401

    token = generate_token(user.id, user.role)

    return jsonify({
        "token": token,
        "role": user.role
    })