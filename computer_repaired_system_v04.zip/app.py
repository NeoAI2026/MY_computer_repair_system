from flask import Flask, redirect
from config import Config
from database.base import db
from database.init_db import init_default_users

from routes.auth_routes import auth_bp
from routes.dashboard_routes import dashboard_bp
from routes.ticket_routes import ticket_bp
from routes.api.ticket_api import ticket_api

app = Flask(__name__)
app.config.from_object(Config)

db.init_app(app)

# Blueprint 註冊
app.register_blueprint(auth_bp, url_prefix="/auth")
app.register_blueprint(dashboard_bp, url_prefix="/dashboard")
app.register_blueprint(ticket_bp, url_prefix="/ticket")
app.register_blueprint(ticket_api, url_prefix="/api/ticket")


# 🔥 入口直接導向登入
@app.route("/")
def index():
    return redirect("/auth/login")


if __name__ == "__main__":
    init_default_users(app)
    app.run(debug=True)