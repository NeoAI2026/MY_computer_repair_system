socketio = None


def init_socket(socketio_instance):
    global socketio
    socketio = socketio_instance


def emit_ticket_update(data):
    if socketio:
        socketio.emit("ticket_update", data)