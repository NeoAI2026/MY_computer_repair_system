from flask import session, jsonify

def login_required(role=None):
    def wrapper(func):
        def inner(*args, **kwargs):
            if "user_id" not in session:
                return jsonify({"error": "not login"}), 401

            if role and session.get("role") != role:
                return jsonify({"error": "forbidden"}), 403

            return func(*args, **kwargs)
        inner.__name__ = func.__name__
        return inner
    return wrapper