from flask import Blueprint, render_template, request, redirect, session
from models.user import User

from database.base import db

auth_bp = Blueprint("auth", __name__)


@auth_bp.route("/login", methods=["GET", "POST"])
def login():

    if request.method == "GET":
        return render_template("login.html")

    username = request.form["username"]
    password = request.form["password"]

    user = User.query.filter_by(username=username).first()

    if not user:
        return render_template("login.html", error="帳號不存在")

    if not user.is_active:
        return render_template("login.html", error="帳號已停用")

    #if user.password != password:
    if not user.check_password(password):
        return render_template("login.html", error="密碼錯誤")

    # 🔐 建立 Session
    session["user_id"] = user.id
    session["username"] = user.username
    session["role"] = user.role

    # 🔀 角色導向
    if user.role == "admin":
        return redirect("/dashboard/admin")

    if user.role == "engineer":
        return redirect("/dashboard/engineer")

    return redirect("/dashboard/user")

from werkzeug.security import check_password_hash

@auth_bp.route("/change_password", methods=["GET", "POST"])
def change_password():

    if "user_id" not in session:
        return redirect("/auth/login")

    user = User.query.get(session["user_id"])

    if request.method == "GET":
        return render_template("change_password.html")

    old_password = request.form["old_password"]
    new_password = request.form["new_password"]
    confirm_password = request.form["confirm_password"]

    if not user.check_password(old_password):
        return render_template(
            "change_password.html",
            error="舊密碼錯誤"
        )

    if new_password != confirm_password:
        return render_template(
            "change_password.html",
            error="兩次密碼不一致"
        )

    user.set_password(new_password)

    db.session.commit()

    return redirect("/dashboard/" + session["role"])

@auth_bp.route("/profile")
def profile():

    if "user_id" not in session:
        return redirect("/auth/login")

    user = User.query.get(session["user_id"])

    return render_template(
        "profile.html",
        user=user
    )


@auth_bp.route("/logout")
def logout():
    session.clear()
    return redirect("/auth/login")


"""
from flask import (
    Blueprint,
    render_template,
    request,
    redirect,
    url_for,
    session
)

from models.user import User

auth_bp = Blueprint("auth", __name__)


@auth_bp.route("/login", methods=["GET", "POST"])
def login():

    if request.method == "GET":
        return render_template("login.html")

    username = request.form["username"]
    password = request.form["password"]

    user = User.query.filter_by(username=username).first()

    if user is None:
        return render_template(
            "login.html",
            error="帳號不存在"
        )

    if user.password != password:
        return render_template(
            "login.html",
            error="密碼錯誤"
        )

    session["user_id"] = user.id
    session["username"] = user.username
    session["role"] = user.role

    if user.role == "admin":
        return redirect("/dashboard/admin")

    if user.role == "engineer":
        return redirect("/dashboard/engineer")

    return redirect("/dashboard/user")

@auth_bp.route("/logout")
def logout():

    session.clear()

    return redirect("/auth/login")
"""

"""
from flask import Blueprint, request, jsonify, session
from models.user import User
from database.base import db

auth_bp = Blueprint("auth", __name__)

@auth_bp.route("/login", methods=["POST"])
def login():
    data = request.json

    user = User.query.filter_by(username=data["username"]).first()

    if not user or user.password != data["password"]:
        return jsonify({"error": "login failed"}), 401

    session["user_id"] = user.id
    session["role"] = user.role

    return jsonify({
        "message": "login success",
        "role": user.role
    })


@auth_bp.route("/logout")
def logout():
    session.clear()
    return jsonify({"message": "logout success"})
"""