from app import app
from database.base import db
from models.user import User

with app.app_context():

    db.create_all()

    if User.query.count() == 0:

        admin = User(username="admin", role="admin")
        admin.set_password("1234")

        engineer = User(username="eng", role="engineer")
        engineer.set_password("1234")

        user = User(username="user", role="user")
        user.set_password("1234")

        db.session.add(admin)
        db.session.add(engineer)
        db.session.add(user)

        db.session.commit()

    print("✅ 初始化完成")