from functools import wraps
from flask import session, redirect


def admin_required(func):
    @wraps(func)
    def wrapper(*args, **kwargs):

        if session.get("role") != "admin":
            return redirect("/dashboard/user")  # 或 403

        return func(*args, **kwargs)

    return wrapper