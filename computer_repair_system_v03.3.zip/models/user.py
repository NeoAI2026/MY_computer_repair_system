from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash
from database.base import db

class User(db.Model):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)

    # 👤 基本資料
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)

    full_name = db.Column(db.String(100))
    email = db.Column(db.String(120))
    phone = db.Column(db.String(30))

    # 🔐 角色
    role = db.Column(db.String(20), default="user")
    # admin / engineer / user

    # 🟢 帳號狀態
    is_active = db.Column(db.Boolean, default=True)

    # ⏰ 時間
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(
        db.DateTime,
        default=datetime.utcnow,
        onupdate=datetime.utcnow
    )

    # 🔐 密碼方法（重要）
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    # 使用者建立的維修單
    repair_tickets = db.relationship(
        "RepairTicket",
        foreign_keys="RepairTicket.user_id",
        backref="customer",
        lazy=True
    )

    # 工程師負責的維修單
    assigned_tickets = db.relationship(
        "RepairTicket",
        foreign_keys="RepairTicket.engineer_id",
        backref="engineer",
        lazy=True
    )