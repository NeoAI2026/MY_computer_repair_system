from datetime import datetime
from database.base import db


class SystemLog(db.Model):
    __tablename__ = "system_logs"

    id = db.Column(db.Integer, primary_key=True)

    user_id = db.Column(db.Integer)

    username = db.Column(db.String(80))

    action = db.Column(db.String(100))

    target = db.Column(db.String(100))

    ip = db.Column(db.String(50))

    created_at = db.Column(
        db.DateTime,
        default=datetime.utcnow
    )