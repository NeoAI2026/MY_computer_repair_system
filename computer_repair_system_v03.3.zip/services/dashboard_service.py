from models.repair_ticket import RepairTicket


class DashboardService:


    @staticmethod
    def get_statistics():

        return {

            "total":
                RepairTicket.query.count(),

            "pending":
                RepairTicket.query.filter_by(
                    status="pending"
                ).count(),


            "processing":
                RepairTicket.query.filter_by(
                    status="processing"
                ).count(),


            "done":
                RepairTicket.query.filter_by(
                    status="done"
                ).count()

        }