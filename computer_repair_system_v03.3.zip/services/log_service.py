from flask import request
from database.base import db
from models.system_log import SystemLog


class LogService:

    @staticmethod
    def write(user, action, target=""):

        log = SystemLog(
            user_id=user.id,
            username=user.username,
            action=action,
            target=target,
            ip=request.remote_addr
        )

        db.session.add(log)
        db.session.commit()