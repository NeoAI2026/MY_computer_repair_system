from functools import wraps

from flask import jsonify
#from flask_jwt_extended import get_jwt_identity
from flask_jwt_extended import get_jwt_identity,get_jwt


from models.user import User


def permission_required(permission_name):

    def decorator(func):

        @wraps(func)
        def wrapper(*args, **kwargs):

            identity = get_jwt_identity()
            claims=get_jwt()

            if not identity:
                return jsonify({
                    "error": "missing identity"
                }), 401



            user_id = int(identity)
            role=claims.get(
                "role"
            )



            user = User.query.get(user_id)


            if not user:
                return jsonify({
                    "error": "user not found"
                }), 404



            permissions = []


            # 單 Role
            if user.role:

                for p in user.role.permissions:
                    permissions.append(
                        p.name
                    )


            # 多 Role
            for role in user.roles:

                for p in role.permissions:

                    if p.name not in permissions:
                        permissions.append(
                            p.name
                        )



            if permission_name not in permissions:

                return jsonify({
                    "error": "forbidden",
                    "permission": permission_name
                }),403



            return func(*args, **kwargs)


        return wrapper


    return decorator


"""
from functools import wraps

from flask_jwt_extended import (
    verify_jwt_in_request,
    get_jwt
)

from flask import jsonify

from services.permission_service import PermissionService

from models.user import User



def permission_required(permission):


    def decorator(fn):

        @wraps(fn)
        def wrapper(*args, **kwargs):


            verify_jwt_in_request()


            identity = get_jwt()


            user_id = identity["sub"]["id"]


            user = User.query.get(user_id)


            if not user:
                return jsonify({
                    "error":"User not found"
                }),404



            allowed = PermissionService.has_permission(
                user,
                permission
            )


            if not allowed:

                return jsonify({
                    "error":"Permission denied",
                    "required":permission
                }),403



            return fn(*args, **kwargs)


        return wrapper


    return decorator
"""