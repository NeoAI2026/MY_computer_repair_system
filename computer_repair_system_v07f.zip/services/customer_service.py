from database.base import db
from models.customer import Customer



class CustomerService:



    @staticmethod
    def get_or_create(data):


        customer = Customer.query.filter_by(

            phone=data.get(
                "customer_phone"
            )

        ).first()



        if customer:

            return customer



        customer = Customer(

            name=data.get(
                "customer_name"
            ),

            phone=data.get(
                "customer_phone"
            )

        )


        db.session.add(customer)

        db.session.flush()


        return customer