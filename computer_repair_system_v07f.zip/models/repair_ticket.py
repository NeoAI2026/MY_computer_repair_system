from database.base import db
from datetime import datetime
from models.repair_history import RepairHistory

class RepairTicket(db.Model):

    __tablename__ = "repair_tickets"


    id = db.Column(
        db.Integer,
        primary_key=True
    )


    ticket_no = db.Column(
        db.String(30),
        unique=True,
        nullable=False
    )


    customer_id = db.Column(
        db.Integer,
        db.ForeignKey("customers.id"),
        nullable=False
    )


    device_id = db.Column(
        db.Integer,
        db.ForeignKey("devices.id")
    )


    engineer_id = db.Column(
        db.Integer,
        db.ForeignKey("users.id")
    )


    title = db.Column(
        db.String(200),
        nullable=False
    )


    description = db.Column(
        db.Text
    )


    status = db.Column(
        db.String(50),
        default="new"
    )    

    # =====================
    # 客戶資料
    # =====================

    customer_name = db.Column(
        db.String(100)
    )


    customer_phone = db.Column(
        db.String(50)
    )


    customer_email = db.Column(
        db.String(120)
    )

    # =====================
    # 設備資料
    # =====================

    device_type = db.Column(
        db.String(50)
    )


    brand = db.Column(
        db.String(100)
    )


    model = db.Column(
        db.String(100)
    )


    serial_number = db.Column(
        db.String(100)
    )

    # =====================
    # 維修分類
    # =====================

    category = db.Column(
        db.String(50)
    )


    priority = db.Column(
        db.String(20),
        default="normal"
    )


    # =====================
    # 時間追蹤
    # =====================

    assigned_at = db.Column(
        db.DateTime
    )


    started_at = db.Column(
        db.DateTime
    )


    completed_at = db.Column(
        db.DateTime
    )

    workflow_started_at = db.Column(
        db.DateTime
    )

    closed_at = db.Column(
        db.DateTime
    )


    created_at = db.Column(
        db.DateTime,
        default=datetime.utcnow
    )


    priority = db.Column(
        db.String(20),
        default="normal"
    )


    created_at = db.Column(
        db.DateTime,
        default=datetime.utcnow
    )


    updated_at = db.Column(
        db.DateTime,
        default=datetime.utcnow,
        onupdate=datetime.utcnow
    )


    customer = db.relationship(
        "Customer"
    )


    device = db.relationship(
        "Device"
    )


    engineer = db.relationship(
        "User",
        foreign_keys=[engineer_id],
        #back_populates="assigned_histories"
    )


    histories = db.relationship(
        "RepairHistory",
        back_populates="ticket",
        cascade="all, delete-orphan"
    )


    attachments = db.relationship(
        "Attachment",
        back_populates="ticket",
        cascade="all, delete-orphan"
    )
    
    quotations=db.relationship(
        "Quotation",
        back_populates="ticket",
        cascade="all, delete-orphan"
    )
    

    def status_text(self):

        mapping = {

            "pending":"待派工",

            "assigned":"已派工程師",

            "checking":"檢測中",

            "quotation":"報價確認",

            "repairing":"維修中",

            "testing":"測試中",

            "completed":"完工",

            "accepted":"客戶驗收",

            "closed":"結案"

        }


        return mapping.get(
            self.status,
            self.status
        )