from flask import Blueprint, jsonify

from services.history_service import HistoryService


history_bp = Blueprint(
    "history",
    __name__
)



@history_bp.route(
    "/api/tickets/<int:ticket_id>/history",
    methods=["GET"]
)
def get_history(ticket_id):


    histories = (
        HistoryService
        .get_ticket_history(ticket_id)
    )


    result = []


    for h in histories:

        result.append({

            "id": h.id,

            "ticket_id": h.ticket_id,

            "old_status": h.old_status,

            "new_status": h.new_status,

            "remark": h.remark,

            "operator_id": h.operator_id,

            "created_at":
                h.created_at.isoformat()

        })


    return jsonify({

        "ticket_id": ticket_id,

        "count": len(result),

        "history": result

    })