from flask import (
    Blueprint,
    render_template,
    request,
    redirect,
    url_for,
    flash
)

from flask_jwt_extended import (
    jwt_required,
    get_jwt_identity,
    get_jwt
)

from services.ticket_service import TicketService


web_ticket_bp = Blueprint(
    "web_ticket",
    __name__,
    url_prefix="/tickets"
)



# =====================================
# Ticket List
# GET /tickets/
# =====================================

@web_ticket_bp.route("/")
@jwt_required()
def list_ticket_page():


    tickets = TicketService.get_all()


    return render_template(
        "tickets/list.html",
        tickets=tickets
    )




# =====================================
# Ticket Create Page
# GET /tickets/create
# =====================================

@web_ticket_bp.route(
    "/create",
    methods=[
        "GET",
        "POST"
    ]
)
@jwt_required()
def create_ticket_page():


    user_id = get_jwt_identity()



    if request.method == "POST":


        data = {

            "title":
            request.form.get(
                "title"
            ),


            "description":
            request.form.get(
                "description"
            ),


            "priority":
            request.form.get(
                "priority"
            ),


            "customer_id":
            request.form.get(
                "customer_id"
            )

        }



        TicketService.create_ticket(

            data,

            creator_id=user_id

        )



        flash(
            "新增維修案件成功",
            "success"
        )


        return redirect(

            url_for(
                "web.ticket_list"
            )

        )



    return render_template(
        "tickets/create.html"
    )




# =====================================
# Ticket Create
# POST /tickets/create
# =====================================

@web_ticket_bp.route(
    "/create",
    methods=["POST"]
)
@jwt_required()
def create_ticket():


    identity = get_jwt_identity()


    data = {

        "title":
            request.form.get("title"),


        "description":
            request.form.get("description"),


        "priority":
            request.form.get("priority"),


        "customer_id":
            request.form.get("customer_id"),


        "engineer_id":
            request.form.get("engineer_id")

    }



    ticket = TicketService.create_ticket(
        data,
        creator_id=identity
    )


    flash(
        "維修案件建立成功",
        "success"
    )


    return redirect(
        url_for(
            "ticket.list_ticket_page"
        )
    )




# =====================================
# Ticket Detail
# GET /tickets/<id>
# =====================================

@web_ticket_bp.route(
    "/<int:ticket_id>"
)
@jwt_required()
def ticket_detail_page(ticket_id):


    ticket = TicketService.get_ticket(
        ticket_id
    )


    if not ticket:


        flash(
            "找不到案件",
            "danger"
        )


        return redirect(
            url_for(
                "ticket.list_ticket_page"
            )
        )



    return render_template(
        "tickets/detail.html",
        ticket=ticket
    )




# =====================================
# Ticket Edit
# GET POST
# =====================================

@web_ticket_bp.route(
    "/<int:ticket_id>/edit",
    methods=[
        "GET",
        "POST"
    ]
)
@jwt_required()
def ticket_edit_page(ticket_id):


    ticket = TicketService.get_ticket(
        ticket_id
    )


    if not ticket:


        flash(
            "案件不存在",
            "danger"
        )


        return redirect(
            url_for(
                "ticket.list_ticket_page"
            )
        )



    if request.method == "POST":


        TicketService.update_ticket(
            ticket,
            request.form
        )


        flash(
            "更新成功",
            "success"
        )


        return redirect(
            url_for(
                "ticket.ticket_detail_page",
                ticket_id=ticket.id
            )
        )



    return render_template(
        "tickets/edit.html",
        ticket=ticket
    )




# =====================================
# Ticket History
# =====================================

@web_ticket_bp.route(
    "/<int:ticket_id>/history"
)
@jwt_required()
def ticket_history_page(ticket_id):


    ticket = TicketService.get_ticket(
        ticket_id
    )


    if not ticket:


        return redirect(
            url_for(
                "ticket.list_ticket_page"
            )
        )



    return render_template(
        "tickets/history.html",
        ticket=ticket
    )