from database.base import db
from datetime import datetime


class Quotation(db.Model):

    __tablename__ = "quotations"

    id = db.Column(
        db.Integer,
        primary_key=True
    )

    quotation_no = db.Column(
        db.String(30),
        unique=True,
        nullable=False
    )

    ticket_id = db.Column(
        db.Integer,
        db.ForeignKey("repair_tickets.id"),
        nullable=False,
        unique=True
    )

    customer_id = db.Column(
        db.Integer,
        db.ForeignKey(
            "customers.id"
        )
    )

    labor_fee = db.Column(
        db.Float,
        default=0
    )

    parts_total = db.Column(
        db.Float,
        default=0
    )

    other_fee = db.Column(
        db.Float,
        default=0
    )

    total_price = db.Column(
        db.Float,
        default=0
    )

    status = db.Column(
        db.String(30),
        default="draft"
    )

    created_by = db.Column(
        db.Integer,
        db.ForeignKey("users.id")
    )

    approved_at = db.Column(
        db.DateTime
    )

    created_at = db.Column(
        db.DateTime,
        default=datetime.utcnow
    )

    updated_at = db.Column(
        db.DateTime,
        default=datetime.utcnow,
        onupdate=datetime.utcnow
    )

    ticket = db.relationship(
        "RepairTicket",
        back_populates="quotation"
    )

    creator = db.relationship(
        "User"
    )