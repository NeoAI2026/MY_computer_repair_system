from flask import (
    Blueprint,
    render_template,
    request,
    redirect,
    url_for,
    flash
)


from flask_jwt_extended import (
    create_access_token,
    set_access_cookies,
    unset_jwt_cookies,
    jwt_required,
    get_jwt,
    get_jwt_identity
)


from services.auth_service import AuthService
from services.ticket_service import TicketService
from services.user_service import UserService


from models.repair_ticket import RepairTicket
from models.repair_history import RepairHistory


web_bp = Blueprint(
    "web",
    __name__
)


# =================================
# Home
# =================================

@web_bp.route("/")
def home():

    return redirect(
        url_for(
            "web.login"
        )
    )



# =================================
# Login
# =================================

@web_bp.route(
    "/login",
    methods=[
        "GET",
        "POST"
    ]
)
def login():


    if request.method == "POST":


        username = request.form.get(
            "username"
        )


        password = request.form.get(
            "password"
        )


        user = AuthService.login(
            username,
            password
        )


        if user is None:


            flash(
                "帳號或密碼錯誤",
                "danger"
            )


            return redirect(
                url_for(
                    "web.login"
                )
            )


        # JWT identity 必須 string

        access_token = create_access_token(

            identity=str(user.id),

            additional_claims={

                "username":
                    user.username,

                "role":
                    user.role.name

            }

        )


        response = redirect(

            url_for(
                "web.dashboard"
            )

        )


        set_access_cookies(

            response,

            access_token

        )


        return response



    return render_template(
        "login.html"
    )



# =================================
# Dashboard Router
# =================================

@web_bp.route(
    "/dashboard"
)
@jwt_required()
def dashboard():


    claims = get_jwt()


    role = claims.get(
        "role"
    )


    if role == "admin":


        tickets = TicketService.get_all()


        return render_template(

            "dashboard/admin.html",

            user=claims,

            tickets=tickets,

            total_tickets=len(tickets)

        )



    elif role == "engineer":

        return redirect(
            url_for(
                "web.dashboard_engineer"
            )
        )


    elif role == "manager":

        return redirect(
            url_for(
                "web.dashboard_manager"
            )
        )


    elif role == "vendor":

        return redirect(
            url_for(
                "web.dashboard_vendor"
            )
        )


    return redirect(
        url_for(
            "web.login"
        )
    )



# =================================
# Engineer Dashboard
# =================================


@web_bp.route(
    "/dashboard/engineer"
)
@jwt_required()
def dashboard_engineer():


    user_id = int(
        get_jwt_identity()
    )


    tickets = (
        TicketService
        .get_engineer_tickets(
            user_id
        )
    )


    return render_template(

        "dashboard/engineer.html",

        tickets=tickets,

        total=len(tickets)

    )



# =================================
# Manager Dashboard
# =================================


@web_bp.route(
    "/dashboard/manager"
)
@jwt_required()
def dashboard_manager():


    tickets = (
        TicketService
        .get_all()
    )


    return render_template(

        "dashboard/manager.html",

        tickets=tickets,

        total=len(tickets)

    )



# =================================
# Vendor Dashboard
# =================================


@web_bp.route(
    "/dashboard/vendor"
)
@jwt_required()
def dashboard_vendor():


    tickets = (
        TicketService
        .get_waiting_parts()
    )


    return render_template(

        "dashboard/vendor.html",

        tickets=tickets,

        total=len(tickets)

    )



# =================================
# Ticket List
# =================================


@web_bp.route(
    "/tickets"
)
@jwt_required()
def ticket_list():


    tickets = (
        TicketService
        .get_all()
    )


    return render_template(

        "tickets/list.html",

        tickets=tickets

    )



# =================================
# Create Ticket
# =================================


@web_bp.route(
    "/tickets/create",
    methods=[
        "GET",
        "POST"
    ]
)
@jwt_required()
def create_ticket_page():


    if request.method == "POST":


        creator_id = int(
            get_jwt_identity()
        )


        data = (
            request.form
            .to_dict()
        )


        TicketService.create_ticket(

            data,

            creator_id

        )


        flash(
            "案件建立成功",
            "success"
        )


        return redirect(
            url_for(
                "web.ticket_list"
            )
        )



    return render_template(
        "tickets/create.html"
    )



# =================================
# Ticket Detail
# =================================


@web_bp.route(
    "/tickets/<int:ticket_id>"
)
@jwt_required()
def ticket_detail(ticket_id):


    ticket = (
        TicketService
        .get_ticket(
            ticket_id
        )
    )


    if ticket is None:

        return redirect(
            url_for(
                "web.ticket_list"
            )
        )


    return render_template(

        "tickets/detail.html",

        ticket=ticket

    )



# =================================
# Ticket Edit
# =================================


@web_bp.route(
    "/tickets/<int:ticket_id>/edit",
    methods=[
        "GET",
        "POST"
    ]
)
@jwt_required()
def edit_ticket(ticket_id):


    ticket = (
        TicketService
        .get_ticket(
            ticket_id
        )
    )


    if request.method == "POST":


        data = (
            request.form
            .to_dict()
        )


        TicketService.update_ticket(

            ticket,

            data

        )


        if data.get(
            "engineer_id"
        ):


            TicketService.assign_engineer(

                ticket_id,

                data["engineer_id"]

            )


        return redirect(

            url_for(

                "web.ticket_detail",

                ticket_id=ticket_id

            )

        )



    engineers = (
        UserService
        .get_engineers()
    )


    return render_template(

        "tickets/edit.html",

        ticket=ticket,

        engineers=engineers

    )



# =================================
# History
# =================================


@web_bp.route(
    "/tickets/<int:ticket_id>/history"
)
@jwt_required()
def ticket_history(ticket_id):


    ticket = (
        RepairTicket
        .query
        .get_or_404(
            ticket_id
        )
    )


    histories = (
        RepairHistory
        .query
        .filter_by(
            ticket_id=ticket_id
        )
        .order_by(
            RepairHistory.created_at.asc()
        )
        .all()
    )


    return render_template(

        "tickets/history.html",

        ticket=ticket,

        histories=histories

    )



# =================================
# Logout
# =================================


@web_bp.route(
    "/logout"
)
def logout():


    response = redirect(

        url_for(
            "web.login"
        )

    )


    unset_jwt_cookies(
        response
    )


    flash(
        "已登出",
        "success"
    )


    return response