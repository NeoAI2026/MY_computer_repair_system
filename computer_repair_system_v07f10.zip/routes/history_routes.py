from flask import (
    Blueprint,
    jsonify,
    render_template
)

from services.history_service import HistoryService


history_bp = Blueprint(
    "history",
    __name__
)


# ==============================
# Web 維修歷史頁面
# ==============================

@history_bp.route(
    "/history/<int:ticket_id>"
)
def history_page(ticket_id):

    histories = (
        HistoryService
        .get_ticket_history(ticket_id)
    )


    return render_template(
        "history/history.html",
        histories=histories,
        ticket_id=ticket_id
    )



# ==============================
# API
# ==============================

@history_bp.route(
    "/api/tickets/<int:ticket_id>/history",
    methods=["GET"]
)
def get_history(ticket_id):


    histories = (
        HistoryService
        .get_ticket_history(ticket_id)
    )


    result=[]


    for h in histories:

        result.append({

            "id":h.id,

            "ticket_id":
                h.ticket_id,

            "old_status":
                h.old_status,

            "new_status":
                h.new_status,

            "remark":
                h.remark,

            "operator_id":
                h.operator_id,

            "created_at":
                h.created_at.isoformat()

        })


    return jsonify({

        "ticket_id":
            ticket_id,

        "count":
            len(result),

        "history":
            result

    })


"""
from flask import Blueprint, jsonify

from services.history_service import HistoryService


history_bp = Blueprint(
    "history",
    __name__
)



@history_bp.route(
    "/api/tickets/<int:ticket_id>/history",
    methods=["GET"]
)
def get_history(ticket_id):


    histories = (
        HistoryService
        .get_ticket_history(ticket_id)
    )


    result = []


    for h in histories:

        result.append({

            "id": h.id,

            "ticket_id": h.ticket_id,

            "old_status": h.old_status,

            "new_status": h.new_status,

            "remark": h.remark,

            "operator_id": h.operator_id,

            "created_at":
                h.created_at.isoformat()

        })


    return jsonify({

        "ticket_id": ticket_id,

        "count": len(result),

        "history": result

    })
"""