from flask import (
    Blueprint,
    render_template,
    request,
    redirect,
    url_for
)


from flask_jwt_extended import jwt_required


from services.customer_service import CustomerService



customer_bp = Blueprint(

    "customer",

    __name__,

    url_prefix="/customers"

)



@customer_bp.route("/")
@jwt_required()
def list_customer():


    customers = CustomerService.get_all()


    return render_template(

        "customers/customer_list.html",

        customers=customers

    )



@customer_bp.route(
    "/add",
    methods=["GET","POST"]
)
@jwt_required()
def add_customer():


    if request.method=="POST":


        CustomerService.create(

            request.form

        )


        return redirect(

            url_for(
                "customer.list_customer"
            )

        )



    return render_template(

        "customers/customer_add.html"

    )



@customer_bp.route(
    "/edit/<int:id>",
    methods=["GET","POST"]
)
@jwt_required()
def edit_customer(id):


    customer = CustomerService.get(id)



    if request.method=="POST":


        CustomerService.update(

            customer,

            request.form

        )


        return redirect(

            url_for(
                "customer.list_customer"
            )

        )



    return render_template(

        "customers/customer_edit.html",

        customer=customer

    )



@customer_bp.route(
    "/history/<int:id>"
)
@jwt_required()
def customer_history(id):


    customer = CustomerService.get(id)


    return render_template(

        "customers/customer_history.html",

        customer=customer

    )