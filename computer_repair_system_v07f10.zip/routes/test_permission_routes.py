from flask import Blueprint, jsonify
from flask_jwt_extended import jwt_required

from middleware.permission import permission_required


test_permission_bp = Blueprint(
    "test_permission",
    __name__
)



@test_permission_bp.route(
    "/api/test/admin",
    methods=["GET"]
)
@jwt_required()
@permission_required(
    "user:create"
)
def test_admin_permission():

    return jsonify(
        {
            "message":
            "admin permission success"
        }
    )



@test_permission_bp.route(
    "/api/test/ticket",
    methods=["GET"]
)
@jwt_required()
@permission_required(
    "ticket:update"
)
def test_ticket_permission():

    return jsonify(
        {
            "message":
            "ticket permission success"
        }
    )



@test_permission_bp.route(
    "/api/test/dashboard",
    methods=["GET"]
)
@jwt_required()
@permission_required(
    "dashboard:view"
)
def test_dashboard_permission():

    return jsonify(
        {
            "message":
            "dashboard permission success"
        }
    )

@test_permission_bp.route(
    "/api/test/quotation",
    methods=["GET"]
)
@jwt_required()
@permission_required(
    "quotation:approve"
)
def test_quotation():


    return jsonify(
        {
            "message":
            "quotation permission success"
        }
    )

@test_permission_bp.route(
    "/api/test/ticket/list",
    methods=["GET"]
)
@jwt_required()
@permission_required(
    "ticket:list"
)
def test_ticket_list():

    return jsonify(
        {
            "message":
            "ticket list permission success"
        }
    )