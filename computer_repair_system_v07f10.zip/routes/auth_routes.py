import token

from flask import Blueprint, request, jsonify

from flask_jwt_extended import (
    create_access_token
)

from services.auth_service import AuthService


auth_bp = Blueprint(
    "auth",
    __name__,
    url_prefix="/api/auth"
)



@auth_bp.route(
    "/login",
    methods=["POST"]
)
def login():


    data=request.json


    user = AuthService.login(
        data.get("username"),
        data.get("password")
    )


    if not user:

        return jsonify(
            {
                "error":"Invalid username or password"
            }
        ),401

    role_name = None

    if user.role:
        role_name = user.role.name

    identity = str(user.id)

    claims = {        
        "username": user.username,
        "role": user.role.name
    }

    access_token=create_access_token(
        identity=identity,
        additional_claims=claims
    )



    return jsonify(
        {
            "access_token": access_token,
            "user": identity
        }
    )