from flask import Blueprint, request, jsonify

from services.ticket_service import TicketService

from flask_jwt_extended import jwt_required

from middleware.permission import permission_required


ticket_bp = Blueprint(
    "ticket",
    __name__,
    url_prefix="/api/tickets"
)



# =========================
# Create Ticket
# =========================

@ticket_bp.route(
    "",
    methods=["POST"]
)
@jwt_required()
@permission_required(
    "ticket:create"
)
def create_ticket():


    data = request.json


    ticket = TicketService.create_ticket(
        data
    )


    return jsonify({

        "message":
            "ticket created",

        "ticket_id":
            ticket.id,

        "ticket_no":
            ticket.ticket_no

    }),201




# =========================
# List Tickets
# =========================

@ticket_bp.route(
    "",
    methods=["GET"]
)
@jwt_required()
@permission_required("ticket:list")
def list_ticket():


    tickets = TicketService.get_all()


    return jsonify([

        {

        "id":t.id,

        "ticket_no":
            t.ticket_no,

        "status":
            t.status,

        "title":
            t.title

        }

        for t in tickets

    ])


# =========================
# Update Ticket
# =========================

@ticket_bp.route(
    "/<int:ticket_id>",
    methods=["PUT"]
)
@jwt_required()
@permission_required(
    "ticket:update"
)
def update_ticket(ticket_id):


    ticket = TicketService.get_ticket(
        ticket_id
    )


    if not ticket:

        return jsonify({
            "error":
            "ticket not found"
        }),404



    ticket = TicketService.update_ticket(

        ticket,

        request.json

    )


    return jsonify({

        "message":
        "ticket updated"

    })


@ticket_bp.route(
    "/<int:ticket_id>/assign",
    methods=["PUT"]
)
@jwt_required()
@permission_required(
    "ticket:assign"
)
def assign_ticket(ticket_id):


    data=request.json


    TicketService.assign_engineer(
        ticket_id,
        data["engineer_id"]
    )


    return jsonify(
        {
            "message":
            "engineer assigned"
        }
    )


# =========================
# Close Ticket
# =========================

@ticket_bp.route(
    "/<int:ticket_id>/close",
    methods=["POST"]
)
@jwt_required()
@permission_required(
    "ticket:close"
)
def close_ticket(ticket_id):


    ticket = TicketService.get_ticket(
        ticket_id
    )


    if not ticket:

        return jsonify({

            "error":
            "ticket not found"

        }),404



    TicketService.close_ticket(
        ticket
    )


    return jsonify({

        "message":
        "ticket closed"

    })