from flask import (
    Blueprint,
    render_template,
    request,
    redirect,
    url_for,
    flash
)


from flask_jwt_extended import jwt_required


from services.device_service import DeviceService



device_bp = Blueprint(
    "device",
    __name__
)



# ==========================
# Device Detail
# ==========================

@device_bp.route(
    "/devices/<int:id>"
)
@jwt_required()
def detail(id):


    device = DeviceService.get(
        id
    )


    return render_template(
        "devices/device_detail.html",
        device=device
    )




# ==========================
# Device Edit
# ==========================

@device_bp.route(
    "/devices/<int:id>/edit",
    methods=[
        "GET",
        "POST"
    ]
)
@jwt_required()
def edit(id):


    device = DeviceService.get(
        id
    )


    if request.method=="POST":


        DeviceService.update(
            device,
            request.form
        )


        flash(
            "設備更新完成",
            "success"
        )


        return redirect(
            url_for(
                "device.detail",
                id=id
            )
        )



    return render_template(
        "devices/device_edit.html",
        device=device
    )



# ==========================
# Delete
# ==========================


@device_bp.route(
    "/devices/<int:id>/delete",
    methods=["POST"]
)
@jwt_required()
def delete(id):


    device = DeviceService.get(
        id
    )


    DeviceService.delete(
        device
    )


    flash(
        "設備已刪除",
        "success"
    )


    return redirect(
        url_for(
            "device.list"
        )
    )


"""
from flask import Blueprint,request,jsonify

from services.device_service import DeviceService


device_bp = Blueprint(
    "device",
    __name__,
    url_prefix="/api/devices"
)



@device_bp.route(
    "",
    methods=["GET"]
)
def list_device():

    devices = DeviceService.get_all()


    return jsonify([

        {

        "id":d.id,

        "customer_id":d.customer_id,

        "device_type":d.device_type,

        "brand":d.brand,

        "model":d.model,

        "serial_number":d.serial_number

        }

        for d in devices

    ])




@device_bp.route(
    "",
    methods=["POST"]
)
def create_device():

    data=request.json


    device=DeviceService.create(
        data
    )


    return jsonify({

        "message":"created",

        "id":device.id

    })
"""
