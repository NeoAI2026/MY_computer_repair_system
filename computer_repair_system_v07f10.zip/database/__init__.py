from database.base import db

__all__ = [
    "db"
]