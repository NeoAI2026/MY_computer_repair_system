from app import app
from database.base import db

from models.user import User
from models.role import Role


def seed():

    with app.app_context():

        users = [

            {
                "username": "admin",
                "password": "admin123",
                "role": "admin"
            },

            {
                "username": "engineer",
                "password": "engineer123",
                "role": "engineer"
            },

            {
                "username": "manager",
                "password": "manager123",
                "role": "manager"
            },

            {
                "username": "vendor",
                "password": "vendor123",
                "role": "vendor"
            }

        ]


        for item in users:

            role = Role.query.filter_by(
                name=item["role"]
            ).first()


            if not role:
                print(
                    "Role missing:",
                    item["role"]
                )
                continue


            user = User.query.filter_by(
                username=item["username"]
            ).first()


            if user:

                print(
                    "Update:",
                    item["username"]
                )

            else:

                user = User(
                    username=item["username"],
                    role_id=role.id,
                    active=True
                )

                db.session.add(user)

                print(
                    "Create:",
                    item["username"]
                )


            user.set_password(
                item["password"]
            )


        db.session.commit()


        print()
        print("====================")
        print("USER SEED COMPLETE")
        print("====================")



if __name__ == "__main__":
    seed()