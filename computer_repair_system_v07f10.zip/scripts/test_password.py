from app import app
from models.user import User


def test():

    with app.app_context():

        print("====================")
        print("PASSWORD TEST")
        print("====================")


        users = [
            ("admin", "admin123"),
            ("engineer", "engineer123"),
            ("manager", "manager123"),
            ("vendor", "vendor123")
        ]


        for username, password in users:

            user = User.query.filter_by(
                username=username
            ).first()


            if not user:
                print(
                    username,
                    "NOT FOUND"
                )
                continue


            result = user.check_password(
                password
            )


            print(
                username,
                result
            )


        print("====================")
        print("TEST COMPLETE")
        print("====================")


if __name__ == "__main__":
    test()