import requests


url="http://127.0.0.1:5000/api/auth/login"


users=[
    ("admin","admin123"),
    ("engineer","engineer123"),
    ("manager","manager123"),
    ("vendor","vendor123")
]


for username,password in users:


    r=requests.post(
        url,
        json={
            "username":username,
            "password":password
        }
    )


    print(
        username,
        r.status_code,
        r.json()
    )