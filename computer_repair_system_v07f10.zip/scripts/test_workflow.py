from app import app

from models.repair_status import RepairStatus


with app.app_context():

    data = RepairStatus.query.all()


    for s in data:

        print(
            s.sequence,
            s.code,
            s.name
        )