from app import app
from database.base import db


with app.app_context():

    conn = db.engine.connect()

    try:

        conn.execute(
            db.text(
                """
                ALTER TABLE roles
                ADD COLUMN description VARCHAR(200)
                """
            )
        )

        print("roles.description added")

    except Exception as e:

        print("ERROR:")
        print(e)

    finally:

        conn.close()