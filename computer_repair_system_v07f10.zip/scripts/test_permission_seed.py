from app import app

from models.role import Role


with app.app_context():

    print("===== ROLE PERMISSION TEST =====")

    roles = Role.query.all()

    for role in roles:

        print()
        print("=" * 40)
        print(role.name.upper())

        for permission in role.permissions:

            print(permission.name)

    print()
    print("===== TEST COMPLETE =====")