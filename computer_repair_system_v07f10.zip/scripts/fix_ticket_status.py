from app import app
from database.base import db
from models.repair_ticket import RepairTicket


with app.app_context():


    tickets = RepairTicket.query.all()


    for t in tickets:

        if t.status:

            t.status = t.status.lower()


    db.session.commit()


    print("Ticket status fixed")