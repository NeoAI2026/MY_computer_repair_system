from app import app
from models.permission import Permission


with app.app_context():

    print("===== PERMISSION TEST =====")


    count = Permission.query.count()


    print(
        "Permission Count:",
        count
    )


    print("===== OK =====")