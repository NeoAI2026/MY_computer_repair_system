from app import create_app
from database.base import db

from models.role import Role


roles = [

    {
        "name": "admin",
        "description": "系統管理員"
    },

    {
        "name": "engineer",
        "description": "維修工程師"
    },

    {
        "name": "manager",
        "description": "管理主管"
    },

    {
        "name": "vendor",
        "description": "合作廠商"
    }

]


def seed():

    app = create_app()


    with app.app_context():

        print(
            "===== RBAC ROLE SEED ====="
        )


        for item in roles:


            exists = Role.query.filter_by(
                name=item["name"]
            ).first()


            if exists:

                print(
                    f"SKIP: {item['name']}"
                )

                continue



            role = Role(
                name=item["name"],
                #description=item["description"]
            )


            db.session.add(role)


            print(
                f"CREATE: {item['name']}"
            )


        db.session.commit()


        print(
            "===== ROLE SEED COMPLETE ====="
        )



if __name__ == "__main__":

    seed()