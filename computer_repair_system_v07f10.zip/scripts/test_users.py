from app import app
from models.user import User


with app.app_context():

    print("===== USER TEST =====")

    users = User.query.all()


    for user in users:

        print(
            user.id,
            user.username,
            user.role.name,
            user.password_hash[:20]
        )


    print("===== OK =====")