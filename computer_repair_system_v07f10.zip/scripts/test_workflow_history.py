from models.repair_history import RepairHistory
from models.repair_ticket import RepairTicket


def test():
    ticket = RepairTicket.query.first()

    histories = RepairHistory.query.filter_by(
        ticket_id=ticket.id
    ).order_by(
        RepairHistory.id
    ).all()


    for h in histories:

        print(
            f"""
    {h.old_status}
    ↓
    {h.new_status}

    Remark:
    {h.remark}

    """
        )


    print(
        "History Count:",
        len(histories)
    )

from app import app

if __name__=="__main__":
    with app.app_context():
        test()