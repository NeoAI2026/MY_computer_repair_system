from app import app
from database.base import db

from models.role import Role
from models.permission import Permission


PERMISSIONS = [

    # User
    ("user:list", "查看使用者"),
    ("user:create", "新增使用者"),
    ("user:update", "修改使用者"),
    ("user:delete", "刪除使用者"),

    # Ticket
    ("ticket:list", "查看維修單"),
    ("ticket:create", "建立維修單"),
    ("ticket:update", "修改維修單"),
    ("ticket:assign", "指派工程師"),
    ("ticket:close", "結案"),

    # History
    ("history:view", "查看維修紀錄"),

    # Dashboard
    ("dashboard:view", "Dashboard"),

    # Quotation
    ("quotation:create", "建立報價"),
    ("quotation:update", "修改報價"),
    ("quotation:approve", "核准報價"),
]


with app.app_context():

    print("===== SEED PERMISSIONS =====")

    permission_map = {}

    # 建立 Permission
    for name, desc in PERMISSIONS:

        permission = Permission.query.filter_by(
            name=name
        ).first()

        if permission is None:

            permission = Permission(
                name=name,
                description=desc
            )

            db.session.add(permission)

        permission_map[name] = permission

    db.session.commit()

    # 重新取得 ID
    permission_map = {
        p.name: p
        for p in Permission.query.all()
    }

    admin = Role.query.filter_by(name="admin").first()
    engineer = Role.query.filter_by(name="engineer").first()
    manager = Role.query.filter_by(name="manager").first()
    vendor = Role.query.filter_by(name="vendor").first()

    if admin:
        admin.permissions = list(permission_map.values())

    if engineer:
        engineer.permissions = [
            permission_map["dashboard:view"],
            permission_map["ticket:list"],
            permission_map["ticket:update"],
            permission_map["ticket:assign"],
            permission_map["history:view"],
            permission_map["quotation:create"],
        ]

    if manager:
        manager.permissions = [
            permission_map["dashboard:view"],
            permission_map["ticket:list"],
            permission_map["quotation:approve"],
            permission_map["history:view"],
        ]

    if vendor:
        vendor.permissions = [
            permission_map["ticket:list"],
            permission_map["history:view"],
        ]

    db.session.commit()

    print()

    print("Permission:", Permission.query.count())

    print("Admin:", len(admin.permissions))
    print("Engineer:", len(engineer.permissions))
    print("Manager:", len(manager.permissions))
    print("Vendor:", len(vendor.permissions))

    print()
    print("===== DONE =====")