from app import app
from database.base import db


with app.app_context():

    result = db.session.execute(
        db.text(
            "PRAGMA table_info(roles)"
        )
    )


    for row in result:

        print(row)