from app import create_app
from models.user import User


app=create_app()


with app.app_context():

    user=User.query.filter_by(
        username="admin"
    ).first()


    print("================")
    print("PASSWORD CHECK")
    print("================")


    for pwd in [
        "admin",
        "admin123",
        "123456",
        "password"
    ]:

        print(
            pwd,
            user.check_password(pwd)
        )