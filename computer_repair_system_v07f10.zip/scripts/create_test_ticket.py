# 加入專案根目錄
import sys
import os

BASE_DIR = os.path.dirname(
    os.path.dirname(
        os.path.abspath(__file__)
    )
)

sys.path.append(BASE_DIR)

from app import app
from database.base import db

from models.customer import Customer
from models.device import Device
from models.repair_ticket import RepairTicket

import uuid

def create():

    with app.app_context():

        # 建立客戶
        customer = Customer(
            name="測試客戶",
            phone="0912345678",
            email="test@test.com"
        )

        db.session.add(customer)
        db.session.commit()


        # 建立設備        
        """
        device = Device(
            customer_id=customer.id,
            name="測試筆電",
            brand="ASUS",
            model="ROG"
        )
        """
        device = Device(

            device_type="Laptop",

            brand="Dell",

            model="Inspiron",

            serial_number="DL20260711001",

            description="測試筆電"

        )
        
        db.session.add(device)
        db.session.commit()



        # 建立維修單
        ticket = RepairTicket(

            ticket_no=f"TK-{uuid.uuid4().hex[:8].upper()}",

            customer_id=customer.id,

            device_id=device.id,

            title="測試電腦無法開機",

            description="按下電源無反應，需要檢測",

            status="new",

            priority="normal"
        )


        db.session.add(ticket)

        db.session.commit()


        print("================================")
        print("建立成功")
        print("Customer:", customer.id)
        print("Device:", device.id)
        print("Ticket:", ticket.id)
        print("================================")


if __name__ == "__main__":
    create()