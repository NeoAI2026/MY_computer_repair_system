from app import app
from database import db

from models.role import Role



DEFAULT_ROLES = [

    "admin",
    "engineer",
    "user"

]



def init():

    with app.app_context():

        for name in DEFAULT_ROLES:

            exists = Role.query.filter_by(
                name=name
            ).first()


            if exists:

                print(
                    f"✔ {name} exists"
                )

                continue


            role = Role(
                name=name
            )


            db.session.add(role)

            print(
                f"＋ create role: {name}"
            )


        db.session.commit()


        print(
            "\nRole initialization complete"
        )



if __name__ == "__main__":
    init()