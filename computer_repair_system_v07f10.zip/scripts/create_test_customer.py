from app import app
from database.base import db

from models.customer import Customer


def create():

    with app.app_context():

        customer = Customer(
            name="王小明",
            phone="0912345678",
            email="test@example.com"
        )

        db.session.add(customer)
        db.session.commit()


        print(
            "Customer 建立成功 ID:",
            customer.id
        )


if __name__ == "__main__":
    create()