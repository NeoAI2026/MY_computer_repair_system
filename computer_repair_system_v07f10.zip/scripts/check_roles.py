from app import app
from models.role import Role


def check():

    with app.app_context():

        roles = Role.query.all()

        print("\n===== ROLES =====")

        for r in roles:
            print(
                r.id,
                r.name
            )


if __name__ == "__main__":
    check()