# scripts/test_ticket_api_security.py

import requests


BASE_URL = "http://127.0.0.1:5000"


# =========================
# Test Users
# =========================

USERS = {
    "admin": {
        "username": "admin",
        "password": "admin123"
    },

    "engineer": {
        "username": "engineer",
        "password": "engineer123"
    },

    "manager": {
        "username": "manager",
        "password": "manager123"
    },

    "vendor": {
        "username": "vendor",
        "password": "vendor123"
    }
}



# =========================
# Login
# =========================

def login(username, password):

    print("================")
    print("LOGIN")
    print(username)


    r = requests.post(
        BASE_URL + "/api/auth/login",
        json={
            "username": username,
            "password": password
        }
    )


    print("STATUS:", r.status_code)


    if r.status_code != 200:

        print(r.text)

        return None


    return r.json()["access_token"]



# =========================
# Request Helper
# =========================
"""
def request_api(
        method,
        url,
        token,
        data=None
):


    headers = {

        "Authorization":
        "Bearer " + token

    }


    r = requests.request(

        method,

        BASE_URL + url,

        headers=headers,

        json=data

    )


    print(
        method,
        url,
        "=>",
        r.status_code
    )


    try:

        print(
            r.json()
        )

    except:

        print(
            r.text
        )


    print()


    return r
"""

def request_api(
        method,
        url,
        token,
        data=None
):

    try:

        headers = {
            "Authorization":
            "Bearer " + token
        }


        r = requests.request(
            method,
            BASE_URL + url,
            headers=headers,
            json=data,
            timeout=5
        )


        print(
            method,
            url,
            "=>",
            r.status_code
        )


        try:
            print(r.json())

        except:
            print(r.text)


        return r


    except Exception as e:

        print(
            "REQUEST ERROR:",
            e
        )

        return None


# =========================
# Create Ticket
# =========================

def test_create_ticket(token):

    print(
        "TEST ticket:create"
    )


    data = {

        "customer_name":
            "API測試客戶",

        "customer_phone":
            "0912345678",

        "customer_email":
            "test@test.com",


        "device_type":
            "Laptop",

        "brand":
            "ASUS",

        "model":
            "ROG",


        "serial_number":
            "TEST001",


        "title":
            "無法開機",


        "description":
            "按電源無反應",


        "priority":
            "high",

        "category":
            "hardware"

    }


    return request_api(

        "POST",

        "/api/tickets",

        token,

        data

    )



# =========================
# Main Test
# =========================


def test():


    print()
    print("======================")
    print("TICKET API SECURITY TEST")
    print("======================")


    tokens = {}



    # Login all users

    for role,user in USERS.items():

        token = login(

            user["username"],

            user["password"]

        )


        if token:

            tokens[role]=token



    print()
    print("======================")
    print("CREATE TEST")
    print("======================")


    if "admin" in tokens:

        test_create_ticket(
            tokens["admin"]
        )



    print()
    print("======================")
    print("LIST TEST")
    print("======================")


    for role in tokens:


        print(
            "ROLE:",
            role
        )


        request_api(

            "GET",

            "/api/tickets",

            tokens[role]

        )



    print()
    print("======================")
    print("UPDATE TEST")
    print("======================")


    for role in tokens:


        print(
            "ROLE:",
            role
        )


        request_api(

            "PUT",

            "/api/tickets/1",

            tokens[role],

            {

                "priority":
                "high"

            }

        )



    print()
    print("======================")
    print("ASSIGN TEST")
    print("======================")


    for role in tokens:


        print(
            "ROLE:",
            role
        )


        request_api(

            "PUT",

            "/api/tickets/1/assign",

            tokens[role],

            {

                "engineer_id":
                3

            }

        )



    print()
    print("======================")
    print("CLOSE TEST")
    print("======================")


    for role in tokens:


        print(
            "ROLE:",
            role
        )


        request_api(

            "POST",

            "/api/tickets/1/close",

            tokens[role]

        )



    print()
    print("======================")
    print("TEST COMPLETE")
    print("======================")




if __name__ == "__main__":

    test()