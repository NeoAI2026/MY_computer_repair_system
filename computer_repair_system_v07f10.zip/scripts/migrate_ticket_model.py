from app import app
from database import db
from sqlalchemy import text


NEW_COLUMNS = [

    ("customer_name", "VARCHAR(100)"),

    ("customer_phone", "VARCHAR(50)"),

    ("customer_email", "VARCHAR(120)"),


    ("device_type", "VARCHAR(50)"),

    ("brand", "VARCHAR(100)"),

    ("model", "VARCHAR(100)"),

    ("serial_number", "VARCHAR(100)"),


    ("category", "VARCHAR(50)"),

    ("priority", "VARCHAR(20)"),


    ("assigned_at", "DATETIME"),

    ("started_at", "DATETIME"),

    ("completed_at", "DATETIME"),

    ("closed_at", "DATETIME"),

]


def migrate():


    with app.app_context():


        conn = db.engine.connect()


        print(
            "\n===== Ticket Model Migration ====="
        )


        # 查目前欄位

        result = conn.execute(
            text(
                "PRAGMA table_info(repair_tickets)"
            )
        )


        existing = [

            row[1]

            for row in result

        ]


        print(
            "Existing Columns:"
        )

        print(existing)



        for name, datatype in NEW_COLUMNS:


            if name in existing:

                print(
                    f"SKIP {name}"
                )

                continue



            sql = f"""

            ALTER TABLE repair_tickets

            ADD COLUMN {name}

            {datatype}

            """


            conn.execute(
                text(sql)
            )


            print(
                f"ADD {name}"
            )



        conn.commit()


        conn.close()



        print(
            """
===== Migration Complete =====
"""
        )



if __name__ == "__main__":

    migrate()