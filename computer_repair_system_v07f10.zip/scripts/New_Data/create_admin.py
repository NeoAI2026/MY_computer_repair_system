from app import app
from database.base import db

from models.user import User
from models.role import Role


with app.app_context():


    admin_role = Role.query.filter_by(
        name="admin"
    ).first()


    if not admin_role:

        print(
            "請先執行 seed_rbac.py"
        )

        exit()



    user = User.query.filter_by(
        username="admin"
    ).first()



    if not user:

        """
        user = User(

            username="admin",

            email="admin@test.com",

            role=admin_role,

            active=True

        )
        """
        user = User(
            username="admin",
            role_id=admin_role.id
        )

        user.set_password(
            "admin123"
        )


        db.session.add(user)


        db.session.commit()


        print(
            "Admin created"
        )


    else:

        print(
            "Admin already exists"
        )