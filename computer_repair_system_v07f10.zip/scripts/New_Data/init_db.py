import sys
import os

from models.quotation import Quotation
from models.quotation_item import QuotationItem


# 加入專案根目錄
BASE_DIR = os.path.dirname(
    os.path.dirname(
        os.path.abspath(__file__)
    )
)

sys.path.append(BASE_DIR)

from app import app

from database.base import db

import models


with app.app_context():

    db.create_all()


    print(
        "CRMS Database Created"
    )