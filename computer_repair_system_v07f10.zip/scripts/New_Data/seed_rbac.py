from app import app
from database.base import db

from models.role import Role
from models.permission import Permission


PERMISSIONS = [

    "ticket:create",
    "ticket:list",
    "ticket:update",
    "ticket:assign",
    "ticket:close",

    "customer:list",
    "customer:create",
    "customer:update",

    "device:list",
    "device:create",
    "device:update",

    "user:list",
    "user:create",
    "user:update",

]


with app.app_context():

    print("=== RBAC Seed Start ===")


    # 建立 Permission

    permission_map = {}


    for name in PERMISSIONS:


        permission = Permission.query.filter_by(
            name=name
        ).first()


        if not permission:

            permission = Permission(
                name=name
            )

            db.session.add(permission)


        permission_map[name] = permission



    # 建立 Role

    admin = Role.query.filter_by(
        name="admin"
    ).first()


    if not admin:


        admin = Role(
            name="admin"
        )

        db.session.add(admin)



    db.session.commit()


    # 綁定全部權限

    admin.permissions = list(
        permission_map.values()
    )


    db.session.commit()


    print("RBAC Seed Complete")