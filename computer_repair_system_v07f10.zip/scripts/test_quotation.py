from app import app

from database.base import db

from models.repair_ticket import RepairTicket
from models.quotation import Quotation
from models.quotation_item import QuotationItem


with app.app_context():


    # 找一張維修單
    ticket = RepairTicket.query.first()


    if not ticket:

        print("❌ 沒有維修單，請先建立 RepairTicket")

        exit()


    # 建立報價單

    quotation = Quotation(

        quotation_no="Q20260711001",

        ticket_id=ticket.id,

        status="draft"

    )


    # 建立報價項目

    item1 = QuotationItem(

        name="SSD 1TB",

        item_type="part",

        quantity=1,

        unit_price=2500

    )


    item2 = QuotationItem(

        name="維修工資",

        item_type="labor",

        quantity=1,

        unit_price=800

    )


    # 加入報價明細

    quotation.items.append(item1)

    quotation.items.append(item2)



    # 計算金額

    quotation.calculate_total()



    db.session.add(quotation)

    db.session.commit()



    print("====================")

    print("報價建立成功")

    print("====================")

    print("報價單號:", quotation.quotation_no)

    print("小計:", quotation.subtotal)

    print("稅額:", quotation.tax)

    print("總額:", quotation.total_amount)
