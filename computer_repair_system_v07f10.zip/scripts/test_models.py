from app import app

from database.base import db

from models.user import User
from models.customer import Customer
from models.device import Device
from models.repair_ticket import RepairTicket
from models.quotation import Quotation
from models.quotation_item import QuotationItem
from models.repair_status import RepairStatus
from models.repair_history import RepairHistory



def test_model_query():

    print("\n========== CRMS MODEL TEST ==========\n")


    models = [

        ("User", User),

        ("Customer", Customer),

        ("Device", Device),

        ("RepairTicket", RepairTicket),

        ("Quotation", Quotation),

        ("QuotationItem", QuotationItem),

        ("RepairStatus", RepairStatus),

        ("RepairHistory", RepairHistory),

    ]


    for name, model in models:

        try:

            count = model.query.count()

            print(
                f"✅ {name:<20} OK  ({count} records)"
            )


        except Exception as e:

            print(
                f"❌ {name:<20} FAILED"
            )

            print(e)



def test_database_connection():

    print("\n========== DATABASE TEST ==========\n")


    try:

        db.session.execute(
            db.text("SELECT 1")
        )


        print(
            "✅ SQLite connection OK"
        )


    except Exception as e:

        print(
            "❌ Database connection FAILED"
        )

        print(e)



if __name__ == "__main__":

    with app.app_context():

        test_database_connection()

        test_model_query()


        print(
            "\n========== TEST FINISHED ==========\n"
        )