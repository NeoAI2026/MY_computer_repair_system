from app import create_app
from database.base import db

from models.user import User
from models.role import Role
from models.customer import Customer
from models.device import Device
from models.repair_ticket import RepairTicket
from models.repair_history import RepairHistory
from models.quotation import Quotation


def check(title, func):

    print("\n" + "=" * 50)
    print(title)
    print("=" * 50)

    try:
        result = func()
        print(result)
        print("OK")

    except Exception as e:
        print("ERROR")
        print(e)



def audit():

    app = create_app()

    with app.app_context():


        check(
            "USER TABLE",
            lambda:
            f"Users: {User.query.count()}"
        )


        check(
            "ROLE TABLE",
            lambda:
            f"Roles: {Role.query.count()}"
        )


        check(
            "CUSTOMER TABLE",
            lambda:
            f"Customers: {Customer.query.count()}"
        )


        check(
            "DEVICE TABLE",
            lambda:
            f"Devices: {Device.query.count()}"
        )


        check(
            "REPAIR TICKET TABLE",
            lambda:
            f"Tickets: {RepairTicket.query.count()}"
        )


        check(
            "REPAIR HISTORY TABLE",
            lambda:
            f"History: {RepairHistory.query.count()}"
        )


        check(
            "QUOTATION TABLE",
            lambda:
            f"Quotation: {Quotation.query.count()}"
        )


        print("\n")
        print("=" * 50)
        print("RELATIONSHIP CHECK")
        print("=" * 50)


        ticket = RepairTicket.query.first()


        if ticket:

            print(
                "Ticket:",
                ticket.ticket_no
            )

            print(
                "Customer:",
                ticket.customer.name
                if ticket.customer
                else None
            )


            print(
                "Device:",
                ticket.device.model
                if ticket.device
                else None
            )


            print(
                "History Count:",
                len(ticket.histories)
            )


        else:

            print(
                "No ticket data"
            )


        print("\n===== DATABASE AUDIT COMPLETE =====")



if __name__ == "__main__":

    audit()