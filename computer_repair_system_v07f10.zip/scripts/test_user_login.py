from app import create_app
from database.base import db
from models.user import User


app=create_app()


with app.app_context():

    print("====================")
    print("USER CHECK")
    print("====================")


    users=User.query.all()


    for u in users:

        print(
            u.id,
            u.username,
            u.password_hash,
            u.role.name if u.role else None
        )