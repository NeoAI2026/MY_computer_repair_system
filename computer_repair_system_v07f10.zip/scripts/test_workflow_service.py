from app import create_app

from models.repair_ticket import RepairTicket

from services.workflow_service import WorkflowService

app = create_app()

def test():

    

    with app.app_context():


        ticket = RepairTicket.query.first()


        if not ticket:

            print(
                "❌ 沒有維修單"
            )

            return



        print(
            "目前狀態:",
            ticket.status
        )



        WorkflowService.change_status(
            ticket,
            "wait_assign",
            remark="等待指派工程師"
        )

        WorkflowService.change_status(
            ticket,
            "assigned",
            remark="已指派工程師"
        )

        WorkflowService.change_status(
            ticket,
            "checking",
            remark="工程師開始檢測"
        )


        print(

            "更新後:",

            ticket.status

        )



        print(

            "歷程數:",

            len(ticket.histories)

        )

    flow = WorkflowService.STATUS_FLOW

    current = ticket.status
    next_list = flow.get(current, [])

    if not next_list:
        print("已經是最後狀態")
        return

    next_status = next_list[0]

    WorkflowService.change_status(
        ticket,
        next_status,
        remark=f"{current} -> {next_status}"
    )

    print(f"{current} -> {next_status}")


from app import app

if __name__=="__main__":
    with app.app_context():
        test()
        