from app import app
from database import db
from sqlalchemy import text


with app.app_context():

    result = db.session.execute(
        text(
            "PRAGMA table_info(repair_tickets)"
        )
    )


    for row in result:

        print(
            row[1],
            row[2]
        )