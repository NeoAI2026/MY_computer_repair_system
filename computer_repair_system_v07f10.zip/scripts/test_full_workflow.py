from app import app
from database import db

from models.repair_ticket import RepairTicket
from models.repair_history import RepairHistory
from models.user import User

from services.workflow_service import WorkflowService


def test():

    with app.app_context():

        print("\n===== CRMS Workflow Full Test =====")


        # 1. 找測試維修單

        #ticket = RepairTicket.query.first()
        ticket = RepairTicket.query.filter_by(
            status="new"
        ).first()

        if not ticket:
            print("❌ 找不到 RepairTicket")
            return


        print(
            f"""
Ticket:
ID={ticket.id}
NO={ticket.ticket_no}
STATUS={ticket.status}
"""
        )


        # 2. 指派工程師

        engineer = User.query.first()

        if engineer:

            WorkflowService.assign_engineer(
                ticket,
                engineer.id
            )

            print(
                "✅ assign_engineer OK"
            )


        # 3. 完整流程

        steps = [

            (
                "wait_assign",
                "等待指派工程師"
            ),

            (
                "assigned",
                "已指派工程師"
            ),

            (
                "checking",
                "工程師開始檢測"
            ),

            (
                "quotation",
                "建立報價"
            ),

            (
                "repairing",
                "開始維修"
            ),

            (
                "testing",
                "維修測試"
            ),

            (
                "completed",
                "維修完成"
            ),

            (
                "customer_check",
                "客戶確認"
            ),

            (
                "closed",
                "案件關閉"
            )

        ]


        for status, remark in steps:


            try:

                WorkflowService.change_status(

                    ticket,

                    status,

                    remark=f"測試流程：{remark}"

                )


                print(
                    f"✅STATUS => {ticket.status}"
                )


            except Exception as e:

                print(
                    f"❌ {ticket.status} -> {status}"
                )

                print(e)

                break



        db.session.commit()



        # 4. 檢查 History


        histories = RepairHistory.query.filter_by(

            ticket_id=ticket.id

        ).all()


        print("\n===== Repair History =====")


        for h in histories:

            print(

                f"""
{h.old_status}
 →
{h.new_status}

Remark:
{h.remark}

"""

            )


        print(
            f"""
History Count:
{len(histories)}
"""
        )


        print(
            """
===== TEST COMPLETE =====
"""
        )



if __name__ == "__main__":

    test()