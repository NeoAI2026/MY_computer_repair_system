import requests


BASE_URL = "http://127.0.0.1:5000"


def login(username, password):

    response = requests.post(
        f"{BASE_URL}/api/auth/login",
        json={
            "username": username,
            "password": password
        }
    )

    print("\nLOGIN:", username)
    print(response.status_code)

    data = response.json()

    return data.get("access_token")



def test_dashboard(
        username,
        password,
        url
):

    token = login(
        username,
        password
    )

    if not token:
        print("TOKEN ERROR")
        return


    headers = {
        "Authorization":
        f"Bearer {token}"
    }


    response = requests.get(
        f"{BASE_URL}{url}",
        headers=headers
    )


    print(
        username,
        url,
        "=>",
        response.status_code
    )

    try:
        print(response.json())

    except Exception:
        print("RAW RESPONSE:")
        print(response.text)



def test():

    print("======================")
    print("DASHBOARD RBAC TEST")
    print("======================")


    # admin
    test_dashboard(
        "admin",
        "admin123",
        "/dashboard/admin"
    )


    # engineer
    test_dashboard(
        "engineer",
        "engineer123",
        "/dashboard/engineer"
    )


    # manager
    test_dashboard(
        "manager",
        "manager123",
        "/dashboard/admin"
    )


    # vendor
    test_dashboard(
        "vendor",
        "vendor123",
        "/dashboard/vendor"
    )



if __name__ == "__main__":
    test()