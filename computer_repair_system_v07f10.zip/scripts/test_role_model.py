from app import app
from models.role import Role


with app.app_context():

    print("===== ROLE MODEL TEST =====")


    count = Role.query.count()


    print(
        "Role Count:",
        count
    )


    for role in Role.query.all():

        print(
            role.id,
            role.name
        )


    print("===== OK =====")