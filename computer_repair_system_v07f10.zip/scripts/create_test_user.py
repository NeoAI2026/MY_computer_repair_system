from app import app
from database import db

from models.user import User
from models.role import Role

from werkzeug.security import generate_password_hash



def create():

    with app.app_context():


        role = Role.query.filter_by(
            name="engineer"
        ).first()


        if not role:

            print(
                "❌ engineer role 不存在"
            )

            return



        exists = User.query.filter_by(
            username="engineer01"
        ).first()


        if exists:

            print(
                "⚠ engineer01 已存在"
            )

            return



        user = User(

            username="engineer01",

            email="engineer01@test.com",

            password_hash=
            generate_password_hash(
                "123456"
            ),

            role=role,

            active=True

        )


        db.session.add(user)

        db.session.commit()


        print(
            "✅ engineer01 建立完成"
        )



if __name__=="__main__":

    create()