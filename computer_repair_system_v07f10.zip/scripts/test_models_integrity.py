from app import app

from models.user import User
from models.customer import Customer
from models.repair_ticket import RepairTicket
from models.repair_history import RepairHistory
from models.quotation import Quotation


with app.app_context():

    print("===== MODEL CHECK =====")

    print(User.query.count())
    
    print(Customer.query.count())

    print(RepairTicket.query.count())

    print(RepairHistory.query.count())

    print(Quotation.query.count())


    print(
        "===== MODEL OK ====="
    )