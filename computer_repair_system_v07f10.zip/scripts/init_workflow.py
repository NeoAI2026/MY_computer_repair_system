from app import app
from database.base import db

from models.repair_status import RepairStatus



statuses = [

    (
        "NEW",
        "新報修",
        1,
        "客戶提出維修需求"
    ),

    (
        "WAIT_ASSIGN",
        "待派工",
        2,
        "等待主管派工程師"
    ),

    (
        "ASSIGNED",
        "已派工程師",
        3,
        "工程師接單"
    ),

    (
        "CHECKING",
        "檢測中",
        4,
        "工程師檢測設備"
    ),

    (
        "QUOTATION",
        "報價確認",
        5,
        "等待客戶確認報價"
    ),

    (
        "REPAIRING",
        "維修中",
        6,
        "開始維修"
    ),

    (
        "TESTING",
        "測試中",
        7,
        "維修完成測試"
    ),

    (
        "COMPLETED",
        "完工",
        8,
        "維修完成"
    ),

    (
        "CUSTOMER_CHECK",
        "客戶驗收",
        9,
        "等待客戶確認"
    ),

    (
        "CLOSED",
        "結案",
        10,
        "案件完成"
    )

]



def init():

    with app.app_context():

        for item in statuses:

            exists = RepairStatus.query.filter_by(
                code=item[0]
            ).first()


            if exists:
                continue


            status = RepairStatus(

                code=item[0],

                name=item[1],

                sequence=item[2],

                description=item[3]

            )


            db.session.add(status)


        db.session.commit()


        print(
            "Workflow status initialized"
        )



if __name__=="__main__":

    init()