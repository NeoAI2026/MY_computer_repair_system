from app import app
from database.base import db

from models.user import User
from models.customer import Customer
from models.device import Device
from models.repair_ticket import RepairTicket
from models.repair_history import RepairHistory

from datetime import datetime


def seed():

    with app.app_context():


        print("===== CRMS Seed Data =====")


        # =========================
        # User
        # =========================

        engineer = User.query.filter_by(
            username="engineer01"
        ).first()


        if not engineer:

            engineer = User(
                username="engineer01",
                email="engineer01@test.com",
                password_hash="test123",
                active=True
            )

            db.session.add(engineer)

            db.session.flush()


            print("Engineer created")


        # =========================
        # Customer
        # =========================

        customer = Customer(
            name="測試客戶",
            phone="0911111111",
            email="customer@test.com"
        )


        db.session.add(customer)

        db.session.flush()


        print("Customer created")


        # =========================
        # Device
        # =========================


        device = Device(

            customer_id=customer.id,

            device_type="Laptop",

            brand="ASUS",

            model="ROG",

            serial_number="TEST-001"

        )


        db.session.add(device)

        db.session.flush()


        print("Device created")



        # =========================
        # Ticket
        # =========================


        ticket = RepairTicket(

            ticket_no="TK-SEED001",

            customer_id=customer.id,

            device_id=device.id,

            title="測試電腦無法開機",

            description="按電源無反應",

            status="new",

            priority="high",

            category="hardware",

            workflow_started_at=datetime.utcnow()

        )


        db.session.add(ticket)

        db.session.flush()



        print(
            "Ticket created:",
            ticket.id
        )



        # =========================
        # History
        # =========================


        history = RepairHistory(

            ticket_id=ticket.id,

            old_status=None,

            new_status="new",

            remark="建立維修案件",

            created_at=datetime.utcnow()

        )


        db.session.add(history)



        db.session.commit()


        print()
        print("===== SEED COMPLETE =====")



if __name__ == "__main__":

    seed()