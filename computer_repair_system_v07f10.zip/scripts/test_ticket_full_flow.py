from app import app
from database.base import db

from models.repair_ticket import RepairTicket
from models.repair_history import RepairHistory

from models.user import User


def print_line():

    print("=" * 50)



def test():

    with app.app_context():

        print("\n===== CRMS Ticket Full Flow Test =====\n")


        client = app.test_client()


        # =====================================
        # 1. Create Ticket
        # =====================================

        print_line()
        print("1. CREATE TICKET")
        print_line()


        response = client.post(
            "/api/tickets",
            json={
                "customer_id": 1,
                "device_id": 1,
                "title": "Full Flow 測試電腦",
                "description": "整合測試案件",
                "priority": "normal"
            }
        )


        print("STATUS:", response.status_code)

        data = response.json

        print(data)


        ticket_id = data["ticket_id"]



        # =====================================
        # 2. Get Ticket
        # =====================================

        print_line()
        print("2. GET DETAIL")
        print_line()


        response = client.get(
            f"/api/tickets/{ticket_id}"
        )


        print(response.status_code)

        print(response.json)



        # =====================================
        # 3. Assign Engineer
        # =====================================

        print_line()
        print("3. ASSIGN ENGINEER")
        print_line()


        engineer = User.query.first()


        response = client.post(

            f"/api/tickets/{ticket_id}/assign",

            json={
                "engineer_id": engineer.id
            }

        )


        print(response.status_code)

        print(response.json)



        # =====================================
        # 4. Workflow
        # =====================================

        print_line()
        print("4. WORKFLOW")
        print_line()


        flow = [

            "wait_assign",
            "assigned",
            "checking",
            "quotation",
            "repairing",
            "testing",
            "completed",
            "customer_check",
            "closed"

        ]



        for status in flow:


            response = client.post(

                f"/api/tickets/{ticket_id}/status",

                json={

                    "status":status,

                    "remark":
                    f"Full Flow {status}"

                }

            )


            print(
                status,
                response.status_code,
                response.json

            )



        # =====================================
        # 5. History
        # =====================================


        print_line()

        print("5. REPAIR HISTORY")

        print_line()


        response = client.get(

            f"/api/tickets/{ticket_id}/history"

        )


        print(response.status_code)


        history=response.json


        print(history)



        # =====================================
        # 6. DB Verify
        # =====================================


        print_line()

        print("6. DATABASE VERIFY")

        print_line()



        ticket = db.session.get(

            RepairTicket,

            ticket_id

        )


        print(

f"""
ID:
{ticket.id}

NO:
{ticket.ticket_no}

STATUS:
{ticket.status}

TITLE:
{ticket.title}

"""

        )



        histories = RepairHistory.query.filter_by(

            ticket_id=ticket_id

        ).all()



        print(
            "History Count:",
            len(histories)
        )


        print("\n===== TEST COMPLETE =====")



if __name__ == "__main__":

    test()