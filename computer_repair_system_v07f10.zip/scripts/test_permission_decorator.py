import requests



BASE_URL="http://127.0.0.1:5000"

def login(username,password):

    r=requests.post(
        BASE_URL+"/api/auth/login",
        json={
            "username":username,
            "password":password
        }
    )

    


    print("================")
    print("LOGIN RESPONSE")
    print(username)
    print("LOGIN STATUS:", r.status_code)
    print("LOGIN RESPONSE:", r.text)
    print("================")


    if r.status_code != 200:
        return None

    data=r.json()

    return data.get("access_token")

"""
def login(username,password):

    r=requests.post(
        BASE_URL+"/api/auth/login",
        json={
            "username":username,
            "password":password
        }
    )

    print(
        username,
        r.status_code
    )


    return r.json()["access_token"]
"""



def test():


    users=[

        ("admin","admin123"),

        ("engineer","engineer123"),

        ("manager","manager123"),

        ("vendor","vendor123")

    ]


    print(
        "===== PERMISSION DECORATOR TEST ====="
    )


    for username,password in users:


        token=login(
            username,
            password
        )

        if token is None:
            print("LOGIN FAILED")
            return

        r=requests.get(

            BASE_URL+
            "/api/test/dashboard",

            headers={

                "Authorization":
                "Bearer "+token

            }

        )


        print()

        print(
            username,
            r.status_code
        )


        print("================")
        print("STATUS:")
        print(r.status_code)

        print("================")
        print("RAW:")
        print(r.text)

        print("================")


if __name__=="__main__":

    test()