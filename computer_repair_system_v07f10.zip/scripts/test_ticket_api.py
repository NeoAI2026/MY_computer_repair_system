from app import app

from models.repair_ticket import RepairTicket


def test():

    print("\n===== CRMS Ticket API Test =====")


    with app.app_context():

        client = app.test_client()


        # ======================
        # 1. Create Ticket
        # ======================

        print("\n1. CREATE TICKET")
        print("======================")


        response = client.post(

            "/api/tickets",

            json={

                "customer_id": 1,

                "device_id": 1,

                "title":
                    "API 測試電腦無法開機",

                "description":
                    "按下電源後沒有反應",

                "priority":
                    "normal"

            }

        )


        print(
            "STATUS:",
            response.status_code
        )

        print(
            response.json
        )


        if response.status_code != 201:

            print(
                "❌ Create Ticket Failed"
            )

            return


        ticket_id = response.json["ticket_id"]



        # ======================
        # 2. List Ticket
        # ======================

        print("\n2. LIST TICKETS")
        print("======================")


        response = client.get(

            "/api/tickets"

        )


        print(
            "STATUS:",
            response.status_code
        )

        print(
            response.json
        )



        # ======================
        # 3. Detail
        # ======================

        print("\n3. GET DETAIL")
        print("======================")


        response = client.get(

            f"/api/tickets/{ticket_id}"

        )


        print(
            "STATUS:",
            response.status_code
        )


        print(
            response.json
        )



        # ======================
        # 4. Update Ticket
        # ======================

        print("\n4. UPDATE TICKET")
        print("======================")


        response = client.put(

            f"/api/tickets/{ticket_id}",

            json={

                "priority":
                    "high",

                "description":
                    "更新：需要優先檢測"

            }

        )


        print(
            "STATUS:",
            response.status_code
        )


        print(
            response.json
        )



        # ======================
        # 5. Close Ticket
        # ======================

        print("\n5. CLOSE TICKET")
        print("======================")


        response = client.post(

            f"/api/tickets/{ticket_id}/close"

        )


        print(
            "STATUS:",
            response.status_code
        )


        print(
            response.json
        )



        # ======================
        # Verify DB
        # ======================

        print("\n6. DATABASE VERIFY")
        print("======================")


        ticket = RepairTicket.query.get(
            ticket_id
        )


        if ticket:


            print(
                f"""
ID:
{ticket.id}

NO:
{ticket.ticket_no}

STATUS:
{ticket.status}

TITLE:
{ticket.title}

PRIORITY:
{ticket.priority}
"""
            )


        print(
            """
===== TEST COMPLETE =====
"""
        )



if __name__ == "__main__":

    test()