from app import app


def test():


    client = app.test_client()


    ticket_id = 1


    print(
        "\n===== Repair History API Test ====="
    )


    response = client.get(
        f"/api/tickets/{ticket_id}/history"
    )


    print(
        "STATUS:",
        response.status_code
    )


    print(
        response.json
    )


    print(
        "\n===== TEST COMPLETE ====="
    )



if __name__ == "__main__":

    test()