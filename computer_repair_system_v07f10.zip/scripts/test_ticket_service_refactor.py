from app import app
from database.base import db

from models.customer import Customer
from models.device import Device
from models.repair_ticket import RepairTicket
from models.repair_history import RepairHistory

from services.ticket_service import TicketService


def test():

    with app.app_context():

        print()
        print("=" * 60)
        print("===== DEV-02.7.4 Ticket Service Refactor Test =====")
        print("=" * 60)


        # =====================================
        # 1. CREATE TICKET
        # =====================================

        print("\n1. CREATE TICKET")
        print("=" * 60)


        ticket = TicketService.create_ticket(

            customer_name="王小明",

            customer_phone="0912345678",

            customer_email="test@test.com",


            device_type="Laptop",

            brand="ASUS",

            model="ROG STRIX",

            serial_number="SN-TEST-001",


            title="無法開機測試",

            description="按下電源沒有反應",


            priority="high",

            category="hardware"

        )


        db.session.commit()


        print(
            "Ticket Created:"
        )


        print(
            ticket.id
        )


        print(
            ticket.ticket_no
        )



        # =====================================
        # 2. CUSTOMER VERIFY
        # =====================================

        print("\n2. CUSTOMER VERIFY")
        print("=" * 60)

        """
        customer = Customer.query.get(
            ticket.customer_id
        )
        """
        customer = db.session.get(
            Customer,
            ticket.customer_id
        )


        if customer:

            print(
                "Customer OK"
            )

            print(
                customer.name
            )

            print(
                customer.phone
            )

        else:

            print(
                "Customer FAIL"
            )



        # =====================================
        # 3. DEVICE VERIFY
        # =====================================


        print("\n3. DEVICE VERIFY")

        print("=" * 60)


        device = Device.query.get(
            ticket.device_id
        )


        if device:

            print(
                "Device OK"
            )

            print(
                device.brand,
                device.model
            )


        else:

            print(
                "Device FAIL"
            )



        # =====================================
        # 4. TICKET VERIFY
        # =====================================


        print("\n4. TICKET VERIFY")

        print("=" * 60)


        ticket = RepairTicket.query.get(
            ticket.id
        )


        print(
            "ID:",
            ticket.id
        )


        print(
            "STATUS:",
            ticket.status
        )


        print(
            "PRIORITY:",
            ticket.priority
        )


        print(
            "CATEGORY:",
            ticket.category
        )


        print(
            "WORKFLOW START:",
            ticket.workflow_started_at
        )



        # =====================================
        # 5. HISTORY VERIFY
        # =====================================


        print("\n5. HISTORY VERIFY")

        print("=" * 60)


        histories = RepairHistory.query.filter_by(

            ticket_id=ticket.id

        ).all()



        print(
            "History Count:",
            len(histories)
        )



        for h in histories:

            print(
                f"""
{h.old_status}

 →

{h.new_status}


Remark:

{h.remark}

"""
            )



        print()
        print("=" * 60)
        print("===== TEST COMPLETE =====")
        print("=" * 60)



if __name__ == "__main__":

    test()