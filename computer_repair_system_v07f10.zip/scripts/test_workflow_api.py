from models.repair_ticket import RepairTicket
from models.user import User

from app import app
from database import db

from models.repair_ticket import RepairTicket

"""
def test():

    
    with app.app_context():
        print(app.url_map)

        client = app.test_client()


        ticket = RepairTicket.query.first()


        if not ticket:

            print(
                "❌ 找不到 RepairTicket"
            )

            return


        print(
            f""
Ticket:
ID={ticket.id}
NO={ticket.ticket_no}
STATUS={ticket.status}
""
        )


        # API 測試開始


        response = client.get(
            f"/api/tickets/{ticket.id}/workflow"
        )


        print(
            response.status_code
        )

        print(
            response.json
        )



if __name__ == "__main__":

    test()

"""
def test():
    steps = [

        ("wait_assign", "等待指派工程師"),

        ("assigned", "已指派工程師"),

        ("checking", "工程師開始檢測"),

        ("quotation", "產生報價"),

        ("repairing", "開始維修"),

        ("testing", "維修測試"),

        ("completed", "維修完成"),

        ("customer_check", "客戶確認"),

        ("closed", "案件結案"),

    ]
    
    client = app.test_client()

    ticket = RepairTicket.query.filter_by(
            status="new"
        ).first()
    
    for status, remark in steps:

        response = client.post(

            f"/api/tickets/{ticket.id}/status",

            json={

                "status": status,

                "remark": remark

            }

        )

        print(status)
        print(response.status_code)
        print(response.json)

if __name__ == "__main__":
    with app.app_context():
        test()

"""
def print_response(title, response):

    print("\n======================")
    print(title)
    print("======================")

    print(
        "STATUS:",
        response.status_code
    )

    print(
        response.get_json()
    )


def test():

    print(
        "\n===== DEV-01.5.2 Workflow API Test ====="
    )


    with app.app_context():


        client = app.test_client()



        # ---------------------------------
        # 取得測試 Ticket
        # ---------------------------------

        #ticket = RepairTicket.query.first()
        ticket = RepairTicket.query.filter_by(
            status="new"
        ).first()

        if not ticket:

            print(
                "❌ No RepairTicket"
            )

            return



        print(
            f""
Ticket:
ID={ticket.id}
NO={ticket.ticket_no}
STATUS={ticket.status}
""
        )



        # ---------------------------------
        # 1. GET workflow
        # ---------------------------------

        response = client.get(

            f"/api/tickets/{ticket.id}/workflow"

        )


        print_response(

            "1. GET workflow",

            response

        )





        # ---------------------------------
        # 2. assign engineer
        # ---------------------------------

        engineer = User.query.first()


        if engineer:


            response = client.post(

                f"/api/tickets/{ticket.id}/assign",

                json={

                    "engineer_id":
                    engineer.id

                }

            )


            print_response(

                "2. assign engineer",

                response

            )




        # ---------------------------------
        # 3. change status
        # ---------------------------------


        next_status = "checking"



        response = client.post(

            f"/api/tickets/{ticket.id}/status",

            json={

                "status":
                next_status,


                "remark":
                "API測試：工程師開始檢測"

            }

        )


        print_response(

            "3. change status",

            response

        )





        # ---------------------------------
        # 4. history
        # ---------------------------------


        response = client.get(

            f"/api/tickets/{ticket.id}/history"

        )


        print_response(

            "4. history",

            response

        )



    print(
        ""
===== TEST COMPLETE =====
""
    )





if __name__ == "__main__":

    test()
    
"""