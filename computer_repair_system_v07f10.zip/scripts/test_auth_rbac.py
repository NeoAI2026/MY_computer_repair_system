import requests


BASE_URL = "http://127.0.0.1:5000"

def test_api(
    username,
    password,
    url,
    expected
):

    token = login(
        username,
        password
    )


    headers = {
        "Authorization":
        f"Bearer {token}"
    }


    r = requests.get(
        BASE_URL + url,
        headers=headers
    )


    print(
        username,
        url,
        r.status_code
    )


# =========================
# Login
# =========================

def login(username, password):

    url = f"{BASE_URL}/api/auth/login"

    payload = {
        "username": username,
        "password": password
    }

    r = requests.post(
        url,
        json=payload
    )

    print("================")
    print("LOGIN")
    print(username)
    print("STATUS:", r.status_code)

    if r.status_code != 200:
        print(r.text)
        return None


    data = r.json()

    return data["access_token"]



# =========================
# Permission Test
# =========================

def test_permission(
        username,
        password,
        permission,
        expect
):

    token = login(
        username,
        password
    )


    if not token:
        print("LOGIN FAILED")
        return

    PERMISSION_URL = {


        "user:create":
        "/api/test/admin",


        "ticket:create":
        "/api/test/ticket",


        "ticket:update":
        "/api/test/ticket",


        "ticket:list":
        "/api/test/ticket/list",


        "dashboard:view":
        "/api/test/dashboard",


        "quotation:approve":
        "/api/test/quotation"

    }

    url = (
        BASE_URL
        +
        PERMISSION_URL[permission]
    )

    """
    url = (
        f"{BASE_URL}"
        "/api/test/permission"
    )
    """

    headers = {
        "Authorization":
        f"Bearer {token}"
    }


    params = {
        "permission": permission
    }


    r = requests.get(
        url,
        headers=headers,
        params=params
    )


    print()
    print(
        username,
        permission
    )

    print(
        "STATUS:",
        r.status_code
    )

    print(
        r.text
    )


    if r.status_code == expect:
        print("PASS")
    else:
        print("FAIL")



# =========================
# Main Test
# =========================


def test():


    print(
        "\n"
        "===== AUTH RBAC TEST ====="
    )


    # -----------------
    # ADMIN
    # -----------------

    test_permission(
        "admin",
        "admin123",
        "user:create",
        200
    )


    test_permission(
        "admin",
        "admin123",
        "ticket:create",
        200
    )


    # -----------------
    # ENGINEER
    # -----------------

    test_permission(
        "engineer",
        "engineer123",
        "ticket:update",
        200
    )


    test_permission(
        "engineer",
        "engineer123",
        "user:create",
        403
    )


    # -----------------
    # MANAGER
    # -----------------

    test_permission(
        "manager",
        "manager123",
        "quotation:approve",
        200
    )


    test_permission(
        "manager",
        "manager123",
        "ticket:update",
        403
    )


    # -----------------
    # VENDOR
    # -----------------

    test_permission(
        "vendor",
        "vendor123",
        "ticket:list",
        200
    )


    test_permission(
        "vendor",
        "vendor123",
        "dashboard:view",
        403
    )


    print(
        "\n===== TEST COMPLETE ====="
    )



if __name__ == "__main__":
    test()