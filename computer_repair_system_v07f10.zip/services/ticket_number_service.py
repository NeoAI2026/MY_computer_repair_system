from datetime import datetime

from models.repair_ticket import RepairTicket


class TicketNumberService:


    PREFIX = "CRMS"



    @staticmethod
    def generate():


        today = datetime.now().strftime(
            "%Y%m%d"
        )


        prefix = f"{TicketNumberService.PREFIX}-{today}-"



        last_ticket = (
            RepairTicket.query
            .filter(
                RepairTicket.ticket_no.like(
                    f"{prefix}%"
                )
            )
            .order_by(
                RepairTicket.id.desc()
            )
            .first()
        )



        if last_ticket:


            last_number = int(
                last_ticket.ticket_no.split("-")[-1]
            )


            next_number = last_number + 1



        else:


            # 今天第一筆案件

            next_number = 1



        ticket_no = (
            f"{prefix}"
            f"{next_number:04d}"
        )



        return ticket_no