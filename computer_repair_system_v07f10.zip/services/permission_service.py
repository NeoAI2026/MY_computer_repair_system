from models.permission import Permission
from models.role import Role


class PermissionService:


    @staticmethod
    def has_permission(user, permission_name):

        role = user.role

        if not role:
            return False


        permissions = [
            p.name
            for p in role.permissions
        ]


        return permission_name in permissions