from models.repair_history import RepairHistory


class HistoryService:


    @staticmethod
    def get_ticket_history(ticket_id):

        histories = (
            RepairHistory.query
            .filter_by(ticket_id=ticket_id)
            .order_by(
                RepairHistory.created_at.asc()
            )
            .all()
        )


        return histories