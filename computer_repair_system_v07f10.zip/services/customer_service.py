from models.customer import Customer
from database.base import db


class CustomerService:


    @staticmethod
    def get_all():

        return Customer.query\
            .order_by(Customer.id.desc())\
            .all()



    @staticmethod
    def get_by_id(customer_id):

        return (
            Customer.query
            .filter_by(id=customer_id)
            .first()
        )



    @staticmethod
    def create(data):

        customer = Customer(

            name=data.get("name"),

            phone=data.get("phone"),

            email=data.get("email"),

            company=data.get("company"),

            address=data.get("address"),

            note=data.get("note")

        )


        db.session.add(customer)

        db.session.commit()


        return customer



    @staticmethod
    def update(customer,data):


        customer.name = data.get("name")

        customer.phone = data.get("phone")

        customer.email = data.get("email")

        customer.company = data.get("company")

        customer.address = data.get("address")

        customer.note = data.get("note")


        db.session.commit()


        return customer



    @staticmethod
    def delete(customer):

        db.session.delete(customer)

        db.session.commit()

    # =====================================
    # 維修案件使用
    # =====================================

    @staticmethod
    def get_or_create(
        name,
        phone=None,
        email=None
    ):


        customer = (
            Customer.query
            .filter_by(
                name=name,
                phone=phone
            )
            .first()
        )


        if customer:

            return customer



        customer = Customer(

            name=name,

            phone=phone,

            email=email

        )


        db.session.add(customer)

        db.session.commit()

        return customer
    
    @staticmethod
    def get(customer_id):

        return (
            Customer.query
            .filter_by(
                id=customer_id
            )
            .first()
        )


"""
from database.base import db
from models.customer import Customer



class CustomerService:



    @staticmethod
    def get_or_create(data):


        customer = Customer.query.filter_by(

            phone=data.get(
                "customer_phone"
            )

        ).first()



        if customer:

            return customer



        customer = Customer(

            name=data.get(
                "customer_name"
            ),

            phone=data.get(
                "customer_phone"
            )

        )


        db.session.add(customer)

        db.session.flush()


        return customer
"""