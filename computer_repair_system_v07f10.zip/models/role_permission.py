from database.base import db


role_permission = db.Table(
    "role_permissions",

    db.Column(
        "role_id",
        db.Integer,
        db.ForeignKey("roles.id")
    ),

    db.Column(
        "permission_id",
        db.Integer,
        db.ForeignKey("permissions.id")
    )
)


"""
from database.base import db


class RolePermission(db.Model):

    __tablename__ = "role_permissions"


    id = db.Column(
        db.Integer,
        primary_key=True
    )


    role_id = db.Column(
        db.Integer,
        db.ForeignKey(
            "roles.id"
        ),
        nullable=False
    )


    permission_id = db.Column(
        db.Integer,
        db.ForeignKey(
            "permissions.id"
        ),
        nullable=False
    )
"""