from database.base import db
from datetime import datetime


class RepairHistory(db.Model):

    __tablename__ = "repair_histories"


    id = db.Column(
        db.Integer,
        primary_key=True
    )


    ticket_id = db.Column(
        db.Integer,
        db.ForeignKey(
            "repair_tickets.id"
        ),
        nullable=False
    )


    # 指派對象 / 工程師
    user_id = db.Column(
        db.Integer,
        db.ForeignKey(
            "users.id"
        )
    )


    # 操作者
    operator_id = db.Column(
        db.Integer,
        db.ForeignKey(
            "users.id"
        )
    )


    old_status = db.Column(
        db.String(50)
    )


    new_status = db.Column(
        db.String(50)
    )


    remark = db.Column(
        db.Text
    )


    note = db.Column(
        db.Text
    )


    created_at = db.Column(
        db.DateTime,
        default=datetime.utcnow
    )


    ticket = db.relationship(
        "RepairTicket",
        back_populates="histories"
    )


    # 工程師 / 被指派人
    user = db.relationship(
        "User",
        foreign_keys=[user_id],
        back_populates="assigned_histories"
    )


    # 操作者
    operator = db.relationship(
        "User",
        foreign_keys=[operator_id],
        back_populates="repair_histories"
    )


"""
from database.base import db
from datetime import datetime


class RepairHistory(db.Model):

    __tablename__="repair_histories"


    id=db.Column(
        db.Integer,
        primary_key=True
    )


    ticket_id=db.Column(
        db.Integer,
        db.ForeignKey(
            "repair_tickets.id"
        ),
        nullable=False
    )

    ""
    user_id=db.Column(
        db.Integer,
        db.ForeignKey(
            "users.id"
        )
    )
    ""

    old_status=db.Column(
        db.String(50)
    )


    new_status=db.Column(
        db.String(50)
    )

    operator_id = db.Column(
        db.Integer,
        db.ForeignKey(
            "users.id"
        ),
        nullable=True
    )

    remark = db.Column(
        db.Text
    )

    note=db.Column(
        db.Text
    )


    created_at=db.Column(
        db.DateTime,
        default=datetime.utcnow
    )

    # Ticket 關係
    ticket=db.relationship(
        "RepairTicket",
        back_populates="histories"
    )

    # User 關係
    operator = db.relationship(
        "User",
        foreign_keys=[operator_id],
        back_populates="repair_histories"
    )
"""