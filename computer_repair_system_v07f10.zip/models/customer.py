from database.base import db
from datetime import datetime


class Customer(db.Model):

    __tablename__ = "customers"


    id = db.Column(
        db.Integer,
        primary_key=True
    )


    name = db.Column(
        db.String(100),
        nullable=False
    )


    phone = db.Column(
        db.String(50)
    )


    email = db.Column(
        db.String(120)
    )


    company = db.Column(
        db.String(120)
    )


    address = db.Column(
        db.String(255)
    )


    note = db.Column(
        db.Text
    )


    created_at = db.Column(
        db.DateTime,
        default=datetime.utcnow
    )


    updated_at = db.Column(
        db.DateTime,
        default=datetime.utcnow,
        onupdate=datetime.utcnow
    )


    # =====================
    # Relationship
    # =====================


    tickets = db.relationship(
        "RepairTicket",
        back_populates="customer",
        lazy=True
    )


    devices = db.relationship(
        "Device",
        back_populates="customer",
        cascade="all, delete",
        lazy=True
    )


    def __repr__(self):

        return self.name