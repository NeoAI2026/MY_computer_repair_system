from database.base import db


class QuotationItem(db.Model):

    __tablename__="quotation_items"


    id=db.Column(
        db.Integer,
        primary_key=True
    )


    quotation_id=db.Column(
        db.Integer,
        db.ForeignKey(
            "quotations.id"
        ),
        nullable=False
    )


    item_type=db.Column(
        db.String(30),
        default="service"
    )


    # service
    # part
    # labor


    name=db.Column(
        db.String(200),
        nullable=False
    )


    description=db.Column(
        db.Text
    )


    quantity=db.Column(
        db.Integer,
        default=1
    )

    price=db.Column(
            db.Float,
            default=0
        )

    unit_price=db.Column(
        db.Float,
        default=0
    )

    subtotal = db.Column(
        db.Float,
        default=0
    )

    amount=db.Column(
        db.Float,
        default=0
    )


    quotation=db.relationship(
        "Quotation",
        back_populates="items"
    )


    def calculate_amount(self):

        self.amount = (
            self.quantity *
            self.unit_price
        )

    @property
    def amount(self):

        return (
            (self.quantity or 0)
            *
            (self.unit_price or 0)
        )
