from database.base import db
from datetime import datetime


class Attachment(db.Model):

    __tablename__="attachments"


    id=db.Column(
        db.Integer,
        primary_key=True
    )


    ticket_id=db.Column(
        db.Integer,
        db.ForeignKey(
            "repair_tickets.id"
        )
    )


    filename=db.Column(
        db.String(255)
    )


    filepath=db.Column(
        db.String(500)
    )


    uploaded_at=db.Column(
        db.DateTime,
        default=datetime.utcnow
    )


    ticket=db.relationship(
        "RepairTicket",
        back_populates="attachments"
    )