from datetime import datetime

from database.base import db


class RepairStatus(db.Model):

    __tablename__ = "repair_statuses"

    id = db.Column(
        db.Integer,
        primary_key=True
    )

    code = db.Column(
        db.String(50),
        unique=True,
        nullable=False
    )

    name = db.Column(
        db.String(100),
        nullable=False
    )

    sequence = db.Column(
        db.Integer,
        nullable=False
    )

    description = db.Column(
        db.Text
    )

    active = db.Column(
        db.Boolean,
        default=True
    )

    created_at = db.Column(
        db.DateTime,
        default=datetime.utcnow
    )


    def __repr__(self):

        return f"<RepairStatus {self.code}>"