from database.base import db


class UserRole(db.Model):

    __tablename__="user_roles"


    id=db.Column(
        db.Integer,
        primary_key=True
    )


    user_id=db.Column(
        db.Integer,
        db.ForeignKey(
            "users.id"
        ),
        nullable=False
    )


    role_id=db.Column(
        db.Integer,
        db.ForeignKey(
            "roles.id"
        ),
        nullable=False
    )