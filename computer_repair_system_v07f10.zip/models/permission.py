"""
from database.base import db
from models.role_permission import role_permission

role_permission = db.Table(
    "role_permissions",

    db.Column(
        "role_id",
        db.Integer,
        db.ForeignKey("roles.id"),
        primary_key=True
    ),

    db.Column(
        "permission_id",
        db.Integer,
        db.ForeignKey("permissions.id"),
        primary_key=True
    )
)



class Permission(db.Model):

    __tablename__ = "permissions"


    id = db.Column(
        db.Integer,
        primary_key=True
    )


    name = db.Column(
        db.String(100),
        unique=True,
        nullable=False
    )


    description = db.Column(
        db.String(200)
    )
"""



from database.base import db
from models.role_permission import role_permission

class Permission(db.Model):

    __tablename__="permissions"


    id=db.Column(
        db.Integer,
        primary_key=True
    )


    name=db.Column(
        db.String(100),
        unique=True,
        nullable=False
    )


    description=db.Column(
        db.String(255)
    )

    roles=db.relationship(
        "Role",
        secondary=role_permission,
        back_populates="permissions"
    )
