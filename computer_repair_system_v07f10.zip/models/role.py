from database.base import db
#from models.permission import role_permission
from models.role_permission import role_permission

class Role(db.Model):

    __tablename__ = "roles"


    id = db.Column(
        db.Integer,
        primary_key=True
    )


    name = db.Column(
        db.String(50),
        unique=True,
        nullable=False
    )


    description = db.Column(
        db.String(200)
    )


    users = db.relationship(
        "User",
        secondary="user_roles",
        back_populates="role"
    )

    permissions = db.relationship(
        "Permission",
        secondary=role_permission,
        back_populates="roles"
    )