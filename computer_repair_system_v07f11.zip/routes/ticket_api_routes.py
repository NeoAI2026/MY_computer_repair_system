from flask import Blueprint, jsonify, request

from services.ticket_service import TicketService

from flask_jwt_extended import jwt_required

from middleware.permission import permission_required

ticket_api_bp = Blueprint(
    "ticket_api",
    __name__
)



@ticket_api_bp.route(
    "/api/tickets",
    methods=["GET"]
)
@jwt_required()
@permission_required(
    "ticket:list"
)
def list_tickets():


    keyword = request.args.get(
        "keyword"
    )


    status = request.args.get(
        "status"
    )



    tickets = TicketService.get_all(
        keyword,
        status
    )



    result=[]



    for t in tickets:


        result.append({

            "id":t.id,

            "ticket_no":
                t.ticket_no,


            "title":
                t.title,


            "status":
                t.status,


            "priority":
                t.priority,


            "customer_name":
                (
                    t.customer.name
                    if t.customer
                    else None
                ),


            "device_type":
                (
                    t.device.device_type
                    if t.device
                    else None
                ),


            "engineer":
                (
                    t.engineer.username
                    if t.engineer
                    else None
                )

        })


    return jsonify(result)