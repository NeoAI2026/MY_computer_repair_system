from flask import (
    Blueprint,
    render_template,
    request,
    redirect,
    url_for,
    flash
)

from flask_jwt_extended import jwt_required

from services.user_service import UserService
from models.role import Role

user_admin_bp = Blueprint(
    "user_admin",
    __name__
)

@user_admin_bp.route("/users")
@jwt_required()
def user_list():

    users = UserService.get_all()

    return render_template(
        "users/user_list.html",
        users=users
    )

@user_admin_bp.route(
    "/users/add",
    methods=["GET","POST"]
)
@jwt_required()
def user_add():

    roles = Role.query.all()

    if request.method=="POST":

        UserService.create(request.form)

        flash("新增成功")

        return redirect(
            url_for(
                "user_admin.user_list"
            )
        )

    return render_template(
        "users/user_add.html",
        roles=roles
    )

@user_admin_bp.route(
    "/users/<int:id>/edit",
    methods=["GET","POST"]
)
@jwt_required()
def user_edit(id):

    user = UserService.get(id)

    roles = Role.query.all()

    if request.method=="POST":

        UserService.update(
            user,
            request.form
        )

        flash("修改完成")

        return redirect(
            url_for(
                "user_admin.user_list"
            )
        )

    return render_template(
        "users/user_edit.html",
        user=user,
        roles=roles
    )

@user_admin_bp.route(
    "/users/<int:id>/delete"
)
@jwt_required()
def user_delete(id):

    user = UserService.get(id)

    UserService.delete(user)

    flash("刪除成功")

    return redirect(
        url_for(
            "user_admin.user_list"
        )
    )

