from database.base import db
from models.user import User
from models.role import Role


class UserService:

    @staticmethod
    def get_all():
        return User.query.order_by(User.id).all()

    @staticmethod
    def get(user_id):
        return User.query.get_or_404(user_id)
    
    @staticmethod
    def get_engineers():

        return (
            User.query
            .join(Role)
            .filter(
                Role.name=="engineer"
            )
            .all()
        )

    @staticmethod
    def create(data):

        user = User()

        user.username = data["username"]
        user.name = data["name"]
        user.email = data["email"]
        user.phone = data["phone"]
        user.role_id = int(data["role_id"])

        user.set_password(data["password"])

        db.session.add(user)
        db.session.commit()

        return user

    @staticmethod
    def update(user, data):

        user.name = data["name"]
        user.email = data["email"]
        user.phone = data["phone"]
        user.role_id = int(data["role_id"])

        db.session.commit()

        return user

    @staticmethod
    def delete(user):

        db.session.delete(user)
        db.session.commit()


"""
from database.base import db

from models.user import User
from models.role import Role


class UserService:


    @staticmethod
    def get_all():

        return (
            User.query
            .order_by(User.id)
            .all()
        )



    @staticmethod
    def get_user(user_id):

        return (
            User.query
            .filter_by(id=user_id)
            .first()
        )


    

    @staticmethod
    def get_engineers():

        return User.query.join(
            Role
        ).filter(
            Role.name=="engineer"
        ).all()



    @staticmethod
    def create_user(data):


        user = User(

            username=data["username"],

            email=data.get(
                "email"
            ),

            role=data.get(
                "role",
                "user"
            )

        )


        user.set_password(
            data["password"]
        )


        db.session.add(user)

        db.session.commit()


        return user
"""