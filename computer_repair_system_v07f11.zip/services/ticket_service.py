from datetime import datetime
import uuid

from database.base import db

from models.customer import Customer
from models.device import Device
from models.repair_ticket import RepairTicket
from models.repair_history import RepairHistory

from services.ticket_number_service import TicketNumberService
from services.customer_service import CustomerService

class TicketService:


    @staticmethod
    def create_ticket(data, creator_id=None):

        ticket_no = TicketNumberService.generate()
        
        customer = CustomerService.get_or_create(
            name=data.get(
                "customer_name"
            ),

            phone=data.get(
                "customer_phone"
            ),

            email=data.get(
                "customer_email"
            )
        )

        ticket = RepairTicket(
            ticket_no=ticket_no,

            customer_id=customer.id,

            customer_name=customer.name,

            customer_phone=customer.phone,
            
            device_id=data.get(
                "device_id"
            ),

            device_type=data.get(
                "device_type"
            ),


            brand=data.get(
                "brand"
            ),


            model=data.get(
                "model"
            ),


            title=data.get(
                "title"
            ),


            description=data.get(
                "description"
            ),


            status="new",


            priority=data.get(
                "priority",
                "normal"
            )

        )


        db.session.add(ticket)

        db.session.flush()



        # 建立初始歷程

        history = RepairHistory(

            ticket_id=ticket.id,

            old_status=None,

            new_status="new",

            operator_id=creator_id,

            remark="建立維修案件"

        )


        db.session.add(history)



        db.session.commit()



        return ticket


    @staticmethod
    def search(keyword=None,status=None):


        query = RepairTicket.query



        if keyword:


            query=query.filter(

                db.or_(

                    RepairTicket.ticket_no.like(
                        f"%{keyword}%"
                    ),

                    RepairTicket.title.like(
                        f"%{keyword}%"
                    ),

                    RepairTicket.customer_name.like(
                        f"%{keyword}%"
                    )

                )

            )



        if status:


            query=query.filter(

                RepairTicket.status==status

            )



        return query.order_by(

            RepairTicket.id.desc()

        ).all()


    # ==========================
    # Get One
    # ==========================
    @staticmethod
    def get_ticket(ticket_id):
        return RepairTicket.query.get(ticket_id)

    # ==========================
    # Get All
    # ==========================
    @staticmethod
    def get_all(
        keyword=None,
        status=None
    ):


        query = RepairTicket.query



        if keyword:


            query=query.filter(

                RepairTicket.title.like(
                    f"%{keyword}%"
                )

            )



        if status:


            query=query.filter(

                RepairTicket.status==status

            )



        return query.order_by(

            RepairTicket.id.desc()

        ).all()

    

    # ==========================
    # Update
    # ==========================
    @staticmethod
    def update_ticket(ticket, data):

        old_status = ticket.status

        if "title" in data:
            ticket.title = data["title"]

        if "description" in data:
            ticket.description = data["description"]

        if "priority" in data:
            ticket.priority = data["priority"]

        if "category" in data:
            ticket.category = data["category"]

        # =====================
        # Status 更新
        # =====================

        if "status" in data:

            new_status = data["status"]


            if old_status != new_status:


                ticket.status = new_status


                history = RepairHistory(

                    ticket_id=ticket.id,

                    old_status=old_status,

                    new_status=new_status,

                    operator_id=None,

                    remark=f"狀態更新 {old_status} → {new_status}",

                    created_at=datetime.utcnow()

                )


                db.session.add(history)

                ticket.updated_at = datetime.utcnow()

                db.session.commit()

                return ticket

    # ==========================
    # Assign Engineer
    # ==========================
    @staticmethod
    def assign_engineer(ticket_id, engineer_id):

        ticket = RepairTicket.query.get(ticket_id)

        if ticket is None:
            return None

        ticket.engineer_id = int(engineer_id)
        #ticket.assigned_at = datetime.utcnow()
        #ticket.updated_at = datetime.utcnow()
        """
        history = RepairHistory(
            ticket_id=ticket.id,
            old_status=ticket.status,
            new_status=ticket.status,
            operator_id=engineer_id,
            remark="指派工程師",
            created_at=datetime.utcnow()
        )
        """
        #db.session.add(history)
        db.session.commit()

        return ticket

    # ==========================
    # Change Status
    # ==========================
    @staticmethod
    def change_status(ticket, new_status, operator_id=None):

        old_status = ticket.status

        ticket.status = new_status
        ticket.updated_at = datetime.utcnow()

        history = RepairHistory(
            ticket_id=ticket.id,
            old_status=old_status,
            new_status=new_status,
            operator_id=operator_id,
            remark=f"狀態變更：{old_status} → {new_status}",
            created_at=datetime.utcnow()
        )

        db.session.add(history)
        db.session.commit()

        return ticket

    # ==========================
    # Close Ticket
    # ==========================
    @staticmethod
    def close_ticket(ticket, operator_id=None):

        old_status = ticket.status

        ticket.status = "closed"
        ticket.completed_at = datetime.utcnow()
        ticket.closed_at = datetime.utcnow()
        ticket.updated_at = datetime.utcnow()

        history = RepairHistory(
            ticket_id=ticket.id,
            old_status=old_status,
            new_status="closed",
            operator_id=operator_id,
            remark="案件結案",
            created_at=datetime.utcnow()
        )

        db.session.add(history)
        db.session.commit()

        return ticket

    # ==========================
    # Delete
    # ==========================
    @staticmethod
    def delete_ticket(ticket):

        db.session.delete(ticket)
        db.session.commit()

        return True
    
    @staticmethod
    def get_engineer_tickets(user_id):

        return (
            RepairTicket.query
            .filter_by(engineer_id=user_id)
            .order_by(RepairTicket.id.desc())
            .all()
        )
    
    @staticmethod
    def get_waiting_parts():

        return (
            RepairTicket.query
            .filter(
                RepairTicket.status == "waiting_parts"
            )
            .all()
        )