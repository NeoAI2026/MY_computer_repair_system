from datetime import datetime

from database.base import db


"""
class RepairTicket(db.Model):

    __tablename__ = "repair_tickets"

    __table_args__ = {
        "extend_existing": True
    }


    id = db.Column(
        db.Integer,
        primary_key=True
    )


    ticket_no = db.Column(
        db.String(50),
        unique=True,
        nullable=False
    )


    title = db.Column(
        db.String(200),
        nullable=False
    )


    description = db.Column(
        db.Text
    )


    status = db.Column(
        db.String(50),
        default="new"
    )


    priority = db.Column(
        db.String(50),
        default="normal"
    )


    customer_id = db.Column(
        db.Integer,
        db.ForeignKey(
            "customers.id"
        )
    )


    device_id = db.Column(
        db.Integer,
        db.ForeignKey(
            "devices.id"
        )
    )


    engineer_id = db.Column(
        db.Integer,
        db.ForeignKey(
            "users.id"
        )
    )


    created_at = db.Column(
        db.DateTime,
        default=datetime.utcnow
    )


    updated_at = db.Column(
        db.DateTime,
        default=datetime.utcnow,
        onupdate=datetime.utcnow
    )



    # =====================
    # Relationship
    # =====================


    customer = db.relationship(
        "Customer",
        backref="tickets"
    )


    device = db.relationship(
        "Device",
        backref="tickets"
    )


    engineer = db.relationship(
        "User",
        foreign_keys=[engineer_id]
    )



    def __repr__(self):

        return (
            f"<RepairTicket {self.ticket_no}>"
        )
"""