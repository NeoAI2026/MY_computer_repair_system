from app import create_app

from database.base import db

from models.role import Role
from models.permission import Permission



app = create_app()



ROLE_PERMISSION_MAP = {


    "admin":[

        "ticket:list",
        "ticket:view",
        "ticket:create",
        "ticket:update",
        "ticket:delete"

    ],

    "manager":[

        "ticket:list",
        "ticket:view",
        "ticket:create",
        "ticket:update"

    ],

    "engineer":[

        "ticket:list",
        "ticket:view",
        "ticket:update"

    ],

    "vendor":[

        "ticket:list",
        "ticket:view"

    ],


    "user":[

        "ticket:view"

    ]

}



with app.app_context():


    for role_name, permissions in ROLE_PERMISSION_MAP.items():


        role = Role.query.filter_by(
            name=role_name
        ).first()



        if not role:

            print(
                "ROLE NOT FOUND:",
                role_name
            )

            continue



        for perm_name in permissions:


            permission = Permission.query.filter_by(
                name=perm_name
            ).first()



            if not permission:

                print(
                    "PERMISSION NOT FOUND:",
                    perm_name
                )

                continue



            if permission not in role.permissions:

                role.permissions.append(
                    permission
                )

                print(
                    "ADD",
                    role_name,
                    "->",
                    perm_name
                )



    db.session.commit()



print(
    "Role Permission Mapping Completed"
)