from app import create_app
from database.base import db
from models.role import Role


app=create_app()


roles=[

    "admin",

    "manager",

    "engineer",

    "vendor",

    "user"

]


with app.app_context():


    for name in roles:


        exists = Role.query.filter_by(
            name=name
        ).first()


        if not exists:


            role=Role(

                name=name

            )


            db.session.add(role)



    db.session.commit()


    print(
        "Roles seed completed"
    )