from app import create_app

from database.base import db

from models.permission import Permission



app = create_app()



permissions = [

    "ticket:list",

    "ticket:view",

    "ticket:update",

    "ticket:create",

    "ticket:delete"

]



with app.app_context():


    for name in permissions:


        exists = Permission.query.filter_by(
            name=name
        ).first()



        if exists:

            print(
                f"EXISTS: {name}"
            )

            continue



        permission = Permission(

            name=name

        )


        db.session.add(
            permission
        )


        print(
            f"CREATE: {name}"
        )



    db.session.commit()



print(
    "Permission fix completed"
)