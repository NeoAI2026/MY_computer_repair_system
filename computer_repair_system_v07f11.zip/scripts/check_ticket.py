from app import create_app
from database.base import db
from models import RepairTicket


app=create_app()


with app.app_context():

    tickets=RepairTicket.query.all()


    print(
        "Ticket count:",
        len(tickets)
    )


    for t in tickets:

        print(
            t.id,
            t.ticket_no,
            t.engineer_id
        )