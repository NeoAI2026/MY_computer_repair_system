from app import app
from database.base import db

# 所有 Models
from models.role import Role
from models.user import User
from models.customer import Customer
from models.device import Device
from models.repair_ticket import RepairTicket
from models.repair_history import RepairHistory


with app.app_context():

    db.create_all()

    print("Database initialized.")