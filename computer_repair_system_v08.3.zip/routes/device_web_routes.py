from flask import (
    Blueprint,
    render_template,
    request,
    redirect,
    url_for,
    flash
)

from flask_jwt_extended import jwt_required

from services.device_service import DeviceService
from services.customer_service import CustomerService

from models.device import Device



device_web_bp = Blueprint(
    "device_web",
    __name__,
    url_prefix="/devices"
)


@device_web_bp.route(
    "/devices/<int:id>"
)
@jwt_required()
def detail(id):


    device = Device.query.get_or_404(
        id
    )


    return render_template(
        "devices/devices_detail.html",
        device=device
    )


@device_web_bp.route("")
@jwt_required()
def device_list():


    devices = DeviceService.get_all()


    return render_template(
        "devices/device_list.html",
        devices=devices
    )





@device_web_bp.route(
    "/add",
    methods=[
        "GET",
        "POST"
    ]
)
@jwt_required()
def add_device():


    customers = (
        CustomerService
        .get_all()
    )


    if request.method=="POST":


        data={

            "customer_id":
                request.form.get(
                    "customer_id"
                ),


            "device_type":
                request.form.get(
                    "device_type"
                ),


            "brand":
                request.form.get(
                    "brand"
                ),


            "model":
                request.form.get(
                    "model"
                ),


            "serial_number":
                request.form.get(
                    "serial_number"
                ),


            "note":
                request.form.get(
                    "note"
                )

        }


        DeviceService.create(
            data
        )


        flash(
            "設備新增成功",
            "success"
        )


        return redirect(
            url_for(
                "device_web.device_list"
            )
        )



    return render_template(
        "devices/devices_add.html",
        customers=customers
    )






@device_web_bp.route(
    "/<int:id>/delete"
)
@jwt_required()
def delete_device(id):


    device = (
        DeviceService.get(id)
    )


    if device:

        DeviceService.delete(
            device
        )


        flash(
            "設備刪除成功",
            "success"
        )


    return redirect(
        url_for(
            "device_web.device_list"
        )
    )
