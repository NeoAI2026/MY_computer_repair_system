from datetime import datetime

from database.base import db



class Device(db.Model):

    __tablename__ = "devices"



    id = db.Column(

        db.Integer,

        primary_key=True

    )



    customer_id = db.Column(

        db.Integer,

        db.ForeignKey(
            "customers.id"
        ),

        nullable=False

    )



    device_type = db.Column(

        db.String(50)

    )


    brand = db.Column(

        db.String(100)

    )


    model = db.Column(

        db.String(100)

    )


    serial_number = db.Column(

        db.String(100),

        unique=True

    )


    note = db.Column(

        db.Text

    )



    created_at = db.Column(

        db.DateTime,

        default=datetime.utcnow

    )


    updated_at = db.Column(

        db.DateTime,

        default=datetime.utcnow,

        onupdate=datetime.utcnow

    )



    # ==================================================
    # Relationship
    # ==================================================


    # Device -> Customer

    customer = db.relationship(

        "Customer",

        back_populates="devices"

    )



    # Device -> RepairTicket

    tickets = db.relationship(

        "RepairTicket",

        back_populates="device"

    )



    def __repr__(self):

        return (

            f"<Device {self.brand} {self.model}>"

        )