from database.base import db
from datetime import datetime


class TicketHistory(db.Model):

    __tablename__="ticket_histories"


    id=db.Column(
        db.Integer,
        primary_key=True
    )


    ticket_id=db.Column(
        db.Integer,
        db.ForeignKey(
            "repair_tickets.id"
        )
    )


    old_status=db.Column(
        db.String(50)
    )


    new_status=db.Column(
        db.String(50)
    )


    note=db.Column(
        db.Text
    )


    created_at=db.Column(
        db.DateTime,
        default=datetime.utcnow
    )


    ticket=db.relationship(
        "RepairTicket",
        back_populates="histories"
    )