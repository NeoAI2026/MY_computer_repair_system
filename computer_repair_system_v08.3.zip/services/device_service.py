from database.base import db

from models.device import Device



class DeviceService:



    @staticmethod
    def get_all():

        return Device.query.order_by(
            Device.created_at.desc()
        ).all()



    @staticmethod
    def get_detail(device_id):

        return (
            Device.query
            .filter_by(
                id=device_id
            )
            .first()
        )
    

    @staticmethod
    def get(device_id):

        return Device.query.get(
            device_id
        )



    @staticmethod
    def create(data):


        device = Device(

            customer_id=data["customer_id"],

            device_type=data.get(
                "device_type"
            ),

            brand=data.get(
                "brand"
            ),

            model=data.get(
                "model"
            ),

            serial_number=data.get(
                "serial_number"
            ),

            note=data.get(
                "note"
            )

        )
        
        db.session.add(device)

        db.session.commit()


        return device


    """
    @staticmethod
    def update(device,data):


        for key,value in data.items():

            setattr(
                device,
                key,
                value
            )

        db.session.commit()


        return device
    """
    @staticmethod
    def update(device,data):


        device.device_type = (
            data.get(
                "device_type"
            )
        )


        device.brand = (
            data.get(
                "brand"
            )
        )


        device.model = (
            data.get(
                "model"
            )
        )


        device.serial_number = (
            data.get(
                "serial_number"
            )
        )


        device.note = (
            data.get(
                "note"
            )
        )


        db.session.commit()


        return device        


    


    @staticmethod
    def delete(device):


        db.session.delete(device)

        db.session.commit()
