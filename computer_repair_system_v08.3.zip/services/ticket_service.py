from datetime import datetime

from database.base import db

from models.repair_ticket import RepairTicket
from models.customer import Customer
from models.device import Device



class TicketService:


    @staticmethod
    def create_ticket(data, creator_id):


        customer = Customer.query.get(
            data["customer_id"]
        )


        if customer is None:
            raise ValueError(
                "Customer not found"
            )


        device = Device.query.get(
            data["device_id"]
        )


        if device is None:
            raise ValueError(
                "Device not found"
            )


        ticket_no = (
            f"CRMS-{datetime.now():%Y%m%d%H%M%S}"
        )


        ticket = RepairTicket(

            ticket_no=ticket_no,

            customer_id=customer.id,

            device_id=device.id,

            creator_id=creator_id,

            assigned_engineer_id=None,

            title=data.get(
                "title"
            ),

            problem=data.get(
                "problem"
            ),

            solution="",

            status="new",

            priority=data.get(
                "priority",
                "normal"
            )

        )


        db.session.add(ticket)

        db.session.commit()


        return ticket



    @staticmethod
    def get_ticket(ticket_id):


        return RepairTicket.query.get(
            ticket_id
        )



    @staticmethod
    def get_all():


        return RepairTicket.query.order_by(
            RepairTicket.created_at.desc()
        ).all()



    @staticmethod
    def assign_engineer(
        ticket_id,
        engineer_id
    ):


        ticket = RepairTicket.query.get(
            ticket_id
        )


        if ticket is None:
            raise ValueError(
                "Ticket not found"
            )


        ticket.assigned_engineer_id = (
            engineer_id
        )


        ticket.status = "assigned"


        db.session.commit()


        return ticket