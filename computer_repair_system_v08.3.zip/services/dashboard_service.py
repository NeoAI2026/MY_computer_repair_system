from models.repair_ticket import RepairTicket
from models.user import User
from models.customer import Customer
from models.device import Device


class DashboardService:


    @staticmethod
    def get_admin_dashboard():


        total_ticket = RepairTicket.query.count()


        new_ticket = RepairTicket.query.filter_by(
            status="new"
        ).count()


        repairing_ticket = RepairTicket.query.filter_by(
            status="repairing"
        ).count()


        completed_ticket = RepairTicket.query.filter_by(
            status="completed"
        ).count()


        engineers = User.query.filter_by(
            role="engineer"
        ).count()


        customers = Customer.query.count()


        devices = Device.query.count()


        return {


            "total_ticket":
                total_ticket,


            "new_ticket":
                new_ticket,


            "repairing_ticket":
                repairing_ticket,


            "completed_ticket":
                completed_ticket,


            "engineers":
                engineers,


            "customers":
                customers,


            "devices":
                devices

        }