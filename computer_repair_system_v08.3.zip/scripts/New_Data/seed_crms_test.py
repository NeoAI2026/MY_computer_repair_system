from datetime import datetime

from app import app

from database.base import db

from models.customer import Customer
from models.device import Device
from models.repair_ticket import RepairTicket
from models.user import User



with app.app_context():


    print("===== CRMS TEST DATA =====")


    # -----------------------
    # Customer
    # -----------------------

    customer = Customer(

        name="測試客戶",

        phone="0912345678",

        email="test@test.com",

        company="CRMS TEST"

    )


    db.session.add(customer)

    db.session.flush()



    # -----------------------
    # Device
    # -----------------------

    device = Device(

        customer_id=customer.id,

        device_type="Notebook",

        brand="ACER",

        model="Aspire 5",

        serial_number="TEST-00001",

        note="測試設備"

    )


    db.session.add(device)

    db.session.flush()



    # -----------------------
    # User
    # -----------------------

    engineer = User.query.first()


    if engineer:

        engineer_id = engineer.id

    else:

        engineer_id = None



    # -----------------------
    # Ticket
    # -----------------------

    ticket = RepairTicket(

        ticket_no=f"CRMS-{datetime.now():%Y%m%d%H%M%S}",

        customer_id=customer.id,

        device_id=device.id,

        creator_id=1,

        assigned_engineer_id=engineer_id,

        title="無法開機測試",

        problem="按下電源無反應",

        solution="",

        status="new",

        priority="normal"

    )


    db.session.add(ticket)


    db.session.commit()



    print("========================")

    print("Customer ID:", customer.id)

    print("Device ID:", device.id)

    print("Ticket ID:", ticket.id)

    print("Ticket No:", ticket.ticket_no)

    print("========================")