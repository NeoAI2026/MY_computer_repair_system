from app import app
from sqlalchemy import inspect
from database.base import db

TABLES = [
    "roles",
    "users",
    "customers",
    "devices",
    "repair_tickets",
    "repair_histories",
]


with app.app_context():

    inspector = inspect(db.engine)

    print("=" * 50)
    print("CRMS DATABASE CHECK")
    print("=" * 50)

    existing = inspector.get_table_names()

    for table in TABLES:

        if table in existing:

            print(f"{table:<25} OK")

        else:

            print(f"{table:<25} MISSING")

    print("=" * 50)

    if "repair_tickets" in existing:

        cols = inspector.get_columns("repair_tickets")

        print("\nrepair_tickets columns:\n")

        for c in cols:

            print(c["name"])

    print("=" * 50)