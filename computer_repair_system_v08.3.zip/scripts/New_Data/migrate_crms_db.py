from app import app
from database.base import db

# 匯入所有 Model，確保 SQLAlchemy 註冊
from models.role import Role
from models.user import User
from models.customer import Customer
from models.device import Device
from models.repair_ticket import RepairTicket
from models.repair_history import RepairHistory


def migrate():
    with app.app_context():

        print("=" * 50)
        print("CRMS Database Migration")
        print("=" * 50)

        db.create_all()

        print("All tables checked / created successfully.")

        print("=" * 50)


if __name__ == "__main__":
    migrate()