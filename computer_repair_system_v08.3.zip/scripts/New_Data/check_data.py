from app import app

from models.customer import Customer
from models.device import Device
from models.repair_ticket import RepairTicket


with app.app_context():


    print("===================")
    print("CUSTOMER")
    print("===================")

    for c in Customer.query.all():

        print(
            c.id,
            c.name
        )


    print("===================")
    print("DEVICE")
    print("===================")

    for d in Device.query.all():

        print(
            d.id,
            d.brand,
            d.model,
            d.serial_number
        )


    print("===================")
    print("TICKET")
    print("===================")

    for t in RepairTicket.query.all():

        print(
            t.id,
            t.ticket_no,
            t.device_id
        )