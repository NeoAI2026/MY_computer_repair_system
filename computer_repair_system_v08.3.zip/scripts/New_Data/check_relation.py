"""
CRMS SQLAlchemy Relationship Check

DEV-FIX-01.2
確認 Models Relationship 是否正常
"""


from app import app

from database.base import db

from models.user import User
from models.customer import Customer
from models.device import Device
from models.repair_ticket import RepairTicket
from models.repair_history import RepairHistory



def check():


    print("\n===== CRMS RELATION CHECK =====\n")


    with app.app_context():


        print("User")

        try:
            print(
                "  role:",
                User.role.property
            )

            print(
                "  assigned_tickets:",
                User.assigned_tickets.property
            )

            print(
                "  repair_histories:",
                User.repair_histories.property
            )

        except Exception as e:

            print(
                "  ERROR:",
                e
            )



        print("\nCustomer")

        try:

            print(
                "  devices:",
                Customer.devices.property
            )

            print(
                "  tickets:",
                Customer.tickets.property
            )

        except Exception as e:

            print(
                "  ERROR:",
                e
            )



        print("\nDevice")

        try:

            print(
                "  customer:",
                Device.customer.property
            )


            print(
                "  tickets:",
                Device.tickets.property
            )


        except Exception as e:

            print(
                "  ERROR:",
                e
            )



        print("\nRepairTicket")

        try:

            print(
                "  customer:",
                RepairTicket.customer.property
            )


            print(
                "  device:",
                RepairTicket.device.property
            )


            print(
                "  histories:",
                RepairTicket.histories.property
            )


        except Exception as e:

            print(
                "  ERROR:",
                e
            )



        print("\nRepairHistory")

        try:

            print(
                "  ticket:",
                RepairHistory.ticket.property
            )


            print(
                "  user:",
                RepairHistory.user.property
            )


        except Exception as e:

            print(
                "  ERROR:",
                e
            )



    print(
        "\n===== CHECK FINISHED =====\n"
    )



if __name__ == "__main__":

    check()