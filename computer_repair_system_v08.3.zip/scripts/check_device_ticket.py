from app import app

from models.device import Device



with app.app_context():


    device = Device.query.first()


    print("================")


    if device is None:

        print("沒有設備")

    else:

        print(
            "Device:",
            device.id,
            device.brand,
            device.model
        )


        print(
            "Ticket Count:",
            len(device.tickets)
        )


        for t in device.tickets:

            print(

                t.id,

                t.ticket_no,

                t.title,

                t.status

            )