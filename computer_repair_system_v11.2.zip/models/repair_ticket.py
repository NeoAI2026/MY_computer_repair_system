from datetime import datetime

from database.base import db



class RepairTicket(db.Model):

    __tablename__ = "repair_tickets"

    STATUS_MAP = {

        "new": "新案件",

        "wait_assign": "等待派工",

        "assigned": "已派工",

        "checking": "檢測中",

        "quotation": "報價中",

        "repairing": "維修中",

        "testing": "測試中",

        "completed": "已完成",

        "customer_check": "客戶確認",

        "closed": "已結案"

    }


    def status_text(self):

        return self.STATUS_MAP.get(
            self.status,
            self.status
        )


    id = db.Column(

        db.Integer,

        primary_key=True

    )



    # ==========================
    # 案件編號
    # ==========================

    ticket_no = db.Column(

        db.String(50),

        unique=True,

        nullable=False,

        index=True

    )

    

    # ==========================
    # 客戶
    # ==========================

    customer_id = db.Column(

        db.Integer,

        db.ForeignKey(
            "customers.id"
        ),

        nullable=False

    )



    # ==========================
    # 設備
    # ==========================

    device_id = db.Column(

        db.Integer,

        db.ForeignKey(
            "devices.id"
        ),

        nullable=False

    )



    # ==========================
    # 維修工程師
    # ==========================

    assigned_engineer_id = db.Column(

        db.Integer,

        db.ForeignKey(
            "users.id"
        ),

        nullable=True

    )

    assigned_vendor_id = db.Column(
        db.Integer,
        db.ForeignKey(
            "users.id"
        ),
        nullable=True
    )

    creator_id = db.Column(

        db.Integer,

        db.ForeignKey(
            "users.id"
        ),

        nullable=True

    )



    # ==========================
    # 案件資訊
    # ==========================


    title = db.Column(

        db.String(200),

        nullable=False

    )



    problem = db.Column(

        db.Text

    )



    solution = db.Column(

        db.Text

    )



    status = db.Column(

        db.String(50),

        default="new"

    )



    priority = db.Column(

        db.String(50),

        default="normal"

    )



    # ==========================
    # 時間
    # ==========================


    created_at = db.Column(

        db.DateTime,

        default=datetime.utcnow

    )



    updated_at = db.Column(

        db.DateTime,

        default=datetime.utcnow,

        onupdate=datetime.utcnow

    )



    # =================================================
    # Relationship
    # =================================================



    # Ticket -> Customer

    customer = db.relationship(

        "Customer",

        back_populates="tickets"

    )



    # Ticket -> Device

    device = db.relationship(

        "Device",

        back_populates="tickets"

    )

    

    creator = db.relationship(

        "User",

        foreign_keys=[creator_id],

        back_populates="created_tickets"

    )


    # Ticket -> Engineer(User)

    assigned_engineer = db.relationship(

        "User",

        foreign_keys=[assigned_engineer_id],

        back_populates="assigned_tickets"

    )



    # Ticket -> History

    histories = db.relationship(

        "RepairHistory",

        back_populates="ticket",

        cascade="all, delete-orphan",

        order_by="RepairHistory.created_at"

    )

    # ==========================
    # Ticket 使用零件
    # ==========================

    ticket_parts = db.relationship(
        "TicketPart",
        back_populates="ticket",
        cascade="all, delete-orphan"
    )

    quotation = db.relationship(
        "Quotation",
        back_populates="ticket",
        uselist=False
    )

    assigned_vendor = db.relationship(
        "User",
        foreign_keys=[
            assigned_vendor_id
        ]
    )


    def __repr__(self):

        return (

            f"<RepairTicket {self.ticket_no}>"

        )