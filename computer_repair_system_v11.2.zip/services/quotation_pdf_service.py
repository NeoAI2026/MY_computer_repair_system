from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib import colors

import os


class QuotationPDFService:

    @staticmethod
    def get_font():

        font_candidates = [
            r"C:\Windows\Fonts\msjh.ttc",
            r"C:\Windows\Fonts\msjh.ttf",
            r"C:\Windows\Fonts\mingliu.ttc",
            r"C:\Windows\Fonts\mingliu.ttf",
        ]

        for font_path in font_candidates:

            if os.path.exists(font_path):

                try:

                    pdfmetrics.registerFont(
                        TTFont(
                            "CRMSChinese",
                            font_path
                        )
                    )

                    return "CRMSChinese"

                except Exception:
                    continue

        raise FileNotFoundError(
            "找不到 Windows 中文字型，請確認 C:\\Windows\\Fonts"
        )


    @staticmethod
    def generate(quotation):

        font_name = QuotationPDFService.get_font()

        output_dir = os.path.join(
            "static",
            "pdf",
            "quotations"
        )

        os.makedirs(
            output_dir,
            exist_ok=True
        )

        filename = (
            f"{quotation.quotation_no}.pdf"
        )

        filepath = os.path.join(
            output_dir,
            filename
        )

        c = canvas.Canvas(
            filepath,
            pagesize=A4
        )

        width, height = A4

        # =========================
        # 標題
        # =========================

        c.setFont(
            font_name,
            20
        )

        c.drawCentredString(
            width / 2,
            height - 25 * mm,
            "電腦維修報價單"
        )

        # =========================
        # 報價單資訊
        # =========================

        y = height - 45 * mm

        c.setFont(
            font_name,
            11
        )

        customer_name = "-"

        if quotation.customer:

            customer_name = (
                quotation.customer.name
                or "-"
            )

        ticket_no = "-"

        if quotation.ticket:

            ticket_no = (
                quotation.ticket.ticket_no
                or "-"
            )

        rows = [

            (
                "報價單號",
                quotation.quotation_no
            ),

            (
                "案件編號",
                ticket_no
            ),

            (
                "客戶",
                customer_name
            ),

            (
                "建立日期",
                str(
                    quotation.created_at
                    or ""
                )[:19]
            ),

        ]

        for label, value in rows:

            c.drawString(
                25 * mm,
                y,
                f"{label}：{value}"
            )

            y -= 8 * mm


        # =========================
        # 金額區
        # =========================

        y -= 8 * mm

        c.setStrokeColor(
            colors.grey
        )

        c.line(
            20 * mm,
            y,
            width - 20 * mm,
            y
        )

        y -= 12 * mm

        c.setFont(
            font_name,
            12
        )

        labor_fee = float(
            quotation.labor_fee or 0
        )

        parts_total = float(
            quotation.parts_total or 0
        )

        other_fee = float(
            quotation.other_fee or 0
        )

        total_price = float(
            quotation.total_price or 0
        )

        amounts = [

            (
                "工資",
                labor_fee
            ),

            (
                "零件費",
                parts_total
            ),

            (
                "其他費用",
                other_fee
            ),

        ]

        for label, amount in amounts:

            c.drawString(
                30 * mm,
                y,
                label
            )

            c.drawRightString(
                width - 30 * mm,
                y,
                f"NT$ {amount:,.0f}"
            )

            y -= 10 * mm


        # =========================
        # 總金額
        # =========================

        y -= 5 * mm

        c.setFont(
            font_name,
            16
        )

        c.drawString(
            30 * mm,
            y,
            "報價總金額"
        )

        c.drawRightString(
            width - 30 * mm,
            y,
            f"NT$ {total_price:,.0f}"
        )


        # =========================
        # 頁尾
        # =========================

        c.setFont(
            font_name,
            9
        )

        c.drawCentredString(
            width / 2,
            15 * mm,
            "CRMS 電腦維修管理系統"
        )

        c.save()

        return filepath