from flask import (
    Blueprint,
    render_template,
    request,
    redirect,
    url_for,
    flash,
    session,
    send_file
)


from flask_jwt_extended import (
    create_access_token,
    set_access_cookies,
    unset_jwt_cookies,
    jwt_required,
    get_jwt,
    get_jwt_identity
)

from datetime import datetime

from services.ticket_service import TicketService
from services.user_service import UserService
from services.customer_service import CustomerService
from services.device_service import DeviceService
from services.dashboard_service import DashboardService
from services.history_service import HistoryService

from services.vendor_service import VendorService
from services.part_service import PartService
from services.ticket_part_service import TicketPartService
#from services.report_service import ReportService
from services.quotation_service import QuotationService
from services.quotation_pdf_service import QuotationPDFService

from routes.auth_routes import AuthService

from models.repair_ticket import RepairTicket
from models.repair_history import RepairHistory
from models.customer import Customer
from models.user import User
from models.role import Role
from models.device import Device
from models.part import Part
from models.quotation import Quotation

from database.base import db

from flask import g

web_bp = Blueprint(
    "web",
    __name__
)

@web_bp.app_context_processor
def inject_user():

    try:

        claims = get_jwt()

        return {

            "username":
                claims.get("username"),

            "role":
                claims.get("role")

        }

    except:

        return {

            "username":None,

            "role":None

        }

# =================================
# Home
# =================================

@web_bp.route("/")
def home():

    return redirect(
        url_for(
            "web.login"
        )
    )



# =================================
# Login
# =================================

@web_bp.route(
    "/login",
    methods=[
        "GET",
        "POST"
    ]
)
def login():


    if request.method == "POST":


        username = request.form.get(
            "username"
        )


        password = request.form.get(
            "password"
        )


        user = AuthService.login(
            username,
            password
        )


        if user is None:


            flash(
                "帳號或密碼錯誤",
                "danger"
            )


            return redirect(
                url_for(
                    "web.login"
                )
            )


        # JWT identity 必須 string

        access_token = create_access_token(

            identity=str(user.id),

            additional_claims={

                "username":
                    user.username,

                "role":
                    user.role.name

            }

        )


        response = redirect(

            url_for(
                "web.dashboard"
            )

        )


        set_access_cookies(

            response,

            access_token

        )


        return response



    return render_template(
        "login.html"
    )



# =================================
# Dashboard Router
# =================================

@web_bp.route("/dashboard")
@jwt_required()
def dashboard():

    claims = get_jwt()

    role = claims.get("role")


    if role == "admin":

        data = DashboardService.get_admin_dashboard()

        return render_template(
            "dashboard/admin.html",
            **data
        )


    elif role == "engineer":

        return redirect(
            url_for(
                "web.dashboard_engineer"
            )
        )


    elif role == "manager":

        return redirect(
            url_for(
                "web.dashboard_manager"
            )
        )


    elif role == "vendor":
        
        return redirect(
            url_for(
                "web.dashboard_vendor"
            )
        )


    return redirect(
        url_for("web.login")
    )


# =================================
# Engineer Dashboard
# =================================

@web_bp.route("/dashboard/engineer")
@jwt_required()
def dashboard_engineer():

    user_id=int(
        get_jwt_identity()
    )


    data = DashboardService.get_engineer_dashboard(
        user_id
    )


    return render_template(
        "dashboard/engineer.html",
        **data
    )




# =================================
# Manager Dashboard
# =================================


@web_bp.route(
    "/dashboard/manager"
)
@jwt_required()
def dashboard_manager():


    data = (
        DashboardService
        .get_manager_dashboard()
    )


    return render_template(

        "dashboard/manager.html",

        **data

    )

# =================================
# Vendor CRUD
# =================================


@web_bp.route("/vendors")
@jwt_required()
def vendors():

    vendors = (
        VendorService
        .get_all()
    )


    return render_template(
        "vendors/list.html",
        vendors=vendors
    )



@web_bp.route(
    "/vendors/create",
    methods=[
        "GET",
        "POST"
    ]
)
@jwt_required()
def vendor_create():


    if request.method=="POST":


        VendorService.create(
            request.form
        )


        flash(
            "廠商新增成功",
            "success"
        )


        return redirect(
            url_for(
                "web.vendors"
            )
        )


    return render_template(
        "vendors/create.html"
    )




@web_bp.route(
    "/vendors/<int:id>/edit",
    methods=[
        "GET",
        "POST"
    ]
)
@jwt_required()
def vendor_edit(id):


    vendor = (
        VendorService
        .get(id)
    )


    if request.method=="POST":


        VendorService.update(
            id,
            request.form
        )


        flash(
            "更新成功",
            "success"
        )


        return redirect(
            url_for(
                "web.vendors"
            )
        )


    return render_template(

        "vendors/edit.html",

        vendor=vendor

    )




@web_bp.route(
    "/vendors/<int:id>/disable"
)
@jwt_required()
def vendor_disable(id):


    VendorService.disable(id)


    flash(
        "廠商已停用",
        "warning"
    )


    return redirect(
        url_for(
            "web.vendors"
        )
    )

# =========================
# 啟用廠商
# =========================

@web_bp.route(
    "/vendors/<int:id>/enable"
)
@jwt_required()
def vendor_enable(id):


    VendorService.enable(id)


    flash(
        "廠商已啟用",
        "success"
    )


    return redirect(
        url_for(
            "web.vendors"
        )
    )




@web_bp.route(
    "/vendors/<int:id>/delete"
)
@jwt_required()
def vendor_delete(id):


    VendorService.delete(id)


    flash(
        "廠商已刪除",
        "danger"
    )


    return redirect(
        url_for(
            "web.vendors"
        )
    )


# =================================
# Vendor Dashboard
# =================================

@web_bp.route(
    "/dashboard/vendor"
)
@jwt_required()
def dashboard_vendor():


    vendor_id = int(
        get_jwt_identity()
    )


    print(
        "LOGIN VENDOR ID=",
        vendor_id
    )


    data = DashboardService.get_vendor_dashboard(
        vendor_id
    )


    print(
        "VENDOR TICKETS=",
        data["tickets"]
    )


    return render_template(

        "dashboard/vendor.html",

        **data

    )

# =================================
# Vendor Ticket Detail
# =================================


@web_bp.route(
    "/vendor/ticket/<int:ticket_id>"
)
@jwt_required()
def vendor_ticket_detail(ticket_id):


    vendor_id = int(
        get_jwt_identity()
    )


    ticket = (
        RepairTicket.query
        .filter_by(
            id=ticket_id,
            assigned_vendor_id=vendor_id
        )
        .first()
    )


    if not ticket:

        flash(
            "無權限查看此案件",
            "danger"
        )

        return redirect(
            url_for(
                "web.dashboard_vendor"
            )
        )


    return render_template(

        "vendors/ticket_detail.html",

        ticket=ticket

    )

# =================================
# Vendor Management
# =================================

@web_bp.route("/vendors")
@jwt_required()
def vendor_management():


    vendors = (
        VendorService
        .get_all()
    )


    return render_template(

        "vendors/list.html",

        vendors=vendors

    )


@web_bp.route(
    "/vendor/ticket/<int:ticket_id>/status",
    methods=["POST"]
)
@jwt_required()
def vendor_update_status(ticket_id):


    vendor_id = int(
        get_jwt_identity()
    )


    ticket = (
        RepairTicket.query
        .filter_by(
            id=ticket_id,
            assigned_vendor_id=vendor_id
        )
        .first()
    )


    if not ticket:

        flash(
            "案件不存在",
            "danger"
        )

        return redirect(
            url_for(
                "web.dashboard_vendor"
            )
        )


    old_status = ticket.status


    new_status = request.form.get(
        "status"
    )

    description = request.form.get("description")

    ticket.status = new_status


    from services.history_service import HistoryService


    HistoryService.add(
        ticket_id=ticket.id,
        old_status=old_status,
        new_status=new_status,
        user_id=vendor_id,
        action="VENDOR_STATUS_UPDATE",
        description=description
    )

    db.session.commit()


    flash(
        "案件狀態更新成功",
        "success"
    )


    return redirect(
        url_for(
            "web.vendor_ticket_detail",
            ticket_id=ticket.id
        )
    )


# =================================
# Ticket List
# =================================


@web_bp.route(
    "/tickets"
)
@jwt_required()
def ticket_list():


    claims=get_jwt()

    role=claims.get("role")

    user_id=int(
        get_jwt_identity()
    )


    if role=="admin":

        tickets=TicketService.get_all()


    elif role=="manager":

        tickets=TicketService.get_all()


    elif role=="engineer":

        tickets=(
            RepairTicket.query
            .filter_by(
                assigned_engineer_id=user_id
            )
            .all()
        )


    elif role=="vendor":

        tickets = TicketService.get_vendor_tickets(
            user_id
        )


    else:

        tickets=[]



    return render_template(

        "tickets/list.html",

        tickets=tickets

    )



# =================================
# Create Ticket
# =================================


@web_bp.route(
    "/tickets/create",
    methods=[
        "GET",
        "POST"
    ]
)
@jwt_required()
def create_ticket_page():

    if request.method == "POST":

        user_id = get_jwt_identity()


        data = {

            "customer_id":
                request.form.get(
                    "customer_id"
                ),


            "device_id":
                request.form.get(
                    "device_id"
                ),


            "title":
                request.form.get(
                    "title"
                ),


            "problem":
                request.form.get(
                    "problem"
                ),


            "priority":
                request.form.get(
                    "priority",
                    "normal"
                )

        }


        TicketService.create_ticket(
            data,
            user_id
        )


        return redirect(
            url_for(
                "web.ticket_list"
            )
        )


    customers = Customer.query.all()

    devices = Device.query.all()


    return render_template(
        "tickets/create.html",
        customers=customers,
        devices=devices
    )



# =================================
# Ticket Detail
# =================================


@web_bp.route(
    "/tickets/<int:ticket_id>"
)
@jwt_required()
def ticket_detail(ticket_id):


    ticket = TicketService.get_ticket(ticket_id)


    if ticket is None:

        flash(
            "案件不存在",
            "danger"
        )

        return redirect(
            url_for("web.ticket_list")
        )


    user_id = int(
        get_jwt_identity()
    )


    user = User.query.get(
        user_id
    )

    parts = Part.query.all()

    histories = (
        RepairHistory.query
        .filter_by(
            ticket_id=ticket_id
        )
        .order_by(
            RepairHistory.created_at.desc()
        )
        .all()
    )

    return render_template(

        "tickets/detail.html",

        user=user,

        ticket=ticket,

        parts=parts,

        histories=histories

    )



# =================================
# Ticket Edit
# =================================


@web_bp.route(
    "/tickets/<int:ticket_id>/edit",
    methods=[
        "GET",
        "POST"
    ]
)
@jwt_required()
def edit_ticket(ticket_id):


    ticket = (
        TicketService
        .get_ticket(
            ticket_id
        )
    )


    if request.method == "POST":

        print(request.form)
        data = (
            request.form
            .to_dict()
        )
        print(data)
    
        TicketService.update_ticket(

            ticket.id,

            data

        )


        if data.get(
            "assigned_engineer_id"
        ):


            TicketService.assign_engineer(

                ticket_id,

                data["assigned_engineer_id"]

            )

        if data.get("assigned_vendor_id"):

            TicketService.assign_vendor(
                ticket_id,
                data["assigned_vendor_id"]
            )


        return redirect(

            url_for(

                "web.ticket_detail",

                ticket_id=ticket_id

            )

        )



    engineers = (
        UserService
        .get_engineers()
    )

    """
    vendors = (
        User.query
        .join(Role)
        .filter(
            Role.name=="VENDOR"
        )
        .all()
    )
    """
    vendors = VendorService.get_all()

    return render_template(
        "tickets/edit.html",
        ticket=ticket,
        engineers=engineers,
        vendors=vendors
    )


@web_bp.route(
    "/tickets/<int:ticket_id>/parts/add",
    methods=["POST"]
)
@jwt_required()
def ticket_part_add(ticket_id):


    part_id = request.form.get(
        "part_id"
    )


    qty = request.form.get(
        "quantity"
    )


    TicketPartService.add(

        ticket_id,

        int(part_id),

        int(qty)

    )


    return redirect(
        f"/tickets/{ticket_id}"
    )


# =================================
# History
# =================================


@web_bp.route(
    "/tickets/<int:ticket_id>/history"
)
@jwt_required()
def ticket_history(ticket_id):


    ticket = (
        RepairTicket
        .query
        .get_or_404(
            ticket_id
        )
    )


    histories = (
        RepairHistory
        .query
        .filter_by(
            ticket_id=ticket_id
        )
        .order_by(
            RepairHistory.created_at.asc()
        )
        .all()
    )


    return render_template(

        "tickets/history.html",

        ticket=ticket,

        histories=histories

    )


# =================================
# Engineer Update Ticket Status
# =================================

@web_bp.route(
    "/tickets/<int:ticket_id>/engineer/status",
    methods=["POST"]
)
@jwt_required()
def engineer_update_status(ticket_id):

    ticket = TicketService.get_ticket(
        ticket_id
    )

    if ticket is None:

        flash(
            "案件不存在",
            "danger"
        )

        return redirect(
            url_for(
                "web.ticket_list"
            )
        )


    user_id = int(
        get_jwt_identity()
    )


    claims = get_jwt()

    role = claims.get("role")


    # 只允許工程師操作

    if role != "engineer":

        flash(
            "沒有權限執行此操作",
            "danger"
        )

        return redirect(
            url_for(
                "web.ticket_detail",
                ticket_id=ticket_id
            )
        )


    # 確認案件是否指派給自己

    if ticket.assigned_engineer_id != user_id:

        flash(
            "此案件尚未指派給您",
            "danger"
        )

        return redirect(
            url_for(
                "web.ticket_detail",
                ticket_id=ticket_id
            )
        )


    old_status = ticket.status

    new_status = request.form.get(
        "status"
    )

    note = request.form.get(
        "note",
        ""
    )


    if not new_status:

        flash(
            "請選擇新的案件狀態",
            "warning"
        )

        return redirect(
            url_for(
                "web.ticket_detail",
                ticket_id=ticket_id
            )
        )


    # 更新案件狀態

    ticket.status = new_status


    db.session.commit()


    # 寫入維修歷程

    HistoryService.add(

        ticket_id=ticket_id,

        user_id=user_id,

        action="STATUS_UPDATE",

        description=(
            f"{old_status} → {new_status}"
        ),

        old_status=old_status,

        new_status=new_status,

        note=note

    )


    flash(
        "案件狀態更新成功",
        "success"
    )


    return redirect(
        url_for(
            "web.ticket_detail",
            ticket_id=ticket_id
        )
    )




# =================================
# Logout
# =================================


@web_bp.route(
    "/logout"
)
def logout():


    response = redirect(

        url_for(
            "web.login"
        )

    )


    unset_jwt_cookies(
        response
    )


    flash(
        "已登出",
        "success"
    )


    return response

@web_bp.route("/customers")
@jwt_required()
def customer_list():

    customers = CustomerService.get_all()

    return render_template(
        "customers/list.html",
        customers=customers
    )

@web_bp.route("/devices")
@jwt_required()
def device_list():

    devices = DeviceService.get_all()

    return render_template(
        "devices/devices_list.html",
        devices=devices
    )

@web_bp.route(
    "/devices/<int:id>"
)
@jwt_required()
def device_detail(id):


    device = (
        DeviceService
        .get_detail(id)
    )


    if not device:

        return "Device Not Found",404



    return render_template(

        "devices/devices_detail.html",

        device=device

    )

"""
@web_bp.route(
    "/devices/<int:id>/edit",
    methods=[
        "GET",
        "POST"
    ]
)
@jwt_required()
def device_edit(id):


    device = DeviceService.get(id)


    if not device:
        flash(
            "設備不存在",
            "danger"
        )

        return redirect(
            url_for(
                "web.device_list"
            )
        )

    
    if request.method=="POST":


        DeviceService.update(
            id,
            request.form
        )


        flash(
            "設備更新成功",
            "success"
        )


        return redirect(
            url_for(
                "web.device_list"
            )
        )
    
    if request.method == "POST":

        device = DeviceService.get(id)


        if not device:
            flash(
                "設備不存在",
                "danger"
            )

            return redirect(
                url_for(
                    "web.device_list"
                )
            )


        DeviceService.update(
            device,
            request.form
        )


        flash(
            "設備更新成功",
            "success"
        )


        return redirect(
            url_for(
                "web.device_list"
            )
        )


    return render_template(

        "devices/devices_edit.html",

        device=device

    )
"""
@web_bp.route(
    "/devices/<int:id>/edit",
    methods=["GET","POST"]
)
@jwt_required()
def device_edit(id):

    device = DeviceService.get(id)

    if not device:
        flash(
            "找不到設備",
            "danger"
        )

        return redirect(
            url_for(
                "web.device_list"
            )
        )


    if request.method=="POST":

        DeviceService.update(
            device,
            request.form
        )

        flash(
            "設備更新成功",
            "success"
        )

        return redirect(
            url_for(
                "web.device_list"
            )
        )


    return render_template(
        "devices/devices_edit.html",
        device=device
    )
    
@web_bp.route("/engineers")
@jwt_required()
def engineer_list():

    engineers = UserService.get_engineers()

    return render_template(
        "engineers/list.html",
        engineers=engineers
    )


@web_bp.route("/vendors")
@jwt_required()
def vendor_list():

    vendors = VendorService.get_all()

    return render_template(
        "vendors/list.html",
        vendors=vendors
    )



# =================================
# Quotation
# =================================
@web_bp.route("/quotations")
@jwt_required()
def quotation_list():

    quotations = QuotationService.get_all()

    return render_template(
        "quotations/list.html",
        quotations=quotations
    )

def generate_quotation_no():

    return "QT" + datetime.now().strftime("%Y%m%d%H%M%S")

@web_bp.route(
    "/quotations/create/<int:ticket_id>",
    methods=["GET","POST"]
)
@jwt_required()
def quotation_create(ticket_id):


    ticket = RepairTicket.query.get_or_404(ticket_id)

    # ============================
    # 防止重複建立報價單
    # ============================

    existing = Quotation.query.filter_by(
        ticket_id=ticket_id
    ).first()


    if existing:

        flash(
            "此維修案件已有報價單",
            "warning"
        )


        return redirect(
            url_for(
                "web.quotation_detail",
                id=existing.id
            )
        )

    if request.method == "POST":

        user_id = int(
            get_jwt_identity()
        )


        # ==========================
        # 自動計算零件費
        # ==========================

        parts_total = 0


        for tp in ticket.ticket_parts:

            if tp.part:

                parts_total += (
                    tp.quantity *
                    tp.part.price
                )


        labor_fee = float(
            request.form.get(
                "labor_fee",
                0
            )
        )


        other_fee = float(
            request.form.get(
                "other_fee",
                0
            )
        )


        total_price = (
            labor_fee
            +
            parts_total
            +
            other_fee
        )



        quotation = Quotation(

            quotation_no=
                generate_quotation_no(),


            ticket_id=
                ticket.id,


            customer_id=
                ticket.customer_id,


            labor_fee=
                labor_fee,


            parts_total=
                parts_total,


            other_fee=
                other_fee,


            total_price=
                total_price,


            status=
                "draft",


            created_by=
                user_id

        )


        db.session.add(quotation)

        db.session.commit()


        return redirect(
            url_for(
                "web.quotation_detail",
                id=quotation.id
            )
        )



    return render_template(

        "quotations/create.html",

        ticket=ticket

    )

@web_bp.route(
    "/quotations/<int:id>"
)
@jwt_required()
def quotation_detail(id):

    quotation = Quotation.query.get_or_404(id)


    return render_template(
        "quotations/detail.html",
        quotation=quotation
    )

from flask import send_file



@web_bp.route(
    "/quotations/<int:id>/pdf"
)
@jwt_required()
def quotation_pdf(id):

    quotation = Quotation.query.get_or_404(id)

    filepath = QuotationPDFService.generate(
        quotation
    )

    return redirect(
        "/" + filepath.replace("\\", "/")
    )


@web_bp.route(
    "/quotations/<int:id>/edit",
    methods=["GET","POST"]
)
@jwt_required()
def quotation_edit(id):


    quotation = Quotation.query.get_or_404(id)


    if request.method=="POST":


        quotation.labor_fee=float(
            request.form.get(
                "labor_fee",
                0
            )
        )


        quotation.parts_total=float(
            request.form.get(
                "parts_total",
                0
            )
        )


        quotation.other_fee=float(
            request.form.get(
                "other_fee",
                0
            )
        )


        quotation.total_price=(

            quotation.labor_fee
            +
            quotation.parts_total
            +
            quotation.other_fee

        )


        db.session.commit()


        return redirect(
            url_for(
                "web.quotation_detail",
                id=id
            )
        )


    return render_template(
        "quotations/edit.html",
        quotation=quotation
    )



@web_bp.route("/reports")
@jwt_required()
def report_dashboard():

    data = ReportService.dashboard()

    return render_template(
        "reports/dashboard.html",
        **data
    )

@web_bp.route("/settings")
@jwt_required()
def system_setting():

    return render_template(
        "settings/index.html"
    )


# =================================
# Vendor
# =================================
@web_bp.route("/parts")
@jwt_required()
def part_list():

    parts = PartService.get_all()

    return render_template(
        "parts/list.html",
        parts=parts
    )


@web_bp.route(
    "/parts/create",
    methods=["GET","POST"]
)
@jwt_required()
def part_create():

    if request.method=="POST":

        PartService.create(
            request.form
        )

        flash(
            "新增成功",
            "success"
        )

        return redirect(
            url_for(
                "web.part_list"
            )
        )

    return render_template(
        "parts/create.html"
    )

@web_bp.route(
    "/parts/<int:id>/edit",
    methods=["GET","POST"]
)
@jwt_required()
def part_edit(id):

    part = PartService.get(id)

    if not part:
        flash("找不到零件", "danger")
        return redirect(url_for("web.part_list"))

    if request.method=="POST":

        PartService.update(
            id,
            request.form
        )

        flash(
            "修改成功",
            "success"
        )

        return redirect(
            url_for("web.part_list")
        )

    return render_template(
        "parts/edit.html",
        part=part
    )
