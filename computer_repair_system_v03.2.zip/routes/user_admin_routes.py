from flask import Blueprint, render_template, request, redirect, session
from models.user import User
from database.base import db

user_admin_bp = Blueprint("user_admin", __name__)


# =========================
# 👤 使用者列表
# =========================
@user_admin_bp.route("/")
def user_list():

    if session.get("role") != "admin":
        return "403 Forbidden", 403

    users = User.query.all()

    return render_template(
        "user_list.html",
        users=users
    )


# =========================
# ➕ 新增使用者
# =========================
@user_admin_bp.route("/add", methods=["GET", "POST"])
def add_user():

    if session.get("role") != "admin":
        return "403 Forbidden", 403

    if request.method == "GET":
        return render_template("user_add.html")

    username = request.form["username"]
    password = request.form["password"]
    role = request.form["role"]

    if User.query.filter_by(username=username).first():
        return render_template("user_add.html", error="帳號已存在")

    user = User(
        username=username,
        role=role
    )
    user.set_password(password)

    db.session.add(user)
    db.session.commit()

    return redirect("/users")


# =========================
# ✏️ 編輯使用者
# =========================
@user_admin_bp.route("/edit/<int:user_id>", methods=["GET", "POST"])
def edit_user(user_id):

    if session.get("role") != "admin":
        return "403 Forbidden", 403

    user = User.query.get_or_404(user_id)

    if request.method == "GET":
        return render_template("user_edit.html", user=user)

    user.username = request.form["username"]
    user.role = request.form["role"]
    user.is_active = "is_active" in request.form

    db.session.commit()

    return redirect("/users")


# =========================
# ❌ 停用帳號（不是刪除）
# =========================
@user_admin_bp.route("/delete/<int:user_id>")
def delete_user(user_id):

    if session.get("role") != "admin":
        return "403 Forbidden", 403

    user = User.query.get_or_404(user_id)

    user.is_active = False

    db.session.commit()

    return redirect("/users")


# =========================
# 🔑 重設密碼
# =========================
@user_admin_bp.route("/reset_password/<int:user_id>", methods=["POST"])
def reset_password(user_id):

    if session.get("role") != "admin":
        return "403 Forbidden", 403

    user = User.query.get_or_404(user_id)

    new_password = request.form["new_password"]

    user.set_password(new_password)

    db.session.commit()

    return redirect("/users")