from datetime import datetime

from database.base import db



class RepairTicket(db.Model):

    __tablename__ = "repair_tickets"



    id = db.Column(

        db.Integer,

        primary_key=True

    )



    # ==========================
    # 案件編號
    # ==========================

    ticket_no = db.Column(

        db.String(50),

        unique=True,

        nullable=False,

        index=True

    )



    # ==========================
    # 客戶
    # ==========================

    customer_id = db.Column(

        db.Integer,

        db.ForeignKey(
            "customers.id"
        ),

        nullable=False

    )



    # ==========================
    # 設備
    # ==========================

    device_id = db.Column(

        db.Integer,

        db.ForeignKey(
            "devices.id"
        ),

        nullable=True

    )



    # ==========================
    # 維修工程師
    # ==========================

    assigned_engineer_id = db.Column(

        db.Integer,

        db.ForeignKey(
            "users.id"
        ),

        nullable=True

    )

    engineer_id = db.Column(

        db.Integer,

        db.ForeignKey(
            "users.id"
        ),

        nullable=True

    )

    creator_id = db.Column(

        db.Integer,

        db.ForeignKey(
            "users.id"
        ),

        nullable=True

    )



    # ==========================
    # 案件資訊
    # ==========================


    title = db.Column(

        db.String(200),

        nullable=False

    )



    problem = db.Column(

        db.Text

    )



    solution = db.Column(

        db.Text

    )



    status = db.Column(

        db.String(50),

        default="new"

    )



    priority = db.Column(

        db.String(50),

        default="normal"

    )



    # ==========================
    # 時間
    # ==========================


    created_at = db.Column(

        db.DateTime,

        default=datetime.utcnow

    )



    updated_at = db.Column(

        db.DateTime,

        default=datetime.utcnow,

        onupdate=datetime.utcnow

    )



    # =================================================
    # Relationship
    # =================================================



    # Ticket -> Customer

    customer = db.relationship(

        "Customer",

        back_populates="tickets"

    )



    # Ticket -> Device

    device = db.relationship(

        "Device",

        back_populates="tickets"

    )

    # Engineer -> User

    engineer = db.relationship(

        "User",

        foreign_keys=[engineer_id],

        back_populates="assigned_tickets"

    )

    creator = db.relationship(

        "User",

        foreign_keys=[creator_id],

        back_populates="created_tickets"

    )


    # Ticket -> Engineer(User)

    assigned_engineer = db.relationship(

        "User",

        foreign_keys=[assigned_engineer_id],

        back_populates="assigned_tickets"

    )



    # Ticket -> History

    histories = db.relationship(

        "RepairHistory",

        back_populates="ticket",

        cascade="all, delete-orphan",

        order_by="RepairHistory.created_at"

    )

    


    def __repr__(self):

        return (

            f"<RepairTicket {self.ticket_no}>"

        )