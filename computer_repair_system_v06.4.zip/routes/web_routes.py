from flask import (
    Blueprint,
    render_template,
    request,
    redirect,
    url_for,
    session,
    flash
)

from flask_jwt_extended import (
    current_user,
    verify_jwt_in_request,
    get_jwt_identity,
)

from flask import request
from services.ticket_service import TicketService
from flask_jwt_extended import jwt_required
from services.user_service import UserService
from models.repair_ticket import RepairTicket
from models.repair_history import RepairHistory

from services.auth_service import AuthService

web_bp = Blueprint(
    "web",
    __name__,
)


# ==========================
# Home
# ==========================

@web_bp.route("/")
def home():
    return redirect(url_for("web.login"))


# ==========================
# Login Page
# ==========================

@web_bp.route("/login", methods=["GET","POST"])
def login():
    if request.method == "POST":


        username = request.form.get(
            "username"
        )

        password = request.form.get(
            "password"
        )


        user = AuthService.login(
            username,
            password
        )


        if not user:


            flash(
                "帳號或密碼錯誤",
                "danger"
            )


            return redirect(
                url_for(
                    "web.login"
                )
            )


        # =================
        # 建立 Session
        # =================
        if user:
            session["user_id"] = user.id

            session["username"] = user.username

            session["role"] = user.role.name

            return redirect(url_for("web.dashboard"))



        # =================
        # Role Redirect
        # =================


        if user.role.name == "admin":


            return redirect(
                url_for(
                    "web.dashboard_admin"
                )
            )


        elif user.role.name == "engineer":


            return redirect(
                url_for(
                    "web.dashboard_engineer"
                )
            )


        elif user.role.name == "manager":


            return redirect(
                url_for(
                    "web.dashboard_manager"
                )
            )


        elif user.role.name == "vendor":


            return redirect(
                url_for(
                    "web.dashboard_vendor"
                )
            )
        
    return render_template("login.html")


# =========================
# Dashboard
# =========================
from flask import session

@web_bp.route("/dashboard")
def dashboard():

    if "user_id" not in session:
        return redirect(
            url_for("web.login")
        )

    role = session.get(
        "role"
    )


    if role == "admin":
        return render_template(
            "dashboard/admin.html"
        )



    elif role == "engineer":
        return render_template(
            "dashboard/engineer.html"
        )


    elif role == "manager":
        return render_template(
            "dashboard/manager.html"
        )


    elif role == "vendor":
        return render_template(
            "dashboard/vendor.html"
        )


    return redirect(
        url_for(
            "web.login"
        )
    )



@web_bp.route("/dashboard/admin")
def dashboard_admin():


    return render_template(
        "dashboard/admin.html"
    )



@web_bp.route("/dashboard/engineer")
def dashboard_engineer():


    return render_template(
        "dashboard/engineer.html"
    )



@web_bp.route("/dashboard/manager")
def dashboard_manager():


    return render_template(
        "dashboard/manager.html"
    )



@web_bp.route("/dashboard/vendor")
def dashboard_vendor():


    return render_template(
        "dashboard/vendor.html"
    )


# ==========================
# Ticket List
# ==========================

@web_bp.route("/tickets")
def ticket_list():

    try:

        verify_jwt_in_request()

        identity = get_jwt_identity()

        return render_template(
            "tickets/list.html",
            user=identity,
        )

    except Exception:

        return redirect(
            url_for("web.login")
        )


# ==========================
# Create Ticket
# ==========================

@web_bp.route("/tickets/create",)
def ticket_create():

    try:

        verify_jwt_in_request()

        identity = get_jwt_identity()

        return render_template(
            "tickets/create.html",
            user=identity,
        )

    except Exception:

        return redirect(
            url_for("web.login")
        )

@web_bp.route(
    "/tickets/create",
    methods=["GET","POST"]
)
#@jwt_required()
def create_ticket_page():

    if request.method == "POST":

        data = request.form.to_dict()


        ticket = TicketService.create_ticket(
            data
        )


        return redirect(
            "/tickets"
        )


    return render_template(
        "tickets/create.html"
    )

# ==========================
# Ticket Detail
# ==========================

@web_bp.route("/tickets/<int:ticket_id>")
def ticket_detail(ticket_id):

    try:

        verify_jwt_in_request()

        identity = get_jwt_identity()

        return render_template(
            "tickets/detail.html",
            user=identity,
            ticket_id=ticket_id,
        )

    except Exception:

        return redirect(
            url_for("web.login")
        )
    

# ==========================
# Edit Ticket
# ==========================

@web_bp.route("/tickets/<int:ticket_id>/edit")
def ticket_edit(ticket_id):

    try:

        verify_jwt_in_request()

        identity = get_jwt_identity()

        return render_template(
            "tickets/edit.html",
            user=identity,
            ticket_id=ticket_id,
        )

    except Exception:

        return redirect(
            url_for("web.login")
        )
    
@web_bp.route(
    "/tickets/<int:ticket_id>/edit",
    methods=["GET","POST"]
)
#@jwt_required()
def edit_ticket(ticket_id):


    ticket = TicketService.get_ticket(
        ticket_id
    )


    if request.method == "POST":


        data = request.form.to_dict()



        TicketService.update_ticket(
            ticket,
            data
        )



        if data.get("engineer_id"):


            TicketService.assign_engineer(
                ticket_id,
                data["engineer_id"]
            )



        return redirect(
            f"/tickets/{ticket_id}"
        )




    engineers = UserService.get_engineers()



    return render_template(

        "tickets/edit.html",

        ticket=ticket,

        engineers=engineers

    )


# ==========================
# User List
# ==========================

@web_bp.route("/users")
def users():

    try:

        verify_jwt_in_request()

        identity = get_jwt_identity()

        return render_template(
            "users/list.html",
            user=identity,
        )

    except Exception:

        return redirect(
            url_for("web.login")
        )


# ==========================
# Profile
# ==========================

@web_bp.route("/profile")
def profile():

    try:

        verify_jwt_in_request()

        identity = get_jwt_identity()

        return render_template(
            "users/profile.html",
            user=identity,
        )

    except Exception:

        return redirect(
            url_for("web.login")
        )

# ==========================
# Repair History
# ==========================
@web_bp.route(
    "/tickets/<int:ticket_id>/history"
)
def ticket_history(ticket_id):


    ticket = RepairTicket.query.get_or_404(
        ticket_id
    )


    histories = RepairHistory.query.filter_by(

        ticket_id=ticket_id

    ).order_by(

        RepairHistory.created_at.asc()

    ).all()



    return render_template(

        "tickets/history.html",

        ticket=ticket,

        histories=histories

    )


# ==========================
# Logout
# ==========================

@web_bp.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("web.login"))