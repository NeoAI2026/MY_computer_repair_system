from flask import (
    Blueprint,
    render_template,
    request,
    redirect,
    url_for,
    flash
)

from services.ticket_service import TicketService


web_ticket_bp = Blueprint(
    "web_ticket",
    __name__,
    url_prefix="/tickets"
)



# ==================================
# Ticket List Page
# URL:
# /tickets/
# ==================================

@web_ticket_bp.route("/")
def list_ticket_page():

    tickets = TicketService.get_all()


    return render_template(
        "tickets/list.html",
        tickets=tickets
    )

from flask import session

@web_ticket_bp.route("/create")
def create_ticket_page():
    print("SESSION =", dict(session))
    
    return render_template(
        "tickets/create.html"
    )



# ==================================
# Ticket Detail Page
# URL:
# /tickets/<id>
# ==================================

@web_ticket_bp.route(
    "/<int:ticket_id>"
)
def ticket_detail_page(ticket_id):

    ticket = TicketService.get_ticket(
        ticket_id
    )


    if not ticket:

        flash(
            "找不到維修案件",
            "danger"
        )

        return redirect(
            url_for(
                "web_ticket.list_ticket_page"
            )
        )


    return render_template(
        "tickets/detail.html",
        ticket=ticket
    )



# ==================================
# Ticket Edit Page
# URL:
# /tickets/<id>/edit
# ==================================

@web_ticket_bp.route(
    "/<int:ticket_id>/edit",
    methods=[
        "GET",
        "POST"
    ]
)
def ticket_edit_page(ticket_id):


    ticket = TicketService.get_ticket(
        ticket_id
    )


    if not ticket:

        flash(
            "案件不存在",
            "danger"
        )

        return redirect(
            url_for(
                "web_ticket.list_ticket_page"
            )
        )


    if request.method == "POST":


        TicketService.update_ticket(
            ticket,
            request.form
        )


        flash(
            "案件更新成功",
            "success"
        )


        return redirect(
            url_for(
                "web_ticket.ticket_detail_page",
                ticket_id=ticket.id
            )
        )



    return render_template(
        "tickets/edit.html",
        ticket=ticket
    )



# ==================================
# Ticket History
# ==================================

@web_ticket_bp.route(
    "/<int:ticket_id>/history"
)
def ticket_history_page(ticket_id):


    ticket = TicketService.get_ticket(
        ticket_id
    )


    if not ticket:

        return redirect(
            url_for(
                "web_ticket.list_ticket_page"
            )
        )


    return render_template(
        "tickets/history.html",
        ticket=ticket
    )