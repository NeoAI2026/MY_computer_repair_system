from flask import Blueprint, request, session, redirect
from models.repair_ticket import RepairTicket
from database.base import db

ticket_bp = Blueprint("ticket", __name__)


# 建立維修單
@ticket_bp.route("/create", methods=["POST"])
def create():

    if "user_id" not in session:
        return redirect("/auth/login")

    title = request.form["title"]
    desc = request.form["description"]

    ticket = RepairTicket(
        title=title,
        description=desc,
        user_id=session["user_id"]
    )

    db.session.add(ticket)
    db.session.commit()

    return redirect("/dashboard/user")