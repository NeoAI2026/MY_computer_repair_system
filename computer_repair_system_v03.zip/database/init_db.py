"""
from app import app
from database.base import db
from models.user import User

with app.app_context():
    db.create_all()

    if User.query.count() == 0:
        db.session.add(User(
            username="admin",
            password="admin123",
            role="admin"
        ))

        db.session.add(User(
            username="engineer",
            password="engineer123",
            role="engineer"
        ))

        db.session.add(User(
            username="user",
            password="user123",
            role="user"
        ))

        db.session.commit()

    print("初始化完成")
"""