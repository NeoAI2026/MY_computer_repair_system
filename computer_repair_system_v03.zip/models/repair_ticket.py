from database.base import db

class RepairTicket(db.Model):
    __tablename__ = "repair_tickets"

    id = db.Column(db.Integer, primary_key=True)

    title = db.Column(db.String(200))
    description = db.Column(db.Text)

    status = db.Column(db.String(50), default="pending")
    # pending / assigned / processing / done / cancel

    user_id = db.Column(db.Integer, db.ForeignKey("users.id"))
    engineer_id = db.Column(db.Integer, nullable=True)