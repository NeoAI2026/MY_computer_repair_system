from app import create_app
from database.base import db
from models.role import Role


app=create_app()


with app.app_context():

    roles=Role.query.all()


    for role in roles:

        print(
            role.id,
            role.name
        )