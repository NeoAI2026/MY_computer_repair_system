from app import create_app

from models.role import Role

from database.base import db



app = create_app()



roles=[
    "admin",
    "manager",
    "engineer",
    "vendor"
]



with app.app_context():


    for r in roles:


        exists = Role.query.filter_by(
            name=r
        ).first()



        if exists:

            print(
                f"角色已存在: {r}"
            )

            continue



        role = Role(

            name=r

        )


        db.session.add(role)



    db.session.commit()



    print(
        "角色初始化完成"
    )