import sqlite3
import os


BASE_DIR = os.path.dirname(
    os.path.dirname(
        os.path.abspath(__file__)
    )
)


DB_PATH = os.path.join(
    BASE_DIR,
    "instance",
    "crms.db"
)


print("Database:", DB_PATH)


conn = sqlite3.connect(DB_PATH)

cursor = conn.cursor()


# 確認資料表存在
cursor.execute(
    "SELECT name FROM sqlite_master WHERE type='table'"
)

tables = cursor.fetchall()

print("Tables:")
for table in tables:
    print(table[0])


# 檢查欄位是否已存在
cursor.execute(
    "PRAGMA table_info(repair_tickets)"
)

columns = [
    row[1]
    for row in cursor.fetchall()
]


if "assigned_vendor_id" not in columns:

    cursor.execute("""
        ALTER TABLE repair_tickets
        ADD COLUMN assigned_vendor_id INTEGER
    """)

    conn.commit()

    print(
        "✅ assigned_vendor_id added"
    )

else:

    print(
        "ℹ️ assigned_vendor_id already exists"
    )


conn.close()