import sqlite3


DB_PATH = "instance/crms.db"


conn = sqlite3.connect(DB_PATH)

cursor = conn.cursor()


# 查看 users 欄位
cursor.execute("""
PRAGMA table_info(users)
""")


columns = [
    row[1]
    for row in cursor.fetchall()
]


print("目前欄位:")
print(columns)



if "status" not in columns:


    cursor.execute("""
    ALTER TABLE users
    ADD COLUMN status VARCHAR(20)
    DEFAULT 'ACTIVE'
    """)


    print(
        "新增 users.status 成功"
    )


else:

    print(
        "status 已存在"
    )



conn.commit()

conn.close()


print("完成")