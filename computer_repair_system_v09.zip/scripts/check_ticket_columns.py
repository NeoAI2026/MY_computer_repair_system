import sqlite3


conn = sqlite3.connect(
    "instance/crms.db"
)

cursor = conn.cursor()


cursor.execute("""
PRAGMA table_info(repair_tickets)
""")


for row in cursor.fetchall():
    print(row)


conn.close()