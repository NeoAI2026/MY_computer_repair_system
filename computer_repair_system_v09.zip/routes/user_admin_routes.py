from flask import Blueprint, render_template, request, redirect, url_for, flash

from flask_jwt_extended import jwt_required, get_jwt

from models.user import User
from models.role import Role
from database.base import db
from werkzeug.security import generate_password_hash


user_admin_bp = Blueprint(
    "user_admin",
    __name__,
    url_prefix="/admin"
)


def admin_required():

    claims = get_jwt()

    if claims.get("role") != "admin":
        return False

    return True



# ==========================
# User List
# ==========================

@user_admin_bp.route("/users")
@jwt_required()
def user_list():

    if not admin_required():

        return "Forbidden",403


    users = User.query.all()


    return render_template(
        "admin/users/list.html",
        users=users
    )



# ==========================
# Add User
# ==========================

@user_admin_bp.route(
    "/users/create",
    methods=["GET","POST"]
)
@jwt_required()
def user_create():


    if not admin_required():

        return "Forbidden",403


    if request.method=="POST":

        role_name = request.form.get("role")

        role = Role.query.filter_by(
            name=role_name
        ).first()


        if not role:

            flash(
                "角色不存在",
                "danger"
            )

            return redirect(
                url_for(
                    "user_admin.user_create"
                )
            )


        password_hash = generate_password_hash(
            request.form["password"]
        )


        user = User(

            username=request.form["username"],

            password_hash=password_hash,

            role=role

        )


        db.session.add(user)

        db.session.commit()


        flash(
            "新增成功",
            "success"
        )


        return redirect(
            url_for(
                "user_admin.user_list"
            )
        )


    return render_template(
        "admin/users/create.html"
    )

# ==========================
# Edit User
# ==========================

@user_admin_bp.route(
    "/users/<int:id>/edit",
    methods=["GET","POST"]
)
@jwt_required()
def user_edit(id):


    if not admin_required():

        return "Forbidden",403



    user = User.query.get_or_404(id)



    if request.method == "POST":


        user.username = request.form["username"]

        user.role = request.form["role"]


        password = request.form.get(
            "password"
        )


        if password:

            user.password = password



        db.session.commit()



        flash(
            "帳號更新成功",
            "success"
        )


        return redirect(
            url_for(
                "user_admin.user_list"
            )
        )



    return render_template(

        "admin/users/edit.html",

        user=user

    )