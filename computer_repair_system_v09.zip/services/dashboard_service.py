from datetime import datetime

from models.repair_ticket import RepairTicket
from models.user import User
from models.customer import Customer
from models.device import Device


class DashboardService:

    @staticmethod
    def get_admin_dashboard():


        tickets = (
            RepairTicket
            .query
            .order_by(
                RepairTicket.created_at.desc()
            )
            .limit(10)
            .all()
        )


        total_ticket = (
            RepairTicket
            .query
            .count()
        )


        today_count = (
            RepairTicket
            .query
            .filter(
                RepairTicket.created_at >= datetime.today()
            )
            .count()
        )


        pending_count = (
            RepairTicket
            .query
            .filter_by(
                status="pending"
            )
            .count()
        )


        repairing_count = (
            RepairTicket
            .query
            .filter_by(
                status="repairing"
            )
            .count()
        )


        closed_count = (
            RepairTicket
            .query
            .filter_by(
                status="closed"
            )
            .count()
        )


        return {


            "today_count":
                today_count,


            "pending_count":
                pending_count,


            "repairing_count":
                repairing_count,


            "closed_count":
                closed_count,


            "tickets":
                tickets,


            "total_ticket":
                total_ticket

        }
    
    @staticmethod
    def get_engineer_dashboard(user_id):


        tickets = (
            RepairTicket
            .query
            .filter_by(
                assigned_engineer_id=user_id
            )
            .all()
        )


        return {


            "total":
                len(tickets),


            "checking":
                len(
                    [
                        t for t in tickets
                        if t.status=="checking"
                    ]
                ),


            "repairing":
                len(
                    [
                        t for t in tickets
                        if t.status=="repairing"
                    ]
                ),


            "completed":
                len(
                    [
                        t for t in tickets
                        if t.status=="completed"
                    ]
                ),


            "tickets":
                tickets

        }

    @staticmethod
    def get_manager_dashboard():


        tickets = (
            RepairTicket
            .query
            .order_by(
                RepairTicket.created_at.desc()
            )
            .limit(10)
            .all()
        )


        return {


            "total":
                RepairTicket.query.count(),


            "pending":
                RepairTicket.query.filter_by(
                    status="pending"
                ).count(),


            "repairing":
                RepairTicket.query.filter_by(
                    status="repairing"
                ).count(),


            "completed":
                RepairTicket.query.filter_by(
                    status="completed"
                ).count(),


            "tickets":
                tickets

        }

    @staticmethod
    def get_vendor_dashboard(vendor_id):

        tickets = RepairTicket.query.filter_by(
            assigned_vendor_id=vendor_id
        ).all()


        return {
            "tickets":tickets
        }

    @staticmethod
    def get_vendor_tickets(user_id):

        return RepairTicket.query.filter_by(
            assigned_vendor_id=user_id
        ).all()