from database.base import db
from models.user import User
from models.role import Role


class VendorService:


    @staticmethod
    def get_vendor_role():

        role = (
            Role.query
            .filter(
                Role.name.ilike("vendor")
            )
            .first()
        )


        if not role:

            raise Exception(
                "找不到 VENDOR 角色，請先建立 Role"
            )


        return role


    # =========================
    # 查詢所有廠商
    # =========================

    @staticmethod
    def get_all():

        role = VendorService.get_vendor_role()

        if not role:
            return []

        return (
            User.query
            .filter_by(
                role_id=role.id
            )
            .order_by(
                User.id.desc()
            )
            .all()
        )


    # =========================
    # 查詢單一廠商
    # =========================

    @staticmethod
    def get(id):

        return User.query.get(id)



    # =========================
    # 新增廠商
    # =========================

    @staticmethod
    def create(data):

        role = VendorService.get_vendor_role()


        vendor = User(

            username=data.get("username"),

            email=data.get("email"),

            phone=data.get("phone"),

            role_id=role.id,

            status="ACTIVE"

        )


        vendor.set_password(
            data["password"]
        )


        db.session.add(vendor)

        db.session.commit()


        return vendor



    # =========================
    # 修改廠商
    # =========================

    @staticmethod
    def update(id,data):


        vendor = User.query.get(id)


        if not vendor:
            return None



        vendor.username = (
            data["username"]
        )


        vendor.email = (
            data.get("email")
        )


        vendor.phone = (
            data.get("phone")
        )


        db.session.commit()


        return vendor



    # =========================
    # 停用
    # =========================

    @staticmethod
    def disable(id):

        vendor = User.query.get(id)


        if vendor:

            vendor.status="DISABLED"

            db.session.commit()



        return vendor



    # =========================
    # 啟用
    # =========================

    @staticmethod
    def enable(id):

        vendor = User.query.get(id)


        if vendor:

            vendor.status="ACTIVE"

            db.session.commit()


        return vendor



    # =========================
    # 刪除
    # =========================

    @staticmethod
    def delete(id):

        vendor = User.query.get(id)


        if vendor:

            db.session.delete(vendor)

            db.session.commit()


        return True