from database.base import db

from models.user import User
from models.role import Role


class UserService:


    @staticmethod
    def get_all():

        return (
            User.query
            .order_by(User.id)
            .all()
        )



    @staticmethod
    def get_user(user_id):

        return (
            User.query
            .filter_by(id=user_id)
            .first()
        )


    

    @staticmethod
    def get_engineers():

        return User.query.join(
            Role
        ).filter(
            Role.name=="engineer"
        ).all()

    @staticmethod
    def get_vendors():

        from models.role import Role


        vendor_role = (
            Role.query
            .filter_by(
                name="VENDOR"
            )
            .first()
        )


        if not vendor_role:
            return []


        return (
            User.query
            .filter_by(
                role_id=vendor_role.id
            )
            .all()
        )



    @staticmethod
    def create_user(data):


        user = User(

            username=data["username"],

            email=data.get(
                "email"
            ),

            role=data.get(
                "role",
                "user"
            )

        )


        user.set_password(
            data["password"]
        )


        db.session.add(user)

        db.session.commit()


        return user