from datetime import datetime

from database.base import db

from models.repair_ticket import RepairTicket
from models.customer import Customer
from models.device import Device



class TicketService:

    @staticmethod
    def search(
        keyword=None,
        status=None,
        customer_id=None
    ):

        query = RepairTicket.query


        if keyword:

            query = query.filter(

                RepairTicket.ticket_no.like(
                    f"%{keyword}%"
                )

                |

                RepairTicket.title.like(
                    f"%{keyword}%"
                )

            )


        if status:

            query = query.filter(
                RepairTicket.status == status
            )


        if customer_id:

            query = query.filter(
                RepairTicket.customer_id == customer_id
            )


        return query.order_by(
            RepairTicket.created_at.desc()
        ).all()

    @staticmethod
    def create_ticket(data, creator_id):


        customer = Customer.query.get(
            data["customer_id"]
        )


        if customer is None:
            raise ValueError(
                "Customer not found"
            )


        device = Device.query.get(
            data["device_id"]
        )


        if device is None:
            raise ValueError(
                "Device not found"
            )


        ticket_no = (
            f"CRMS-{datetime.now():%Y%m%d%H%M%S}"
        )


        ticket = RepairTicket(

            ticket_no=ticket_no,

            customer_id=customer.id,

            device_id=device.id,

            creator_id=creator_id,

            assigned_engineer_id=None,

            title=data.get(
                "title"
            ),

            problem=data.get(
                "problem"
            ),

            solution="",

            status="new",

            priority=data.get(
                "priority",
                "normal"
            )

        )


        db.session.add(ticket)

        db.session.commit()


        return ticket

    @staticmethod
    def update_ticket(ticket_id, data):


        ticket = RepairTicket.query.get(ticket_id)


        if not ticket:
            return None


        # 案件標題
        if "title" in data:
            ticket.title = data["title"]


        # 問題描述
        if "problem" in data:
            ticket.problem = data["problem"]


        # 優先級
        if "priority" in data:
            ticket.priority = data["priority"]


        # 狀態
        if "status" in data:
            ticket.status = data["status"]


        # 解決方案
        if "solution" in data:
            ticket.solution = data["solution"]


        # 指派工程師
        if "assigned_engineer_id" in data:

            ticket.assigned_engineer_id = (
                int(data["assigned_engineer_id"])
                if data["assigned_engineer_id"]
                else None
            )


        # 指派廠商
        if "assigned_vendor_id" in data:

            ticket.assigned_vendor_id = (
                int(data["assigned_vendor_id"])
                if data["assigned_vendor_id"]
                else None
            )


        db.session.commit()


        return ticket

    @staticmethod
    def get_ticket(ticket_id):


        return RepairTicket.query.get(
            ticket_id
        )



    @staticmethod
    def get_all():


        return RepairTicket.query.order_by(
            RepairTicket.created_at.desc()
        ).all()



    @staticmethod
    def assign_engineer(
        ticket_id,
        engineer_id
    ):


        ticket = RepairTicket.query.get(
            ticket_id
        )


        if ticket is None:
            raise ValueError(
                "Ticket not found"
            )


        ticket.assigned_engineer_id = (
            engineer_id
        )


        ticket.status = "assigned"


        db.session.commit()


        return ticket

    @staticmethod
    def get_waiting_parts():
        """
        Vendor 看待料中的案件
        """

        return (
            RepairTicket.query
            .filter(
                RepairTicket.status == "waiting_parts"
            )
            .all()
        )

    @staticmethod
    def get_vendor_tickets(vendor_id):

        return RepairTicket.query.filter_by(
            assigned_vendor_id=vendor_id
        ).all()

    @staticmethod
    def assign_vendor(ticket_id, vendor_id):

        ticket = RepairTicket.query.get(ticket_id)


        if not ticket:
            return None


        ticket.assigned_vendor_id = int(
            vendor_id
        )


        db.session.commit()


        return ticket