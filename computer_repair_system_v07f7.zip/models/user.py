from database.base import db
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash

class User(db.Model):

    __tablename__ = "users"


    id = db.Column(
        db.Integer,
        primary_key=True
    )


    username = db.Column(
        db.String(50),
        unique=True,
        nullable=False
    )


    password_hash = db.Column(
        db.String(255),
        nullable=False
    )


    email = db.Column(
        db.String(120)
    )


    role_id = db.Column(
        db.Integer,
        db.ForeignKey("roles.id")
    )


    active = db.Column(
        db.Boolean,
        default=True
    )


    created_at = db.Column(
        db.DateTime,
        default=datetime.utcnow
    )


    role = db.relationship(
        "Role",
        back_populates="users"
    )

    roles=db.relationship(
        "Role",
        secondary="user_roles",
        back_populates="users"
    )

    assigned_histories = db.relationship(
        "RepairHistory",
        foreign_keys="RepairHistory.user_id",
        back_populates="user"
    )

    assigned_tickets = db.relationship(
        "RepairTicket",
        foreign_keys="RepairTicket.engineer_id",
        back_populates="engineer"
    )
    
    repair_histories = db.relationship(
        "RepairHistory",
        foreign_keys="RepairHistory.operator_id",
        back_populates="operator"
    )

    def set_password(self, password: str):
        self.password_hash = generate_password_hash(password)


    def check_password(self, password: str) -> bool:
        return check_password_hash(self.password_hash, password)