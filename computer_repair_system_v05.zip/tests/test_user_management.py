import pytest

from app import app as flask_app
from database.base import db
from database.init_db import init_default_users
from models.user import User
from models.role import Role
from models.customer import Customer
from models.asset import Asset
from models.repair_ticket import RepairTicket


@pytest.fixture
def client():
    flask_app.config.update(TESTING=True, SQLALCHEMY_DATABASE_URI="sqlite:///:memory:")
    with flask_app.app_context():
        db.drop_all()
        db.create_all()
        yield flask_app.test_client()
        db.session.remove()
        db.drop_all()


def test_admin_can_manage_users_and_roles(client):
    with flask_app.app_context():
        init_default_users(flask_app)

    client.post(
        "/auth/login",
        data={"username": "admin", "password": "1234"},
        follow_redirects=True,
    )

    create_user_response = client.post(
        "/admin/users",
        data={"action": "create", "username": "newuser", "password": "pass123", "role": "user"},
        follow_redirects=True,
    )
    assert create_user_response.status_code == 200

    create_role_response = client.post(
        "/admin/roles",
        data={"action": "create", "name": "viewer", "description": "可檢視報表"},
        follow_redirects=True,
    )
    assert create_role_response.status_code == 200

    with flask_app.app_context():
        user = User.query.filter_by(username="newuser").first()
        role = Role.query.filter_by(name="viewer").first()
        assert user is not None
        assert role is not None

    delete_response = client.post(
        "/admin/users",
        data={"action": "delete", "user_id": user.id},
        follow_redirects=True,
    )
    assert delete_response.status_code == 200

    with flask_app.app_context():
        assert User.query.filter_by(username="newuser").first() is None


def test_erp_overview_supports_crud_for_customer_asset_and_ticket(client):
    with flask_app.app_context():
        init_default_users(flask_app)

    client.post(
        "/auth/login",
        data={"username": "admin", "password": "1234"},
        follow_redirects=True,
    )

    create_customer_response = client.post(
        "/erp/overview",
        data={
            "action": "customer_create",
            "company": "ERP 客戶",
            "contact_person": "林小明",
            "phone": "0911222333",
            "email": "erp@example.com",
        },
        follow_redirects=True,
    )
    assert create_customer_response.status_code == 200

    create_asset_response = client.post(
        "/erp/overview",
        data={
            "action": "asset_create",
            "asset_no": "A-001",
            "name": "筆電",
            "asset_type": "Laptop",
            "brand": "Dell",
            "model": "Latitude",
            "serial_no": "SN-001",
            "customer_id": "1",
        },
        follow_redirects=True,
    )
    assert create_asset_response.status_code == 200

    create_ticket_response = client.post(
        "/erp/overview",
        data={
            "action": "ticket_create",
            "title": "硬體維修",
            "description": "電源異常",
            "device_type": "Laptop",
            "priority": "high",
            "status": "pending",
            "customer_id": "1",
            "asset_id": "1",
            "cost": "1500",
        },
        follow_redirects=True,
    )
    assert create_ticket_response.status_code == 200

    with flask_app.app_context():
        customer = Customer.query.filter_by(company="ERP 客戶").first()
        asset = Asset.query.filter_by(asset_no="A-001").first()
        ticket = RepairTicket.query.filter_by(title="硬體維修").first()
        assert customer is not None
        assert asset is not None
        assert ticket is not None

    update_customer_response = client.post(
        "/erp/overview",
        data={
            "action": "customer_update",
            "customer_id": customer.id,
            "company": "ERP 客戶更新",
            "contact_person": "林小明",
            "phone": "0911222333",
            "email": "erp@example.com",
        },
        follow_redirects=True,
    )
    assert update_customer_response.status_code == 200

    delete_ticket_response = client.post(
        "/erp/overview",
        data={"action": "ticket_delete", "ticket_id": ticket.id},
        follow_redirects=True,
    )
    assert delete_ticket_response.status_code == 200

    with flask_app.app_context():
        assert Customer.query.filter_by(company="ERP 客戶更新").first() is not None
        assert RepairTicket.query.filter_by(id=ticket.id).first() is None
