from flask import Flask, redirect, render_template_string
from config import Config
from database.base import db
from database.init_db import init_default_users
from models.user import User
from models.customer import Customer
from models.asset import Asset
from models.repair_ticket import RepairTicket
from models.role import Role

from routes.auth_routes import auth_bp
from routes.dashboard_routes import dashboard_bp
from routes.ticket_routes import ticket_bp
from routes.api.ticket_api import ticket_api
from routes.erp_routes import erp_bp
from routes.user_management_routes import user_management_bp

app = Flask(__name__)
app.config.from_object(Config)

db.init_app(app)

# 初始化資料庫與預設帳號，避免首次啟動時 SQLite 還沒建立任何表
with app.app_context():
    db.create_all()
    init_default_users(app)

# Blueprint 註冊
app.register_blueprint(auth_bp, url_prefix="/auth")
app.register_blueprint(dashboard_bp, url_prefix="/dashboard")
app.register_blueprint(ticket_bp, url_prefix="/ticket")
app.register_blueprint(ticket_api, url_prefix="/api/ticket")
app.register_blueprint(erp_bp, url_prefix="/erp")
app.register_blueprint(user_management_bp, url_prefix="/admin")


# 🔥 入口直接導向登入
@app.route("/")
def index():
    return redirect("/auth/login")


if __name__ == "__main__":
    app.run(debug=True)