from flask import Blueprint, redirect, render_template, request, session

from database.base import db
from models.role import Role
from models.user import User

user_management_bp = Blueprint("user_management", __name__)


@user_management_bp.route("/users", methods=["GET", "POST"])
def users():
    if "user_id" not in session or session.get("role") != "admin":
        return redirect("/auth/login")

    if request.method == "POST":
        action = request.form.get("action")
        if action == "create":
            username = request.form.get("username", "").strip()
            password = request.form.get("password", "").strip()
            role = request.form.get("role", "user").strip()
            if username and password:
                user = User(username=username, password=password, role=role)
                db.session.add(user)
                db.session.commit()
        elif action == "update":
            user_id = request.form.get("user_id", type=int)
            user = User.query.get(user_id)
            if user:
                user.username = request.form.get("username", user.username).strip()
                user.password = request.form.get("password", user.password).strip() or user.password
                user.role = request.form.get("role", user.role).strip() or user.role
                user.status = request.form.get("status", user.status).strip() or user.status
                db.session.commit()
        elif action == "delete":
            user_id = request.form.get("user_id", type=int)
            user = User.query.get(user_id)
            if user:
                db.session.delete(user)
                db.session.commit()

    users = User.query.order_by(User.id).all()
    roles = Role.query.order_by(Role.id).all()
    return render_template("user_management.html", users=users, roles=roles)


@user_management_bp.route("/roles", methods=["GET", "POST"])
def roles():
    if "user_id" not in session or session.get("role") != "admin":
        return redirect("/auth/login")

    if request.method == "POST":
        action = request.form.get("action")
        if action == "create":
            name = request.form.get("name", "").strip()
            description = request.form.get("description", "").strip()
            if name:
                role = Role(name=name, description=description)
                db.session.add(role)
                db.session.commit()
        elif action == "update":
            role_id = request.form.get("role_id", type=int)
            role = Role.query.get(role_id)
            if role:
                role.name = request.form.get("name", role.name).strip() or role.name
                role.description = request.form.get("description", role.description).strip() or role.description
                db.session.commit()
        elif action == "delete":
            role_id = request.form.get("role_id", type=int)
            role = Role.query.get(role_id)
            if role:
                db.session.delete(role)
                db.session.commit()

    users = User.query.order_by(User.id).all()
    roles = Role.query.order_by(Role.id).all()
    return render_template("user_management.html", users=users, roles=roles)
