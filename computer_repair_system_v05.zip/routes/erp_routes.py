from flask import Blueprint, redirect, render_template, request, session

from database.base import db
from models.asset import Asset
from models.customer import Customer
from models.repair_ticket import RepairTicket
from models.user import User

erp_bp = Blueprint("erp", __name__)


@erp_bp.route("/customer/create", methods=["POST"])
def create_customer():
    if "user_id" not in session or session.get("role") != "admin":
        return redirect("/auth/login")

    customer = Customer(
        company=request.form.get("company", "").strip(),
        contact_person=request.form.get("contact_person", "").strip(),
        phone=request.form.get("phone", "").strip(),
        email=request.form.get("email", "").strip(),
        address=request.form.get("address", "").strip(),
        notes=request.form.get("notes", "").strip(),
    )
    db.session.add(customer)
    db.session.commit()
    return redirect("/dashboard/admin")


@erp_bp.route("/asset/create", methods=["POST"])
def create_asset():
    if "user_id" not in session or session.get("role") != "admin":
        return redirect("/auth/login")

    asset = Asset(
        asset_no=request.form.get("asset_no", "").strip(),
        name=request.form.get("name", "").strip(),
        asset_type=request.form.get("asset_type", "").strip(),
        brand=request.form.get("brand", "").strip(),
        model=request.form.get("model", "").strip(),
        serial_no=request.form.get("serial_no", "").strip(),
        customer_id=request.form.get("customer_id", type=int),
    )
    db.session.add(asset)
    db.session.commit()
    return redirect("/dashboard/admin")


@erp_bp.route("/overview", methods=["GET", "POST"])
def overview():
    if "user_id" not in session:
        return redirect("/auth/login")

    if request.method == "POST":
        action = request.form.get("action")

        if action == "customer_create":
            customer = Customer(
                company=request.form.get("company", "").strip(),
                contact_person=request.form.get("contact_person", "").strip(),
                phone=request.form.get("phone", "").strip(),
                email=request.form.get("email", "").strip(),
                address=request.form.get("address", "").strip(),
                notes=request.form.get("notes", "").strip(),
            )
            db.session.add(customer)
            db.session.commit()

        elif action == "customer_update":
            customer_id = request.form.get("customer_id", type=int)
            customer = Customer.query.get(customer_id)
            if customer:
                customer.company = request.form.get("company", customer.company).strip() or customer.company
                customer.contact_person = request.form.get("contact_person", customer.contact_person).strip() or customer.contact_person
                customer.phone = request.form.get("phone", customer.phone).strip() or customer.phone
                customer.email = request.form.get("email", customer.email).strip() or customer.email
                customer.address = request.form.get("address", customer.address).strip() or customer.address
                customer.notes = request.form.get("notes", customer.notes).strip() or customer.notes
                db.session.commit()

        elif action == "customer_delete":
            customer_id = request.form.get("customer_id", type=int)
            customer = Customer.query.get(customer_id)
            if customer:
                db.session.delete(customer)
                db.session.commit()

        elif action == "asset_create":
            customer_id = request.form.get("customer_id", type=int)
            if not customer_id:
                customer_id = None
            customer = Customer.query.get(customer_id) if customer_id else None
            if customer is None and customer_id is not None:
                customer_id = None
            if not customer_id:
                return redirect("/erp/overview")

            asset = Asset(
                asset_no=request.form.get("asset_no", "").strip(),
                name=request.form.get("name", "").strip(),
                asset_type=request.form.get("asset_type", "").strip(),
                brand=request.form.get("brand", "").strip(),
                model=request.form.get("model", "").strip(),
                serial_no=request.form.get("serial_no", "").strip(),
                customer_id=customer_id,
            )
            db.session.add(asset)
            db.session.commit()

        elif action == "asset_update":
            asset_id = request.form.get("asset_id", type=int)
            asset = Asset.query.get(asset_id)
            if asset:
                customer_id = request.form.get("customer_id", type=int)
                if customer_id:
                    customer = Customer.query.get(customer_id)
                    if customer is None:
                        customer_id = asset.customer_id
                else:
                    customer_id = asset.customer_id
                asset.asset_no = request.form.get("asset_no", asset.asset_no).strip() or asset.asset_no
                asset.name = request.form.get("name", asset.name).strip() or asset.name
                asset.asset_type = request.form.get("asset_type", asset.asset_type).strip() or asset.asset_type
                asset.brand = request.form.get("brand", asset.brand).strip() or asset.brand
                asset.model = request.form.get("model", asset.model).strip() or asset.model
                asset.serial_no = request.form.get("serial_no", asset.serial_no).strip() or asset.serial_no
                asset.customer_id = customer_id
                asset.status = request.form.get("status", asset.status).strip() or asset.status
                db.session.commit()

        elif action == "asset_delete":
            asset_id = request.form.get("asset_id", type=int)
            asset = Asset.query.get(asset_id)
            if asset:
                db.session.delete(asset)
                db.session.commit()

        elif action == "ticket_create":
            ticket = RepairTicket(
                title=request.form.get("title", "").strip(),
                description=request.form.get("description", "").strip(),
                device_type=request.form.get("device_type", "PC").strip(),
                priority=request.form.get("priority", "medium").strip(),
                status=request.form.get("status", "pending").strip(),
                user_id=session.get("user_id"),
                customer_id=request.form.get("customer_id", type=int),
                asset_id=request.form.get("asset_id", type=int),
                cost=request.form.get("cost", type=float) or 0.0,
            )
            db.session.add(ticket)
            db.session.commit()

        elif action == "ticket_update":
            ticket_id = request.form.get("ticket_id", type=int)
            ticket = RepairTicket.query.get(ticket_id)
            if ticket:
                ticket.title = request.form.get("title", ticket.title).strip() or ticket.title
                ticket.description = request.form.get("description", ticket.description).strip() or ticket.description
                ticket.device_type = request.form.get("device_type", ticket.device_type).strip() or ticket.device_type
                ticket.priority = request.form.get("priority", ticket.priority).strip() or ticket.priority
                ticket.status = request.form.get("status", ticket.status).strip() or ticket.status
                ticket.customer_id = request.form.get("customer_id", type=int) or ticket.customer_id
                ticket.asset_id = request.form.get("asset_id", type=int) or ticket.asset_id
                ticket.cost = request.form.get("cost", type=float) or ticket.cost
                db.session.commit()

        elif action == "ticket_delete":
            ticket_id = request.form.get("ticket_id", type=int)
            ticket = RepairTicket.query.get(ticket_id)
            if ticket:
                db.session.delete(ticket)
                db.session.commit()

    customers = Customer.query.order_by(Customer.id).all()
    assets = Asset.query.order_by(Asset.id).all()
    tickets = RepairTicket.query.order_by(RepairTicket.id).all()
    users = User.query.order_by(User.id).all()
    return render_template(
        "erp_overview.html",
        customers=customers,
        assets=assets,
        tickets=tickets,
        users=users,
    )
