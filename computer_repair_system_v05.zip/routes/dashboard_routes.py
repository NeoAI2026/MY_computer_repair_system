from flask import Blueprint, redirect, render_template, request, session

from models.repair_ticket import RepairTicket
from models.user import User

dashboard_bp = Blueprint("dashboard", __name__)


# 🔐 Admin
@dashboard_bp.route("/admin")
def admin():

    if "user_id" not in session:
        return redirect("/auth/login")

    if session["role"] != "admin":
        return "403 Forbidden", 403

    tickets = RepairTicket.query.all()
    engineers = User.query.filter_by(role="engineer").all()
    return render_template("dashboard_admin.html", tickets=tickets, engineers=engineers)


# 🔧 Engineer
@dashboard_bp.route("/engineer")
def engineer():

    if "user_id" not in session:
        return redirect("/auth/login")

    tickets = RepairTicket.query.filter_by(engineer_id=session["user_id"]).all()
    return render_template("dashboard_engineer.html", tickets=tickets)


# 👤 User
@dashboard_bp.route("/user", methods=["GET", "POST"])
def user():

    if "user_id" not in session:
        return redirect("/auth/login")

    tickets = RepairTicket.query.filter_by(user_id=session["user_id"]).all()
    ai_answer = None
    ai_query = ""

    if request.method == "POST":
        ai_query = request.form.get("ai_query", "").strip()
        if ai_query:
            query = ai_query.lower()
            if "待處理" in ai_query or "pending" in query:
                pending_tickets = [t for t in tickets if t.status == "pending"]
                ai_answer = f"您目前有 {len(pending_tickets)} 筆待處理案件。"
            elif "已完成" in ai_query or "done" in query or "完成" in ai_query:
                done_tickets = [t for t in tickets if t.status == "done"]
                ai_answer = f"您目前有 {len(done_tickets)} 筆已完成案件。"
            elif "我的報修" in ai_query or "報修單" in ai_query or "我的" in query:
                ai_answer = f"您共有 {len(tickets)} 筆報修單，最近一筆是：{tickets[-1].title if tickets else '目前沒有報修單'}。"
            elif "統計" in ai_query or "count" in query:
                counts = {"pending": sum(1 for t in tickets if t.status == "pending"), "processing": sum(1 for t in tickets if t.status == "processing"), "done": sum(1 for t in tickets if t.status == "done")}
                ai_answer = f"統計結果：待處理 {counts['pending']}、維修中 {counts['processing']}、已完成 {counts['done']}。"
            else:
                ai_answer = "我可以幫您查詢待處理案件、我的報修單、已完成案件與案件統計。"

    return render_template("dashboard_user.html", tickets=tickets, ai_answer=ai_answer, ai_query=ai_query)