import os
import sqlite3

p = os.path.join(os.getcwd(), 'database', 'db.sqlite3')
print('db_path', p)
print('exists', os.path.exists(p))
conn = sqlite3.connect(p)
cur = conn.cursor()
print('tables', cur.execute("select name from sqlite_master where type='table' order by name").fetchall())
for table in ['users','customers','assets','repair_tickets','roles']:
    try:
        print(table, cur.execute(f'select count(*) from {table}').fetchone()[0])
    except Exception as e:
        print(table, 'ERR', e)
conn.close()
