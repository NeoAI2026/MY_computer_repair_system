from datetime import datetime

from database.base import db


class Asset(db.Model):
    __tablename__ = 'assets'

    id = db.Column(db.Integer, primary_key=True)
    asset_no = db.Column(db.String(50), unique=True, nullable=False)
    name = db.Column(db.String(120), nullable=False)
    asset_type = db.Column(db.String(80), nullable=False)
    brand = db.Column(db.String(80), nullable=True)
    model = db.Column(db.String(120), nullable=True)
    serial_no = db.Column(db.String(120), nullable=True)
    status = db.Column(db.String(40), default='in_service')
    customer_id = db.Column(db.Integer, db.ForeignKey('customers.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
