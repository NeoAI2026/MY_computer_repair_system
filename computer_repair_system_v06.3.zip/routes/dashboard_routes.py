from flask import Blueprint, jsonify
from flask_jwt_extended import (
    jwt_required,
    get_jwt
)


dashboard_bp = Blueprint(
    "dashboard",
    __name__,
    url_prefix="/dashboard"
)



@dashboard_bp.route(
    "/admin",
    methods=["GET"]
)
@jwt_required()
def admin_dashboard():

    claims = get_jwt()

    role = claims.get("role")


    if role != "admin":

        return {
            "error":"forbidden"
        },403


    return jsonify({

        "message":
        "Admin Dashboard",

        "role":
        role

    })




@dashboard_bp.route(
    "/engineer",
    methods=["GET"]
)
@jwt_required()
def engineer_dashboard():

    claims = get_jwt()

    role = claims.get("role")


    if role not in [
        "admin",
        "engineer"
    ]:

        return {
            "error":"forbidden"
        },403


    return jsonify({

        "message":
        "Engineer Dashboard",

        "role":
        role

    })




@dashboard_bp.route(
    "/manager",
    methods=["GET"]
)
@jwt_required()
def manager_dashboard():

    claims = get_jwt()

    role = claims.get("role")


    if role not in [
        "admin",
        "manager"
    ]:

        return {
            "error":"forbidden"
        },403


    return jsonify({

        "message":
        "Manager Dashboard",

        "role":
        role

    })




@dashboard_bp.route(
    "/vendor",
    methods=["GET"]
)
@jwt_required()
def vendor_dashboard():

    claims = get_jwt()

    role = claims.get("role")


    if role not in [
        "admin",
        "vendor"
    ]:

        return {
            "error":"forbidden"
        },403


    return jsonify({

        "message":
        "Vendor Dashboard",

        "role":
        role

    })


"""
from flask import Blueprint, jsonify
from flask_jwt_extended import (
    jwt_required,
    get_jwt
)

from middleware.permission import permission_required


dashboard_bp = Blueprint(
    "dashboard",
    __name__,
    url_prefix="/dashboard"
)


@dashboard_bp.route("/dashboard/admin")
@jwt_required()
@permission_required("dashboard:view")
def admin_dashboard():

    user_id = get_jwt_identity()

    claims = get_jwt()

    role = claims.get("role")


    if role != "admin":
        return {
            "error":"forbidden"
        },403


    return {
        "message":"admin dashboard",
        "user_id":user_id
    }


@dashboard_bp.route("/dashboard/engineer")
@jwt_required()
@permission_required("dashboard:view")
def engineer_dashboard():

    claims=get_jwt()

    role=claims.get("role")


    if role not in [
        "engineer",
        "admin"
    ]:
        return {
            "error":"forbidden"
        },403


    return {
        "message":"engineer dashboard"
    }


@dashboard_bp.route("/dashboard/vendor")
@jwt_required()
@permission_required("dashboard:view")
def vendor_dashboard():

    claims=get_jwt()

    role=claims.get("role")


    if role not in [
        "vendor",
        "admin"
    ]:
        return {
            "error":"forbidden"
        },403


    return {
        "message":"vendor dashboard"
    }
"""