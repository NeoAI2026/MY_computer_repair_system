from datetime import datetime
import uuid

from database.base import db

from models.customer import Customer
from models.device import Device
from models.repair_ticket import RepairTicket
from models.repair_history import RepairHistory


class TicketService:

    # ==========================
    # Ticket Number
    # ==========================
    @staticmethod
    def generate_ticket_no():
        return "TK-" + uuid.uuid4().hex[:8].upper()

    # ==========================
    # Create Ticket
    # ==========================
    """
    @staticmethod
    def create_ticket(data):

        customer = Customer.query.get(data["customer_id"])
        if customer is None:
            raise ValueError("Customer not found")

        device = Device.query.get(data["device_id"])
        if device is None:
            raise ValueError("Device not found")

        ticket = RepairTicket(
            ticket_no=TicketService.generate_ticket_no(),
            customer_id=customer.id,
            device_id=device.id,
            engineer_id=data.get("engineer_id"),
            title=data["title"],
            description=data.get("description"),
            status="new",
            category=data.get("category", "other"),
            priority=data.get("priority", "normal"),
            workflow_started_at=datetime.utcnow(),
            created_at=datetime.utcnow(),
            updated_at=datetime.utcnow()
        )

        db.session.add(ticket)
        db.session.flush()

        history = RepairHistory(
            ticket_id=ticket.id,
            old_status=None,
            new_status="new",
            remark="建立維修案件",
            created_at=datetime.utcnow()
        )

        db.session.add(history)
        db.session.commit()

        return ticket
    """
    @staticmethod
    def create_ticket(data):


        customer = Customer(

            name=data["customer_name"],

            phone=data.get(
                "customer_phone"
            ),

            email=data.get(
                "customer_email"
            )

        )


        db.session.add(customer)

        db.session.flush()



        device = Device(

            customer_id=customer.id,

            device_type=data["device_type"],

            brand=data.get("brand"),

            model=data.get("model"),

            serial_number=data.get(
                "serial_number"
            )

        )


        db.session.add(device)

        db.session.flush()



        ticket = RepairTicket(

            ticket_no=
            TicketService.generate_ticket_no(),


            customer_id=
            customer.id,


            device_id=
            device.id,


            title=data["title"],


            description=
            data.get(
                "description"
            ),


            priority=
            data.get(
                "priority",
                "normal"
            ),


            category=
            data.get(
                "category",
                "other"
            ),


            status="new",


            workflow_started_at=
            datetime.utcnow()

        )


        db.session.add(ticket)

        db.session.flush()



        history = RepairHistory(

            ticket_id=ticket.id,


            old_status=None,


            new_status="new",


            remark="建立維修案件",


            created_at=datetime.utcnow()

        )


        db.session.add(history)


        db.session.commit()


        return ticket

    # ==========================
    # Get One
    # ==========================
    @staticmethod
    def get_ticket(ticket_id):
        return RepairTicket.query.get(ticket_id)

    # ==========================
    # Get All
    # ==========================
    @staticmethod
    def get_all():
        return RepairTicket.query.order_by(
            RepairTicket.id.desc()
        ).all()

    

    # ==========================
    # Update
    # ==========================
    @staticmethod
    def update_ticket(ticket, data):

        if "title" in data:
            ticket.title = data["title"]

        if "description" in data:
            ticket.description = data["description"]

        if "priority" in data:
            ticket.priority = data["priority"]

        if "category" in data:
            ticket.category = data["category"]

        ticket.updated_at = datetime.utcnow()

        db.session.commit()

        return ticket

    # ==========================
    # Assign Engineer
    # ==========================
    @staticmethod
    def assign_engineer(ticket_id, engineer_id):

        ticket = RepairTicket.query.get(ticket_id)

        if ticket is None:
            return None

        ticket.engineer_id = engineer_id
        #ticket.assigned_at = datetime.utcnow()
        #ticket.updated_at = datetime.utcnow()
        """
        history = RepairHistory(
            ticket_id=ticket.id,
            old_status=ticket.status,
            new_status=ticket.status,
            operator_id=engineer_id,
            remark="指派工程師",
            created_at=datetime.utcnow()
        )
        """
        #db.session.add(history)
        db.session.commit()

        return ticket

    # ==========================
    # Change Status
    # ==========================
    @staticmethod
    def change_status(ticket, new_status, operator_id=None):

        old_status = ticket.status

        ticket.status = new_status
        ticket.updated_at = datetime.utcnow()

        history = RepairHistory(
            ticket_id=ticket.id,
            old_status=old_status,
            new_status=new_status,
            operator_id=operator_id,
            remark=f"狀態變更：{old_status} → {new_status}",
            created_at=datetime.utcnow()
        )

        db.session.add(history)
        db.session.commit()

        return ticket

    # ==========================
    # Close Ticket
    # ==========================
    @staticmethod
    def close_ticket(ticket, operator_id=None):

        old_status = ticket.status

        ticket.status = "closed"
        ticket.completed_at = datetime.utcnow()
        ticket.closed_at = datetime.utcnow()
        ticket.updated_at = datetime.utcnow()

        history = RepairHistory(
            ticket_id=ticket.id,
            old_status=old_status,
            new_status="closed",
            operator_id=operator_id,
            remark="案件結案",
            created_at=datetime.utcnow()
        )

        db.session.add(history)
        db.session.commit()

        return ticket

    # ==========================
    # Delete
    # ==========================
    @staticmethod
    def delete_ticket(ticket):

        db.session.delete(ticket)
        db.session.commit()

        return True